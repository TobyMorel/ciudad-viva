"""Previsión fiscal móvil: impuestos, obras y deuda sin alterar la caja real."""
import copy
import unittest
import server


class MunicipalForecast(unittest.TestCase):
    def setUp(self):
        server.state=server.initial_state()
        self.s=server.state
        self.s['day']=121
        self.s['money']=25000
        self.s['monthlyIncome']=12000
        self.s['monthlyExpenses']=8000

    def test_twelve_months_include_commitments_and_do_not_mutate_city(self):
        self.s['projects']=[{'id':'municipal-1','cost':12000,'paid':2000,'duration':90,'elapsed':30,'status':'en curso'}]
        self.s['finance']['municipalLoans']=[{'id':'loan-1','status':'active','balance':6000,'payment':550,'monthsRemaining':12,'monthlyRate':.01}]
        before=copy.deepcopy((self.s['money'],self.s['projects'],self.s['finance']['municipalLoans']))
        report=server.municipal_finance_report(12000,8000);forecast=report['forecastMonths']
        self.assertEqual(len(forecast['months']),12)
        self.assertEqual(forecast['committedProjects'],10000)
        self.assertGreater(forecast['months'][0]['contractPayments'],0)
        self.assertGreater(forecast['months'][0]['debtService'],0)
        self.assertEqual(forecast['months'][0]['closingCash'],forecast['months'][0]['openingCash']+forecast['months'][0]['net'])
        self.assertEqual(before,(self.s['money'],self.s['projects'],self.s['finance']['municipalLoans']))

    def test_fiscal_scenarios_apply_visible_shocks_without_changing_saved_city(self):
        before=copy.deepcopy((self.s['money'],self.s['finance'],self.s['projects']))
        scenarios=server.municipal_finance_report(12000,8000)['scenarios12']
        base,favorable,adverse=scenarios['scenarios']
        self.assertEqual([x['id'] for x in scenarios['scenarios']],['base','favorable','adverso'])
        self.assertEqual((favorable['incomeChangePct'],favorable['expenseChangePct']),(10,-5))
        self.assertEqual((adverse['incomeChangePct'],adverse['expenseChangePct']),(-15,10))
        self.assertEqual(base['closingCash'],server.municipal_finance_report(12000,8000)['forecastMonths']['closingCash'])
        self.assertGreater(favorable['closingCash'],base['closingCash'])
        self.assertLess(adverse['closingCash'],base['closingCash'])
        self.assertEqual(before,(self.s['money'],self.s['finance'],self.s['projects']))

    def test_tax_rate_changes_the_projected_income(self):
        self.s['taxes']['lastReport']={'collected':100,'propertyBilled':1000,'propertyCollected':500,'businessBilled':500,'businessCollected':250}
        self.s['taxes']['propertyRateBp']=60
        low=server.municipal_finance_report(12000,8000)['forecastMonths']['months'][0]['income']
        self.s['taxes']['propertyRateBp']=120
        high=server.municipal_finance_report(12000,8000)['forecastMonths']['months'][0]['income']
        self.assertGreater(high,low)

    def test_debt_calendar_ends_after_last_installment(self):
        self.s['finance']['municipalLoans']=[{'id':'loan-short','status':'active','balance':100,'payment':120,'monthsRemaining':1,'monthlyRate':.01}]
        months=server.municipal_finance_report(12000,8000)['forecastMonths']['months']
        self.assertGreater(months[0]['debtService'],0)
        self.assertEqual(months[1]['debtService'],0)

    def test_forecast_accumulates_unpaid_installments_then_recovers_arrears(self):
        self.s["money"]=0;self.s["monthlyIncome"]=0;self.s["monthlyExpenses"]=100000
        loan={"id":"arrears-loan","status":"active","balance":10000,"payment":500,"monthsRemaining":4,"monthlyRate":.01,"paymentArrears":0}
        self.s["finance"]["municipalLoans"]=[loan]
        forecast=server.municipal_finance_report(0,100000)["forecastMonths"]
        self.assertTrue(forecast["months"][0]["debtDefault"])
        self.assertEqual(forecast["months"][0]["debtArrears"],500)
        self.assertIsNotNone(forecast['earlyWarning'])
        self.assertEqual(forecast['earlyWarning']['month'],1)
        self.assertGreater(forecast['earlyWarning']['shortfall'],0)
        self.assertTrue(forecast['earlyWarning']['causes'])
        self.s["money"]=1000000;self.s["monthlyIncome"]=1000000;loan["paymentArrears"]=500
        recovered=server.municipal_finance_report(1000000,0)["forecastMonths"]
        self.assertGreaterEqual(recovered["months"][0]["debtService"],1000)
        self.assertLess(recovered["months"][0]["debtArrears"],500)

    def test_forecast_applies_selected_program_priority_when_cash_is_short(self):
        self.s["buildings"]=[];self.s["money"]=0;self.s["monthlyIncome"]=100;self.s["monthlyExpenses"]=300
        budgets=self.s["finance"]["programBudgets"];budgets["programPriority"]=["mobility","services","networks"]
        budgets["lastReport"]={"programs":{key:{"monthlyCost":100} for key in ("services","networks","mobility")}}
        month=server.municipal_finance_report(100,300)["forecastMonths"]["months"][0]
        self.assertEqual(month["programPayments"],100)
        self.assertEqual(month["programArrears"],200)
        self.assertEqual(month["underfundedPrograms"],["services","networks"])
        self.assertEqual(month["programShortfall"],200)
        self.assertEqual(month["fundingGap"],200)
