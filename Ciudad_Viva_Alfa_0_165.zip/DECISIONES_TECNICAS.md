## Alfa 0.165 · viajes persistentes en el mapa 3D

Al construir una calle se conservan la posición y ruta de actores ya existentes. Se retiraron peatones y camiones decorativos sin itinerario causal. Los viajes de trabajo, compras y servicios permanecen ligados a personas de la simulación. 142 pruebas Python pasaron. Progreso global no estimable sin pesos verificables de las 34 fases.

## Alfa 0.164 · Separar interés migratorio, vacantes y presión de construcción

`housingDemand.unmet` permanece como registro persistente de personas interesadas para admisión gradual, **no** como porcentaje de demanda de construir viviendas. `growth_demand.py` y `growth_demand.js` calculan `housing.vacancies` (plazas habitables disponibles, sin hogares cerrados o temporalmente inhabilitados) y `housing.shortage` = espera solo cuando `vacancies` es 0. Ambos motores usan esta presión para habilitar nuevas obras de vivienda; la interfaz muestra plazas libres antes que personas en espera. Comercio mide cantidad de locales operativos y en obra, y considera oferta sin utilizar a locales cuyas últimas ventas satisfacen la demanda reportada; solo inicia obra si hay escasez de locales y esa oferta está agotada. No se infieren oficinas inexistentes. Las pruebas verifican paridad, no sobreconstrucción, y presentación en UI. Obligatorio registrar Alfa y Cambios en cada entrega.

## Fase 7 · decisión de diseño: puente por contrato (propuesta en revisión)

El cauce permanece en x=24–25; la nueva herramienta `bridge` se ancla en (24,y) y reserva ambas celdas. El acceso debe venir de la calle (23,y) con ruta hasta el acceso regional. El cruce se abre solo cuando la constructora termina sus etapas: dos entradas a `roads`, cada una con `roadAssets.bridge=true`, calidad y $80/mes de mantenimiento. La calle (26,y) queda a cargo del jugador para extenderse por el este; nunca se construye automáticamente en terreno privado. Se reutilizan las validaciones de parcela, contrato, cuadrillas, anticipos, inspección y garantía, en LAN y Offline. Las calles normales siguen prohibidas sobre el agua. El primer puente no incorpora todavía simulación de cargas máximas, geotecnia local comparada ni derrumbe: documentar esa profundidad pendiente para fase 16/28.

## Regla de publicación · versión obligatoria en cada entrega

Ningún PR que cambie mecánicas, interfaz, motor o activos debe fusionarse sin incrementar la versión Alfa, registrar los cambios visibles en `release_notes.json` (pantalla **Cambios y novedades**) y sincronizar `index.html` (título, `meta`, caché y `game.js?v=`), la importación versionada del mundo 3D desde `game.js` y los nombres de artefacto del workflow. `tests/test_release_version.py` verifica igualdad de versiones y, en pull requests, compara contra `main` para exigir incremento. Una nueva Alfa no significa por sí sola despliegue público ni prueba física LAN. Las versiones omitidas se recuperaron en Alfa 0.162 (puentes) y 0.163 (pasajeros de taxis).

## Fase 7 · contabilización de pasajeros de taxi

El aforo inicial es de ocho pasajeros por taxi/día. Solo se reasignan viajes existentes de compras o servicios modelados como automóvil con distancia de al menos cuatro tramos, y que se encuentren a una cuadra o menos de dos paradas distintas del circuito. Una vía desconectada, un depósito cerrado o un taxi pausado anulan nuevas recogidas. La emisión del circuito de taxi se añade una vez; los autos particulares desplazados salen del aforo de sus viajes. El registro por día en cada taxi evita que múltiples lecturas de estado dupliquen recaudación; `fareMonth` y `fareByDay` se reinician en cada ciclo de 30 días, y se cobra al cierre mensual junto con el transporte existente. Quedan pendientes conductores reales, espera, despacho y tarifa dinámica.

## Alfa 0.159 · equipamientos públicos inmediatos

Solo los modelos de salud, policía y bomberos declarados en `INSTANT_PUBLIC_MODELS` se colocan al instante. Se valida parcela, conexión vial y caja libre antes de cobrar. La misma regla se aplica a `offline.js` y el servidor; `game.js` omite la selección automática de constructora para estos modelos. Los proyectos antiguos en curso no se migran ni cancelan para evitar cobrar dos veces. Escuelas y otros equipamientos conservan su flujo actual.

## Alfa 0.158 · río y mapa

El cauce ocupa las celdas x=24 y x=25 en toda coordenada y; la regla se comparte entre los motores Online/Offline y la selección del mapa. No cerrar el este con un océano porque debe conservarse la expansión pagada allí. El agua y las dos orillas usan mallas continuas de bandas con curvas deterministas, sin geometría por cada celda. Los puentes aún no están implementados; no permitir calles sobre el cauce hasta disponer de esa mecánica.

## Alfa 0.157 · demanda sin techo inicial

El interés migratorio diario tiene mínimo de 2 personas, y crece de forma acotada con población, puestos y aprobación. La falta de vivienda acumula demanda; la falta de empleo modera el atractivo pero no prohíbe mudarse. Cada residente nuevo aporta 280 de capital privado externo, separado de la caja municipal. Se quita el límite temporal de 120 personas y el techo de espera pasa a 100.000. Las incidencias se conservan al descartar mensajes del buzón; el descarte es local a la sesión.

## Alfa 0.156 · escala temporal común

Cuatro segundos reales equivalen a una hora del juego en x1. x2 y x4 multiplican esa tasa, dando días de 48 y 24 segundos. El servidor y el Worker offline aplican la misma conversión. La iluminación consulta la hora del estado, sin un reloj paralelo. Farolas: paridad de coordenadas `(x+y)%2===0`, que alterna cada tramo recto y mantiene cobertura en los ejes horizontal y vertical.

# Decisiones añadidas · Alfa 0.155

- No ocultar el selector Offline antes de completar el primer `/api/state`; ante fallo, no dejar controles que parezcan jugables sin sesión válida. El adaptador local es prioritario en `api()`.
- Mantener previews 3D suficientemente grandes (120px desktop/100px móvil) y acercar cámara/escala, pero vigilar visibilidad y scroll en pantallas cortas.
- Mantener un tramo de conexión exterior abierto: túnel 4,4 unidades para carretera de cuatro tramos.

# Decisiones anteriores · Alfa 0.153

- Inicio de modos secuenciado con `modeGeneration`: la última elección del jugador prevalece sobre respuestas de red tardías. En offline, `api()` exige el adaptador y nunca recurre al fetch HTTP.
- La primera escena y las escenas pausadas deben renderizarse de forma explícita; una pausa detiene el tiempo simulado, no el dibujo WebGL.
- El panel de construcción es dueño de sus filtros y grid; no debe recibir la segunda navegación de `reference-ui.js`. Reservar altura flexible al grid y generar miniaturas luego del layout. Un modelo defectuoso no debe interrumpir la galería.
- El acceso regional cubre los cuatro tramos iniciales con techo y laterales continuos.

# Decisiones anteriores · Alfa 0.152

- Las vistas previas del catálogo se renderizan con una escena WebGL pequeña usando un solo renderer reutilizable para la galería y se copian a los canvas de tarjeta. Evitar múltiples contextos WebGL por pieza; los modelos usan primitivas/funciones de construcción del mundo, no ilustraciones externas.
- El panel Construir es un drawer inferior responsive; las categorías filtran herramientas y la búsqueda consulta sus títulos/descripciones. Los tool buttons existentes conservan sus event handlers al pasar a la cuadrícula.
- Paradas de colectivo/taxi son accesos directos al diseñador vial existente: el jugador selecciona el depósito y marca orden de paradas. Los costos actuales se mantienen; no se agrega una segunda entidad de parada que duplique el circuito.
- Una coordenada hover de servicio no forma parte de la firma de reconstrucción del mundo. El overlay de cobertura se recalcula separado, preservando orientación y movimiento suave de actores.

- Las obras urbanas no dependen de una cadena logística municipal de materiales. En las partidas guardadas se migran cantidades requeridas/usadas a cero y se reactiva una obra cuyo único bloqueo era la falta de material. Las fábricas sí consumen insumos para su producción comercial.
- Las viviendas y otros permisos privados reaccionan a la zonificación en cada día simulado. La cohorte inicial puede ocupar las primeras viviendas aunque todavía no haya empleo; el ciclo laboral empieza a reaccionar con los negocios que abre la ciudad.
- Los excedentes de fábrica se apartan de su stock real por encima de una reserva. Se vende el lote por carretera a la salida regional o, si existen, por puerto/aeropuerto conectados. El dinero se acredita al completar el viaje.
- Vegetación ambiental es procedural y se crea solo en la caja visible de cámara, con densidad ajustada por zoom. El conjunto de edificios/calles impide colocar vegetación encima de objetos urbanos.
- Cada tile vial crea una farola y cada brazo se orienta hacia el centro del asfalto. Las cabezas de semáforo miran al carril de procedencia del tráfico.
- El modelo inicial del túnel está alineado con la aproximación de carretera en `[4,10]`; revisar captura antes de cambiar coordenadas.

# Decisiones técnicas · Alfa 0.150

## Taxis de circuito manual · Alfa 0.150

Cada entidad `taxiRoutes[]` representa un taxi y su circuito cerrado, con `depotId`, `route` (secuencia de calles), paradas ordenadas (`at`), estado operacional y costos. Un depósito `serviceModel=taxiYard` ofrece cuatro plazas; un taxi usa su acceso vial determinista y vuelve al mismo tramo. La ruta se valida completa antes del cargo: todas las paradas deben ser distintas y sobre calles conectadas/desbloqueadas. Compra $2.800, infraestructura $220 por parada, operación $260/mes. `cancelTaxiRoute` reembolsa la mitad del costo del vehículo; las paradas no se reembolsan. Cliente Online/Offline conservan mismo formato/validación. Vehículo dibujado por `world3d.js`; parada física representativa, no es aún un objeto con capacidad/cobro. La firma de render incluye `taxiRoutes` para reconstruir la escena al cambiar un circuito; los tramos activos suman carga a su calle. El actor expone ficha al seleccionarlo en el mapa.

Todavía no simular conductores, viajes de pasajero, destinos, espera, ocupación o recaudación en taxi; esas variables quedan en cero hasta implementar la movilidad bajo demanda. Evitar agregar ingresos ficticios. En fases próximas: rutas origen/destino de demanda real y asignación de conductor/turno, entonces conectar al modelo de movilidad.

## Líneas de colectivo elegidas por jugador

Una línea manual queda identificada por `garageId` y conserva la secuencia exacta de calles, más la lista de paradas ordenada con `routeIndex`. Cada cochera solo alberga una línea manual; los nuevos vehículos y paradas se cobran juntos al publicar ($700 por bus, $350 por parada). Validar acceso vial y conectividad completa por la red antes de descontar dinero. La línea es bidireccional; el planificador toma los segmentos entre paradas en orden ascendente o inverso. Para hacer transbordo, dos líneas manuales deben compartir una parada puesta en esa misma ubicación. `world3d.js` dibuja marcador físico por parada. Cliente y servidor guardan la misma ruta. Las líneas automáticas viejas se conservan para compatibilidad, pero no se ofrecen como opción al crear desde la UI.

## Última decisión registrada · Alfa 0.148

El buzón de vecinos deriva mensajes de `collectCityAlerts(S)`, filtrando avisos con prioridad 0/1 para mantener solicitudes accionables y no convertir resoluciones pasadas en emergencias actuales. El remitente se obtiene de los residentes con nombre en los hogares más cercanos; se usa una selección estable por ID del aviso para evitar que el nombre cambie con cada render. Si no hay padrón, el fallback es «Voz vecinal». El texto se presenta en la interfaz sin escribir un registro paralelo ni inventar incidentes.

«Ver» centra la parcela con `world.focusTile(x,y,viewParams())`, conservando la rotación y ampliando el zoom móvil hasta 1,45 cuando sea necesario. El panel no bloquea la vista y su enlace abre el listado actual de avisos. El foco solo mueve cámara y selección; no altera economía ni simulación.

## Decisión anterior · Alfa 0.147

La calle municipal deja de ser una obra contractual. `placeRoad` coloca y cobra un tramo de inmediato en Online y Offline, con precio base $1.200, sin `project`, constructora, materiales ni mano de obra. `place` con `kind=road` conserva compatibilidad redirigiendo a la misma acción. La adyacencia ortogonal a la red, terreno habilitado, agua, ocupación y fondos comprometidos siguen validados. Cada tramo añade el activo de mantenimiento actual ($15/mes). El cliente mantiene la herramienta de calles activa y serializa clics sucesivos para no competir por el mismo saldo.

## Decisiones anteriores · Alfa 0.146

Los semáforos se modelan con `trafficSignalOverrides`: ausencia de una clave significa instalado en cruces con al menos tres accesos; `false`/`true` guarda la preferencia al retirar/instalar. La misma coordenada y el mismo override alimentan Three.js, la espera visual y el cálculo de viaje Online/Offline. El servidor ejecuta la mutación bajo su lock compartido.

Los efectos se generan con Web Audio, sin archivos externos ni llamadas de red. Sirenas cortas dependen de respuestas registradas, crepitación de incendios activos y bocinas de congestión de colas/trayectos. Se priorizan volúmenes bajos y límites entre repeticiones; audio desactivado, pestaña oculta o simulación pausada no emiten nuevos efectos.

La decisión anterior sobre expansión del mapa sigue documentada en la sección Alfa 0.145 al final de este archivo.

## Alfa 0.141 · mortalidad y servicios funerarios

`urbanEvolution.deceased` conserva hasta 2.000 fallecimientos recientes con ID de residente, edad, año/día, hogar y disposición funeraria. La edad avanza al cambiar el año de simulación; la curva anual determinista por ID evita resultados arbitrarios y reproducibilidad rota al recargar. Los umbrales por edad están implementados en `natural_death_threshold()` y `offlineNaturalDeathThreshold()`. Al morir, la identidad se retira del hogar y del padrón en la misma transición. La vacante puede recibir migración en el cierre mensual normal.

`cemetery` guarda `funeralService.burials`, con tope de 120 plazas permanentes; `crematorium` registra `cremationsThisYear`, `totalCremations` e historial, con tope anual de 24. Se buscan servicios habilitados con ruta al acceso regional y ruta desde el hogar; se usa el cementerio más cercano que tenga plaza, después se intenta cremación. Sin servicio alcanzable o con capacidad agotada, la disposición queda `en espera`; la búsqueda diaria hace que una obra habilitada pueda resolverla ese mismo año. El contador anual se reinicia al cambiar de año. Las instalaciones conservan el gasto fijo mensual en el gasto municipal y sus puestos son vacantes de empleo ordinarias.

El reporte `urbanEvolutionReport` / `offlineUrbanEvolutionReport` conserva capacidad, ocupación, espera, cremaciones, rutas y costos. La interfaz está en Ciudad → Evolución; la escena muestra modelos distintos en `world3d.js`. Próxima extensión debe cubrir transporte funerario físico y los demás eventos del fin de vida únicamente después de avanzar sistemas que aún están vacíos.

# Decisiones técnicas · Alfa 0.140

- El servidor Online y el primer inicio Offline arrancan en una partida nueva vacía. La acción Nueva partida Online limpia el estado actual; Offline aplica el inicio vacío solo si no hay guardado. Se conserva el modelo de servicios y hay una única puerta vial exterior. El mapa construye visualmente la continuación de esa ruta sin fingir que son calles municipales construidas. Offline solo aplica el escenario vacío cuando no hay guardado; no migra ni borra guardados anteriores.
- La migración de arranque conserva una demanda pendiente inicial de 36 y genera cuatro solicitudes mensuales hasta 120 potenciales, incluso antes de que haya empleos. Este tope solo modera el arranque; el sistema de hogares y empleo debe gobernar la permanencia posterior.
- Viviendas, comercios y fábricas zonificados son promociones privadas. El precio de proyecto cubre materiales/insumos de obra; no se inventan entregas del inventario municipal. La ciudad mantiene el costo del permiso y la obra conserva cuadrilla, duración, etapas e inspección.
- Se conserva el generador mensual de incendios y robos existente; no se incrementa su frecuencia hasta integrar una evaluación de seguridad/equipos que no genere incidentes arbitrarios. En visual se representan partículas solo para incidentes activos.
- Pendiente posterior, no parte terminada: muerte natural, capacidad funeraria, cementerios/crematorios, patrullas 3D y una farola asignada por nuevo tramo vial.

# Decisiones técnicas · Alfa 0.139

## Viajes de acero importado por mar

Cada remesa `steelShipments` persiste un `voyageId` enlazado a `supply.portVoyages`, con origen oceánico, puerto de destino, días de zarpe/arribo, carga de acero y unidades descargadas. Los guardados que ya tenían remesas activas obtienen el viaje al avanzar sin repetir unidades ni costo. El actor 3D usa progreso fraccional según reloj simulado (pausa incluida); al arribar queda atracado hasta que la capacidad diaria autoriza descargar. Solo entonces sube el stock del proveedor. El informe distingue importaciones de exportaciones.

# Decisiones técnicas · Alfa 0.138

## Estimación preliminar de ciclo de vida

La ficha de obra pública calcula escenarios acumulados a 1, 4, 10 y 20 años. Construcción se cuenta una sola vez. Operación solo se suma donde el modelo existente tiene costo mensual explícito; para los demás se muestra “no cuantificada” y se excluye del total. Mantenimiento se muestra como provisión orientativa del 2,5% anual del capital, no como gasto simulado ni descuento de tesorería. Suelo, diseño, financiación, inflación, renovación, cierre y costos operativos ausentes permanecen excluidos en forma visible. La UI se pliega para evitar saturar y el diálogo conserva scroll para que la nota completa sea accesible.

# Decisiones técnicas · Alfa 0.133

## Obras de construcción sin elección de empresa

El jugador elige el tipo de obra y confirma la ficha económica; el cliente asigna automáticamente una constructora compatible con menor precio, desempata por plazo y calidad, y el anfitrión/servidor vuelve a validar fondos, trabajadores, capacidad y parcela antes de registrar el contrato. No se elimina el modelo interno de empresas: sus perfiles todavía determinan precio, duración, calidad, caja de obra, abastecimiento y garantías. La ficha presenta la inversión del proyecto, el plazo base y el responsable del financiamiento. Si todas las cuadrillas están ocupadas o falta caja, la acción queda deshabilitada y explica el motivo. Esta decisión prioriza la gestión urbana y quita la microdecisión de licitar a cada edificio.

Las inversiones privadas zonificadas siguen siendo automáticas, de acuerdo con la decisión anterior del usuario. Construcción municipal y rehabilitación continúan como obra por etapas; la confirmación directa no significa que el edificio aparezca terminado.

# Decisiones técnicas · Alfa 0.132

## Desplazamiento temporal por desastres

- Solo evacuamos cuando la vivienda es afectada en la rutina autoritativa de daño: inundación con al menos 75 m³ de escorrentía sobre el edificio o segundo anegamiento, o incendio que deja la condición en 35% o menos.
- Residentes existentes se trasladan como los mismos registros en `socialServices.shelterResidents`; población y `housingDemand.unmet` no cambian. La clase `displacedBy` permite priorizarlos sobre la migración nueva.
- El hogar original queda marcado con `emergencyReturnDay` durante siete días. Se excluye de nuevas colocaciones; al siguiente cierre mensual a partir de la fecha, las personas regresan si existe y mantiene calidad habitable. Aún no hay una licitación privada automática de reconstrucción para viviendas arrasadas.
- Si falta cama, mantienen su identidad en la espera municipal; el límite fiscal, personal y de redes sigue vigente. El reporte separa desplazados de migrantes para que no se resten de la demanda residencial pendiente.
- Online/Offline son equivalentes. La elegibilidad concreta se basa en las reglas de daño ya existentes, sin eventos aleatorios adicionales.

# Decisiones técnicas · Alfa 0.131

## Refugio social

- `socialServices.shelterResidents` guarda residentes temporales con identidad estable; `shelterReport` conserva capacidad/ocupación y actividad del período. No cuentan como hogares con vivienda ni se vuelven a sumar al realojarse.
- Capacidad de cada refugio = mínimo entre camas físicas y tres camas por trabajador asignado; se limita por la menor disponibilidad entre electricidad, agua y cloacas y por el porcentaje efectivo de financiamiento de Servicios. Sin acceso vial desde el centro no admite residentes.
- Solo se admiten candidatos ya generados por la demanda migratoria y con empleo disponible; se asignan primero viviendas permanentes disponibles a residentes temporales en cuanto se ejecuta la colocación mensual.
- El refugio es una obra cívica con los recursos/etapas existentes, no una aparición instantánea. El costo operativo fijo mensual se incluye en Servicios.
- Alcance explícito de esta iteración: cubre demanda migratoria nueva sin alojamiento. Todavía no evacua hogares existentes desplazados por incendio/inundación ni modela atención geriátrica, salud individual, reunificación o duración máxima de estancia. Son siguientes pasos, no funciones completadas.
- `server.py` y `offline.js` mantienen reglas paralelas; suites dedicadas cubren admisión, realojamiento y cuellos de botella.

# Decisiones técnicas · Alfa 0.130

## Subsidio directo de alquiler con apropiación mensual

`socialServices.housingAidBudget` persiste el cupo autorizado (0–5.000, pasos de 250). La selección mensual exige vivienda `home` resultante de `adaptiveReuse`, ocupación y `rentArrears` positivos; ordena por ingreso mensual por residente y luego por deuda. Cada unidad no recibe más que la mora existente ni más que una renta mensual. Se calcula después de `collect_adaptive_rents`, por lo que responde al impago observado del período.

El costo propuesto se añade al programa fiscal `services` antes de liquidar caja; la ayuda efectivamente abonada se escala por `fundingPct` de Servicios. La liquidación aumenta `rentalOwnerCash`, reduce `rentArrears` y registra día/importe en la casa. No altera `householdCash`, no crea efectivo y no promete pagos cuando la apropiación o la caja no alcanzan. El último informe guarda elegibles, demanda, pago, beneficiarios y no cubierto.

La UI queda en Economía, junto al presupuesto municipal, con límites y últimos resultados. Se mantiene acotada a vivienda de alquiler reconvertida porque ese es el modelo de renta/arrears existente; refugios y otras prestaciones quedan pendientes.

# Decisiones técnicas · Alfa 0.129

## Inspección de anexos y balance de materiales

La finalización Offline deriva calidad de `RESTORATION_CONTRACTORS[p.contractor]` y la pasa a `completeOfflineSchoolExpansion`; la ruta de recepción anterior enviaba una variable `quality` inexistente, que solo fallaba cuando terminaba la obra. Online conserva la calidad contractual/penalizaciones existente. Ambos motores anexan al historial del edificio el número de aulas/plazas/docentes, empresa, calidad, costo y copias de `materialsRequired`/`materialsUsed`, porque el proyecto activo se elimina al recibirlo. La garantía común se crea después de la inspección.

Las regresiones ejercitan el avance diario real: producción/stock en patio, demoras por acceso o insumos, hitos certificados, consumo completo, habilitación y garantía. El escenario de laboratorio estabiliza sucesos viales para probar la recepción sin azar; las reglas de interrupciones y reanudación siguen activas en partidas reales.

# Decisiones técnicas · Alfa 0.128

## Anexos escolares como obra pública

`expandSchool` localiza una escuela habilitada, valida modelo educativo y acceso vial, comprueba presupuesto después de compromisos y permite un anexo activo por sede. El proyecto usa `kind=school`, `projectType=schoolExpansion`, cuatro etapas y materiales proporcionales a la receta de escuela. Cobra 20% al contratar; la capacidad permanece sin cambios hasta inspección. En la recepción, amplía aulas y vacantes de maestros, registra historial de calidad y añade gasto mensual al municipio. El crecimiento de capacidad no asigna docentes: sigue dependiendo del sistema de empleo, salarios, rutas y presupuesto.

Online se procesa en `server.py`; Offline reproduce la misma acción y campos en `offline.js`. El panel cliente lee el proyecto sincronizado y no simula la obra localmente. El anexo máximo es de seis aulas sobre la base del modelo. La prueba automatizada cubre contrato, fondos, materiales, bloqueo de duplicado, capacidad al inspeccionar y presentación responsive; la entrega de materiales y la inspección a través del avance de días requieren una prueba integral adicional.

# Decisiones técnicas · Alfa 0.127

## Prioridad de pagos municipales

`programPriority` conserva un orden completo y sin duplicados para `services`, `networks` y `mobility`. Al liquidar el cierre mensual, se aplica la apropiación y se descuenta caja disponible en ese orden. Los importes impagos siguen como mora y cada factor de financiación conserva sus efectos en el simulador. La acción Online es autoritativa; Offline usa la misma estructura y valida programas. Las partidas previas se migran al orden servicios → redes/residuos → movilidad.

# Decisiones técnicas · Alfa 0.126

## Advertencia de caja insuficiente proyectada

`municipal_finance_forecast` y `offlineMunicipalForecast` toman el primer registro de los 12 meses con `fundingGap > 0`. Devuelven `earlyWarning` con número/etiqueta de mes, mayor faltante entre el hueco de caja y el saldo libre negativo, causas observadas del mes y tres opciones de gestión. Solo es información proyectada: no cobra, recorta ni pausa nada. Se muestra encima del acordeón fiscal para que el riesgo no requiera abrir el calendario.

El aviso distingue operación mayor que ingresos, certificados de obras, mora presupuestaria y cuotas no cubiertas. Ambos motores conservan los mismos nombres de campo y decisión; el test UI cubre el caso de advertencia en móvil y escritorio.

# Decisiones técnicas · Alfa 0.125

## Presión fiscal sobre población y apoyo

La presión se calcula como impuestos efectivamente cobrados dividido por la suma de salarios observados en hogares, ventas de comercios e impuestos cobrados. Se redondea a porcentaje entero y se guarda en `taxes.lastReport.pressure`, por lo que las ciudades anteriores empiezan con 0 hasta su próximo cierre. La métrica usa pagos, no deuda facturada ni tasa nominal.

A partir de 5%, cada tramo completo de 5 puntos reduce en uno (máximo cinco) la puntuación base de apoyo y el flujo mensual de potenciales migrantes, sin crear migraciones forzadas de salida. La aprobación general no se modifica por esta regla: los distritos reflejan apoyo, y la demanda residencial retiene sus límites por empleo y viviendas. La mora impaga continúa reduciendo aprobación por las reglas existentes. Fórmulas equivalentes viven en `server.py` y `offline.js`; la sección Economía ya tiene una barra para la presión fiscal.

# Decisiones técnicas · Alfa 0.124

## Crédito empresarial bajo mora tributaria

La línea de cada comercio se calcula como `max(0, límite contractual - mora tributaria del activo)`. Se identifica la cuenta por el ID estable de la empresa (o coordenada heredada). Tres cierres consecutivos impagos fijan en cero la disponibilidad para nuevos giros. La deuda crediticia vigente se conserva; no se acelera su vencimiento. Cuando el impuesto completo queda saldado, el contador vuelve a cero y se restaura el límite después de descontar cualquier saldo tributario restante.

La regla se consulta en cada giro y compra para evitar usar capacidad calculada antes del cobro mensual. Online y Offline aplican las mismas condiciones; los eventos aparecen al cruzar la tercera mora y al regularizarse.

# Decisiones técnicas · Alfa 0.123

## Recuperación fiscal de servicios

`programBudgets.financialServiceImpact` registra solamente los puntos efectivamente perdidos por el deterioro de `services` durante cierres con facturas actuales sin cubrir. Se calcula contra el valor previo y respeta el piso de 5, por lo que no registra puntos que la ciudad no perdió.

La recuperación solo ocurre cuando el costo corriente del programa está completamente pagado y su mora llega a cero. Entonces se restaura como máximo un punto por mes, sin superar 100 y sin reducir el daño fiscal pendiente más allá de la restauración aplicada. Otras causas de pérdida no se revierten. La regla corre igual en Online y Offline; el saneamiento de guardados agrega el saldo en cero para ciudades anteriores.

# Decisiones técnicas · Alfa 0.122

## Cuotas municipales impagas

Cada cierre liquida la cuota actual y, si existe mora, hasta una cuota contractual vencida adicional. Si caja y reserva no cubren el importe total, no se amortiza principal; solo se registra la cuota corriente como mora nueva, sin duplicar mora previa. El servicio de deuda y el límite de crédito cuentan las cuotas vencidas. El principal permanece en activo hasta que principal y mora lleguen a cero; el último vencimiento liquida el saldo restante por redondeos. La previsión usa una copia de préstamos y no modifica la ciudad.

La lógica es paralela en servidor y navegador. Las pruebas cubren default, calendario, acumulación, recuperación parcial, límite de plazo y cierre mensual offline.

# Decisiones técnicas · Alfa 0.121

## CI responsive

No usar capturas de página completa del mapa 3D con SwiftShader en el job de layout: Chromium excedía el límite interno de 30 s esperando la captura. La suite conserva mediciones y asserts DOM de dimensiones, visibilidad, desbordes y solapamientos en 390×844 y 1440×900. No se sube un artefacto de capturas vacío. Las pruebas funcionales de escenas y vehículos siguen activas.

# Decisiones técnicas · Alfa 0.120

## Previsión de tesorería municipal

La previsión de doce meses es de solo lectura. Proyecta impuestos desde las tasas actuales y la proporción histórica recaudada (si todavía no hay un cierre fiscal, se parte de la tasa vigente completa); ingresos no tributarios y gastos ajenos a programas permanecen al nivel mensual actual. Los programas aplican su porcentaje aprobado al costo vigente y arrastran el déficit como mora. Las obras públicas distribuyen lo no pagado sobre los meses de trabajo restantes. La deuda usa la cuota y tasa guardadas y deja de cargarse al vencer o cancelarse. Garantías y compromisos aparecen por separado; la caja libre descuenta obras pendientes y mora. Esta aproximación no pronostica crecimiento, inflación ni crisis, y no cambia el saldo del juego.

Online (`server.py`) y Offline (`offline.js`) comparten las reglas. Las pruebas verifican horizonte, desembolsos, deuda, ajuste tributario y ausencia de mutación Online; Offline comprueba estructura y operaciones básicas.

# Decisiones técnicas · Ciudad Viva

## Alfa 0.119 · continuidad física de carga durante desvíos

Cada pedido en tránsito persiste `currentPosition` como la última intersección alcanzada. Al cambiar el camino, se busca desde allí y se compara con el sufijo anterior. Un camino sin cambios mantiene `travelledDistance`; un camino nuevo vuelve a cero solo para el segmento restante. Esto evita reiniciar el trayecto en el proveedor o mover el vehículo a otra calle. Un cierre sin alternativa conserva ubicación y espera. `plannedArrivalDay` se fija al salir y no se altera cuando se recalcula, para comparar la ETA actual contra el compromiso original. La lógica se replica en Online/Offline; Online incluye el factor de flujo de las calles restantes y Offline usa la distancia física recalculada.

## Alfa 0.118 · selección de rutas considerando congestión y obras

Online y Offline usan Dijkstra determinista con costo por tramo: una unidad base de distancia, más penalización acotada por la cola persistente/capacidad, y fricción temporal cuando una obra vial activa está junto al tramo. Los desempates siguen coordenadas estables para que una misma partida genere los mismos recorridos. Las calles cerradas por incidentes o deterioro se filtran antes de buscar la ruta. Se aplica el mismo criterio a pasajeros, emergencias y logística para evitar redes de transporte incompatibles. La interfaz no cambia; la ruta alimenta los tiempos y reportes existentes. Fase 7 avanza a 95% por alternativa dinámica funcional; falta medición de impacto integral y rendimiento sobre redes grandes. El progreso global sigue sin base ponderada verificable.


## Alfa 0.110 · arte procedural reutilizable

Se mantiene Three.js y el formato de datos. `world3d.js` incorpora una caché de BoxGeometry, IcosahedronGeometry y CylinderGeometry por dimensiones. `clear(dynamicRoot)` no libera estas geometrías compartidas; sí elimina geometrías y materiales efímeros. Las fachadas se modelan en varias caras para permitir rotación. La vista previa del menú se difiere 1,8 segundos y se cancela si el usuario ya inició una partida para que el render no bloquee el clic. Los cruces se dibujan solo en intersecciones del grafo existente y las etapas visuales usan `project.progress`, sin tiempo ni costo inventado. Referencias en `design_reference_3d/` y dirección técnica en `ARTE_3D.md`. La fase 15 avanza a 80%; no se calcula porcentaje global sin ponderación estable.


## Alfa 0.109 · implementación de las referencias visuales

El usuario aportó trece PNG como especificación visual. Los archivos `reference.css` y `reference-ui.js` implementan el nuevo lenguaje de forma adaptable y mantienen los paneles originales como `ref-source`, evitando perder acciones de mecánicas existentes. Las tarjetas nuevas leen `S` y nunca copian números de las imágenes. Los PNG permanecen en `design_reference/` para continuidad. El render de Three.js limita resolución y detalle lejano en pantallas grandes para sostener la respuesta del navegador. La fase 15 pasa de 70% a 75%; el porcentaje total sigue sin base ponderada.


- **Servidor LAN:** Python 3.9+ y `ThreadingHTTPServer`, sin paquetes Python. El anfitrión conserva el estado único; acciones se serializan bajo bloqueo y clientes consultan cada segundo. La API y los archivos gráficos se sirven desde el mismo origen. Solo los archivos públicos del juego se exponen.
- **Multijugador:** el primer ID de cliente se vuelve anfitrión. Solo el anfitrión puede pausar, cambiar velocidad, iniciar partida nueva y cargar/guardar. Los demás jugadores comparten caja y pueden planificar. El ID es una identidad ligera de alfa; aún no hay cuentas, autenticación robusta ni roles municipales.
- **Inicio y archivos:** doble clic en el lanzador inicia servidor y navegador. Three.js 0.171.0 está empaquetado bajo `vendor/` con su licencia MIT; no se usa CDN ni se requiere npm en el juego. Python atiende `index.html`, `game.js`, `world3d.js`, `style.css`, `favicon.svg` y los dos módulos Three.js.
- **Render:** escena WebGL 3D isométrica con Three.js, cámara ortográfica, giros de 90°, luz direccional, sombras en escritorio, textura de suelo procedural, árboles, costa, paseo, calles, vehículos ambientales y edificios compuestos de geometría propia. La escena se genera sin modelos protegidos ni recursos externos. En móvil se desactiva el mapa de sombras y se baja la densidad de render para conservar fluidez. Los autos ambientales siguen decorativos. Los camiones de materiales sí recorren la red compartida: cada tramo tiene capacidad de corredor, los traslados agregados hogar-trabajo generan demanda en los corredores y camiones simultáneos añaden volumen local. El servidor reduce el avance del camión según volumen/capacidad, recalcula el ETA a diario y publica progreso por distancia recorrida para que la escena renderice la posición autoritativa. Cada residente laboral conserva identidad y una única asignación a vacante si existe ruta vial. La población potencialmente activa se estima como ocupación × 42%; la tasa de empleo limita las asignaciones. Los puestos privados tienen vacantes por empresa y los públicos restantes se distribuyen entre servicios habilitados. Los flujos se agrupan por hogar y destino en el mapa. El viaje estima 2,5 minutos por tramo y una asistencia con piso del 25%. El impuesto municipal es $2/mes por puesto privado efectivo. Las nóminas privadas pasan de la caja de la empresa a la caja compartida del hogar; la nómina pública se suma al gasto municipal. Las compras locales descuentan efectivo del hogar. Aún no se aplican salarios diferenciados por persona, jornadas ni congestión de cruces.
- **Escala:** la ciudad interactiva sigue en una cuadrícula de 28×20. La cámara puede desplazarse y acercarse, pero la expansión del mapa continúa pendiente.
- **Calendario:** 360 días/año, 30 por mes; un día por segundo en ×1, con ×2/×4 y pausa bajo control del anfitrión.
- **Vivienda:** los edificios residenciales mantienen ocupación y capacidad. Cada mes la migración se limita por vacantes y empleo estimado; las mudanzas cambian ocupación, población e ingreso fiscal. Los edificios de guardados previos reciben una capacidad migrada de 115% de su ocupación registrada.
- **Terreno:** la costa bloquea construcción común hasta implementar puertos. El terreno edificable es plano en esta alfa; los tipos de suelo todavía no modifican costos.
- **Contratos y cuadrillas:** constructoras tienen cupos simultáneos y dotación finita. Calle requiere 4 trabajadores, vivienda 6, comercio 7 y centro de salud 11. Pausar libera trabajadores; reanudar vuelve a validar cupo y personal. Los salarios y materiales están incluidos en el precio contractual, sin cobros dobles.
- **Materiales y pedidos:** áridos, acero, madera y componentes se consumen según avance de preparación, estructura e instalaciones. Faltantes detienen avance y pago. El jugador cotiza un pedido para una obra a corralón local, mayorista regional o flete urgente. Cada proveedor tiene precios, stock finito y plazo distintos; el precio incluye flete por distancia vial. Se cobra de la caja de la constructora al pedir y se reserva stock del proveedor. La entrega usa una ruta conectada desde el acceso regional; si no hay ruta, el camión espera y recalcula. La carga pasa al inventario de esa constructora en el patio o depósito elegido al completar la descarga asignada. El mercado repone producción mensualmente. Vehículos de entrega recorren la ruta como representación visual. El patio inicial tiene 240 unidades; cada depósito municipal terminado agrega 500 y cuesta $180/mes. Cada ubicación conserva stock por constructora. El pedido reserva espacio en el destino elegido y el camión toma una ruta hasta allí. La prioridad normal respeta orden de llegada; la alta se adelanta solo al competir por recursos de descarga, no reduce ETA ni cambia el costo de flete. La cola automática favorece órdenes cuya carga completa destraba la siguiente etapa de una obra que tiene acceso vial al destino. Suma días esperando y muestra costo contractual/duración × espera como plazo expuesto, sin descontarlo. La prioridad manual alta conserva precedencia. Al llegar, conserva la reserva mientras espera equipo y durante la descarga; el camión se detiene y los bultos se animan hasta la playa. Una obra consume primero el depósito alcanzable más cercano por la red vial, luego otras ubicaciones accesibles. El patio mantiene el inventario heredado de versiones anteriores. La descarga se bloquea si el contratista no tiene operarios configurados y un autoelevador libre; el volumen dividido por su tasa de manejo define el plazo. La cuadrilla y el autoelevador quedan reservados y se liberan al completar o cuando se corta la ruta.
- **Calidad municipal:** la calidad de una calle modifica mantenimiento mensual; la calidad del centro de salud cambia cobertura y operación. El guardado JSON conserva inventario, dotación, viviendas y estado de contratos; las urgencias y su exposición se derivan al presentar el estado y no se guardan como valores financieros. Cargar esquemas anteriores migra los campos faltantes; el esquema 10 migra pedidos en tránsito a distancia recorrida y día de salida estimado, sin persistir los flujos laborales derivados; el esquema 11 conserva esos cálculos como derivados y no añade estado guardado; el esquema 12 expone cobertura laboral y actividad fiscal como valores derivados; el esquema 13 agrega estado contable inicial a comercios anteriores; el esquema 14 genera residentes identificables y caja doméstica para ciudades previas; el esquema 15 agrega mayoristas privados y almacén inicial de insumos a tiendas existentes; el esquema 8 crea inventario vacío en depósitos existentes, asigna prioridad normal a órdenes antiguas y reinicia descargas a la espera de reasignar cuadrilla/equipo.
- **Presupuesto inicial:** $48.000 municipales, $26.000 privados, 620 residentes, 286 empleos, $6.200/mes de ingresos y $4.700/mes de gastos. Son valores iniciales de balance, no una economía final.

- **Empleo y salarios (Alfa 0.16):** cada residente en edad laboral se representa como registro estable dentro de su hogar. Una persona ocupa como máximo una vacante alcanzable por calle. La asistencia derivada del tiempo de viaje multiplica el salario base: la nómina acreditada en el hogar coincide con el débito privado o el gasto municipal. Los hogares compran una cantidad pequeña de bienes solo si tienen efectivo. Se usa una caja común por vivienda hasta implementar personas adultas e ingresos separados.

- **Modos de ejecución (Alfa 0.17):** Offline usa un estado inicial estático y persistencia localStorage, por lo que funciona en hosting estático como Vercel. Conserva avance de calendario, obras básicas y partidas en el mismo navegador. Online requiere la API Python del anfitrión LAN y se valida antes de entrar. La simulación offline aún no implementa pedidos logísticos ni todas las acciones del servidor.

- **Compras de comercios (Alfa 0.18):** tres mayoristas de mercancía guardan stock y reposición mensual. Cada tienda compra unidades alcanzables, paga al ordenar, aparta stock y recibe después de preparación y viaje por calles. Precio puesto en tienda incluye tarifa por distancia y demora. La producción consume inventario recibido; faltantes reducen producción. Hogares ponderan distancia y precio, y tiendas ajustan el precio al observar ventas/stock. Los ingresos regionales por exportación se registran a un precio menor.

- **Crédito comercial (Alfa 0.19):** el Banco Cooperativo comienza con liquidez finita de $42.000. Cada negocio tiene una línea de hasta $200 por puesto y tasa mensual del 2%, respaldada por caja disponible del banco. Se toma automáticamente para pagar nómina, gastos e insumos; el interés se cobra por mes y el excedente superior a una reserva de caja de $500 amortiza deuda. Dos vencimientos consecutivos de interés sin cobertura cierran el negocio, eliminan vacantes y marcan sus residentes como buscadores de empleo con empleador previo. Offline conserva la misma mecánica en localStorage. Guardados esquema 15 migran a esquema 16.
- **Historial de versiones:** `release_notes.json` contiene versiones publicadas y entregas previstas. La ventana Cambios carga el historial como texto seguro y lo pagina; debe actualizarse junto con cada cambio de versión que se sube a `main`.

- **Interfaz minimalista (Alfa 0.20):** el mapa 3D llena el área de juego. Un dock flotante abre ventanas modales para construcción, informe urbano, economía, contratos, acontecimientos y cambios. Los elementos funcionales se mueven al popup en lugar de duplicarse, para conservar IDs y listeners existentes. El historial lista Alfa 0.1–0.20 en páginas de cinco versiones. Para 0.1–0.9 se muestra explícitamente que no hay notas recuperables; no se inventan detalles.

- **Seguimiento de desempleo (Alfa 0.21):** cada residente activo conserva `unemployedSinceDay`, causa y empleador previo mientras busca. Al tomar una vacante registra días de búsqueda, empleador de destino y episodio. El informe cuenta personas activas buscando, vacantes sin asignar, promedio y duración máxima. LAN usa empleos conectados por ruta; Offline mantiene su asignación aproximada por distancia Manhattan. Los campos nuevos se agregan al migrar y el guardado sube a esquema 17.

- **Compatibilidad laboral (Alfa 0.22):** cada residente trabajador recibe niveles deterministas de comercio, administración y logística, además de un salario mínimo esperado. Los puestos iniciales exigen un nivel básico y salario suficiente; se conservan vacantes si no hay candidato accesible y compatible. Habilidades se derivan establemente del ID al migrar, y el guardado sube a esquema 18. En esa entrega la formación aún no estaba modelada; Alfa 0.23 agrega una capacitación municipal inicial, pero deja pendiente la educación formal y negociación salarial.

- **Formación laboral municipal (Alfa 0.23):** cursos temporales usan un centro cívico operativo como aula. Comercio, administración y logística seleccionan hasta seis residentes trabajadores con habilidad bajo el requisito y ruta desde su hogar. El gobierno prepaga dos ciclos mensuales a $180 de costo base más $40 por participante al mes; cada ciclo acredita 18 puntos de habilidad y descuenta del saldo reservado. Un aula cerrada o cohorte sin acceso vial pausa el curso; reanudar exige acceso y cancelar devuelve el saldo no gastado. Los IDs, cohorte, habilidad, saldo y estado se guardan en esquema 19. Offline reproduce la regla con BFS sobre la cuadrícula de calles; el aula no simula docentes, currículo ni escalas educativas.

- **Elección modal inicial (Alfa 0.24):** cada desplazamiento laboral elegible conserva origen, destino, motivo y ventana 07:00–09:00. Con menos de cuatro tramos viales entre edificios se camina; para distancias mayores se usa auto. El tiempo puerta a puerta suma acceso (2 min), espera (3 min en auto), recorrido (4 min/tramo a pie o 2,5 min/tramo en auto ajustado por congestión) y estacionamiento (2 min en auto). Los autos transportan una media modelada de 1,4 viajeros y generan el flujo de congestión; la escena representa los grupos a pie con peatones. Emisiones diarias se estiman a 0,18 kg por vehículo y tramo en cada sentido. Offline usa BFS y el mismo umbral pero sin congestión dinámica. Aún no modelamos posesión/compra/costo de auto, tarifas, bus, tren, carga ni tiempos elegidos individualmente.

- **Autobuses por corredor (Alfa 0.25):** se ofrecen pares origen–puesto que ya tienen viajeros y ruta vial; la línea usa la ruta más corta disponible y sirve sus dos extremos. Se pueden comprar hasta tres colectivos por línea a $700 cada uno, 30 plazas cada uno. La frecuencia se calcula como el tiempo de vuelta de 3,6 min/tramo dividido entre flota (mínimo 6 min). El bus cobra $0,25 por viaje y prefiere usarse si su tiempo generalizado (acceso, media frecuencia, marcha y tarifa) es menor que el del auto. La operación incluye combustible, mantenimiento y operador contratado no personificado por $140/bus/mes; los hogares pagan boletos hasta su caja disponible y la taquilla real se acredita a tesorería. La capacidad limita pasajeros; los buses ocupan ruta y animación 3D. Calles desconectadas pausan el servicio; pausar suspende gasto y tarifa, reanudar recalcula la ruta, retirar recupera 50% del valor de compra. Offline replica BFS y flujo de caja. Conductores como residentes, paradas intermedias y transbordos quedan pendientes.

- **Paradas compartidas de autobús (Alfa 0.26):** cada corredor registra una parada en cada edificio residencial, comercial o público cuya parcela esté a un tramo del recorrido vial. La línea puede atender viajes distintos al par de edificios que originó la oferta si ambos extremos quedan a dos tramos caminando en total, la dirección del recorrido es posible y su tiempo generalizado vence al modo preferido antes de abrirse la línea (a pie o auto). El cálculo suma caminata de acceso, media frecuencia, distancia viajada por la línea y tarifa; pasajeros y flota comparten el aforo total de la línea durante la ventana laboral. Paradas derivadas se recalculan desde edificios y calles al actualizar servicio, así que no se duplican al guardar y cargar. Son puntos de abordaje abstractos, no obras físicas; aún faltan paradas construibles, personal conductor y transbordos entre líneas. Online y Offline aplican la misma regla, con BFS en Offline.

- **Paradas físicas de colectivo (Alfa 0.27):** se guardan como edificios normales de servicio con tipo `busStop`, y la obra retiene `busLineId` durante licitación/rescate. La sede debe estar sobre parcela vacía contigua a una calle del corredor activo; al finalizar, el trazado vial del servicio visita estaciones construidas en orden. Reutiliza el pipeline de contratos, cuadrillas, materiales y etapas de Online, mientras Offline mantiene ceros de consumo material conforme a su modelo local. Mantenimiento municipal: $25/mes por parada habilitada.

- **Salas LAN Alfa 0.28:** el servidor Python ya abierto por el iniciador recibe `POST /api/room/create` solo desde loopback. Los invitados usan `POST /api/room/join` con código opcional o navegan a la IP local del anfitrión. UDP en puerto 8766 anuncia salas cada tres segundos y olvida anuncios luego de 12 segundos. `/api/rooms` expone las salas vistas por ese servidor local. El navegador servido por Vercel puede navegar a la IP del anfitrión, pero no puede escuchar UDP ni alojar la simulación; no hay servidor público ni servicio externo.
- **Audio y render Alfa 0.28:** tonos cortos Web Audio se inician tras interacción del usuario, con preferencia de silencio en `localStorage`. El colectivo tiene geometría propia y animación sobre rutas existentes. La densidad de píxeles queda acotada a 1,55 en escritorio y 1,2 en móvil para equilibrar nitidez y rendimiento.

- **Dotación de colectivos Alfa 0.29:** cada colectivo activo exige un residente con logística ≥42, salario esperado ≤$10 y camino al origen. El conductor conserva un empleador exclusivo y el turno pico 07:00–09:00 / 17:00–19:00. La flota efectiva se deriva de contrataciones, no de compras; el gasto de $140/vehículo/mes incluye su salario de $10 y operación, para evitar doble contabilizar nómina. Horarios de otras franjas y relevos aún no se modelan.

- **Cochera Alfa 0.30:** proyecto público de 40 días base, costo base $4200, seis obreros y materiales definidos por tipo. Cada edificio habilitado tiene cuatro plazas; las líneas con conductor se ordenan por ID y toman plazas de la cochera conectada más cercana a su origen. La operación de una unidad alojada cuesta $110/mes, frente a $140 en una plaza alquilada; el edificio suma $50/mes al gasto fijo. La flota no pierde servicio si faltan plazas: usa alquiler. El cálculo derivado evita guardar ocupaciones duplicadas.

- **Turnos de transporte Alfa 0.31:** cada vehículo requiere dos residentes cualificados y sin otro empleo, uno asignado a 07:00–09:00 y otro a 17:00–19:00. Se contrata solo el número par de personas necesario para unidades completas; una candidatura sobrante queda libre. La flota efectiva se deriva de parejas de turnos. Cada conductor cobra $10/mes al hogar dentro del costo operativo ya existente de $140 por vehículo, o $110 con cochera. La demanda laboral modelada corresponde a la ida matutina; el regreso se representa por el segundo turno y los 44 viajes mensuales por pasajero, sin simular aún su ruta separada.

- **Transbordos Alfa 0.32:** el selector de movilidad busca recorridos directos o de dos líneas con una parada `busStop` habilitada a una casilla o menos de ambas rutas. Respeta la dirección de cada línea y el aforo de ambos tramos. Suma acceso a pie, media espera de cada línea, caminata de intercambio, recorrido y dos tarifas. El viaje se asigna si mejora el modo de referencia o, para un intercambio, si no supera 1,5 veces la caminata de un residente sin auto ni 1,25 veces el tiempo de uno con auto; esto representa preferencia por viajar sentado y costo de usar auto, aún sin modelar propiedad del vehículo. El acceso al auto se deriva de un hash estable del ID (65% de adultos trabajadores) y se conserva en el guardado. Cada línea cobra $0,25 por viaje de tramo y ocupa una plaza; no hay billete integrado. El regreso vespertino no tiene ruta separada todavía. La búsqueda de pares de líneas deberá optimizarse para mapas grandes.

- **Billete integrado Alfa 0.33:** el segundo tramo de un transbordo cobra el 40% de la tarifa de esa línea, redondeado a centavos. Con tarifa base $0,25, los tramos son $0,25 + $0,10 = $0,35. Cada trabajador conserva `busLegFares` alineado con `busLineIds`; cada línea reserva una plaza y registra ingreso de su tramo. La previsión mensual suma las tarifas reales de los viajes de ida y vuelta para 22 días laborables y distribuye el redondeo a centavos por línea para que el total del hogar no se exceda por redondeos separados. El cierre LAN preserva los pagos efectivamente cobrados durante el mismo día ante recálculos de estado. Si el hogar tiene menos caja, solo se recauda lo disponible.

- **Regreso vespertino Alfa 0.34:** cada grupo laboral genera un viaje separado 17:00–19:00 desde el empleo al hogar. Invierte el orden de líneas y el recorrido matutino, y reserva cupo en un contador de retorno independiente. Si una línea se pausa o la vuelta completa su aforo, el residente vuelve a pie o en auto conforme al acceso que tiene. El retorno aplica $0,25 a la primera línea y el 40% del tramo integrado siguiente. Por pasajero se cobra la suma de ambos sentidos durante 22 días; el redondeo doméstico se reparte entre las líneas según sus centavos para conservar el total. El catálogo de corredores evita contar la ruta inversa como una nueva demanda. Los vehículos de bus recorren la ruta en ambas direcciones. No hay horarios intermedios, transbordo de más de dos líneas ni trenes aún.

- **Horarios de colectivos Alfa 0.35:** el día de servicio va de 05:00 a 23:00 en nueve ventanas consecutivas de dos horas. La frecuencia base es la duración del recorrido más un margen de terminal, dividida por flota activa; cada ventana aplica un multiplicador (pico 1×, día/no pico hasta 1,75×, última salida 2×). Las salidas redondean hacia arriba el intervalo; los asientos son 30 por salida. Se cuentan por ventana y por sentido, sin mezclar pasajeros de la mañana y del regreso. Los IDs determinan de forma estable uno de tres turnos de salida y su retorno. Los dos turnos de conductores son 05:00–14:00 y 14:00–23:00. El costo base mensual del vehículo se conserva; cada salida no pico suma $0,08 durante 22 días. Es un modelo horario laboral agregado, sin relojes de minuto, pasajeros de compras ni trasbordos de más de dos líneas.

- **Viajes cotidianos Alfa 0.36:** añadir demanda no laboral con una regla pequeña y estable antes de ampliar detalle: un grupo por hogar ocupado, con pasajeros aproximados al 12% de sus residentes (mínimo uno, máximo tres), comercio abierto alcanzable priorizado por distancia y ventas locales recientes, y destino rotado entre hasta tres alternativas. El grupo camina hasta tres tramos o usa auto si la familia tiene suficiente acceso. El viaje representa ida y vuelta en el flujo vial y emisiones, sin volver a debitar compras. Es un agregado diario; no representa actividad individual ni horarios exactos. Offline replica el selector.

- **Viajes a servicios Alfa 0.37:** utilizar edificios cívicos ya habilitados como destinos diarios, sin inventar una tarifa ni reaplicar compras. Cada hogar accesible genera un grupo pequeño (5% de ocupación, mínimo uno, máximo dos), prioriza cercanía y rota entre hasta dos centros. El motivo, sus flujos, pasajeros y emisiones se mantienen separados de compras. El modelo se duplica en Offline.

- **Navegación Ciudad Alfa 0.37:** el acceso del dock siempre abre el panel general y restablece la subcategoría Resumen, independiente de la parcela seleccionada. La ficha de parcela no debe interceptar la navegación de categoría. Los indicadores de búsqueda/puestos se alojan en la subcategoría Empleo para evitar que el Resumen exceda el popup móvil.

- **Puerto comercial Alfa 0.38 (fase 23, parcial):** una sola terminal se construye en x=23, junto al agua del borde este, con ruta vial y contrato largo. Ventas regionales realmente liquidadas generan carga por comercio; el envío recorre la red vial, se detiene si falta acceso o espacio en patio, y se conserva en inventario del muelle. Patio 500, buque 180, despacho al reunir 60 unidades con intervalo mínimo de 10 días, viaje de dos días y tasa municipal $0,60/unidad. Operación $320/mes y 12 puestos logísticos. Los guardados pasan a esquema 22. No hay importaciones, selección de carga, calado, dragado, grúas con capacidad variable, llegada/atraque con colas, tren de carga ni competencia regional; la fase sigue parcial.

- **Aeropuerto Alfa 0.39 (fase 24, parcial):** aeropuerto regional único en parcela conectada a la red vial, contrato municipal de cinco etapas (112 días/$19.500 base), 16 trabajadores y materiales Online. Edificio habilitado: terminal 800 pasajeros/mes, pista 12 vuelos/mes, 18 empleos y $600/mes de operación. El objetivo de empleo admite hasta esas plazas nuevas y el aeropuerto ofrece $12/mes para atraer personal. La aerolínea activa requiere acceso vial, cuatro empleados y demanda; 80 asientos/vuelo, hasta 12 vuelos, $70/pasajero de ingreso modelado y $500/vuelo de costo. Tasas municipales: $4/pasajero y $75/vuelo. La mitad de pasajeros llega como visitante; hasta 65% genera compras, limitadas por acceso e inventario. No hay activos financieros persistentes de la aerolínea, vuelos con hora, carga aérea, clima, ruido por barrio ni transporte terrestre dedicado. Guardado esquema 23.

- **Turismo y hoteles Alfa 0.40 (fase 25, parcial):** inversión del hotel privado financiada por capital promotor más permiso municipal; proyecto de cinco etapas, 76 días base, materiales Online, 24 habitaciones, 48 camas y 10 empleos. La demanda asigna hasta el 45% de llegadas como huéspedes únicamente con aeropuerto operativo y conexión vial. Cada huésped modela dos noches y $90 de tarifa inicial, ajustada entre $55 y $180 por ocupación. La empresa paga nómina, insumos ($18 por huésped) y $260 de costos fijos; aporta impuesto municipal del 5% sobre ingresos. El agotamiento de la caja cierra el negocio y despiden sus puestos. Online y Offline siguen el mismo circuito agregado. No hay estaciones, eventos, atractivos patrimoniales/naturales, alquiler temporario ni externalidades de congestión/servicios. Guardado esquema 24.


- **Redes de energía y agua Alfa 0.41 (fase 26, parcial):** guardado esquema 26. `utilities.powerLines` y `utilities.waterPipes` registran coordenadas sobre calles; una BFS desde el suministro inicial distingue tramos conectados de islas físicas. La red heredada se migra con las calles actuales conectadas. Demanda diaria y eléctrica se asigna por prioridad cívica/residencial; el déficit desconectado cuenta como no atendido. Capacidades base: 1.200 kW y 180 m³/día; pérdidas: 6% eléctrica y fuga: 8% agua. Verano suma 10% y 12% de consumo respectivamente. Fuentes nuevas solo cuentan con acceso físico a ambas redes. La cobertura menor a 85% erosiona servicios y debajo de 65% también aprobación al pasar el mes; tiendas/hoteles multiplican producción por cobertura y vuelos exigen al menos 65%. El mantenimiento de red se deriva de tramos conectados. Online y Offline replican la fórmula; aún no hay saneamiento, drenaje, residuos, gas, telecomunicaciones, fallas probabilísticas ni reparación.


- **Cloacas Alfa 0.42 (fase 26, parcial):** guardado esquema 27. `utilities.sewerLines` es una red independiente. El caudal generado por edificio equivale al 80% del agua suministrada. La fracción conectada se depura hasta `baseWastewaterTreatmentM3Day` (180 m³/día) más plantas operativas; cada planta requiere conexión física a energía, agua y colector, y aporta hasta 260 m³/día. El flujo no conectado o que excede capacidad se suma como descarga sin tratar y no desaparece. Por debajo de 90% de cobertura la ciudad pierde un punto de servicios mensual; por debajo de 65% también pierde aprobación. La falta de saneamiento reduce el factor de actividad de negocios y turismo. El mantenimiento de colectores es $0,90/tramo/mes. No representa todavía composición contaminante ni destino de efluentes.

- **Drenaje pluvial (Alfa 0.43):** red independiente de las cloacas, conectada por tramos de calle desde la salida regional. Cada tramo cuesta $155 y mantiene $0,70/mes; la capacidad base es 3.300 m³/día más 18 m³/día por tramo. Ciclo determinista de 24 días: días 7 y 8 con 5 mm, día 18 con 18 mm. La escorrentía depende de la superficie vial/edificada y una aproximación reproducible de elevación. El agua desconectada o excedente anega parcelas; las tormentas dañan edificios, hogares, negocios y activos viales, con costo, deterioro, servicios y aprobación afectados. Online y Offline comparten cálculo y migración de guardados al esquema 28.

- **Residuos municipales (Alfa 0.44, fase 26 parcial):** el servicio inicial recoge 1,15 t/día; hogares generan 1,15 kg/residente/día, comercios 1,15 kg/trabajador/día, servicios públicos 0,75 kg/empleado/día y huéspedes 1,5 kg por noche aproximada. Depósitos logísticos conectados aportan 1 camión y 0,75 t/día de capacidad por instalación. El relleno regional tiene 900 t de capacidad inicial. Cada relleno sanitario contratado (cinco etapas, 72 días base, $9.800, 12 empleos) agrega 1.800 t y cuesta $420/mes. El servicio tiene una base de $280/mes, $160 por camión adicional y $7,50 por tonelada recolectada/día, mensualizada ×30. La cantidad que excede flota o cupo persiste como basura sin recoger; se representa en hasta 18 parcelas. Al pasar 3,5% de la población en toneladas (mínimo 8 t), servicios bajan un punto mensual; al superar 12% (mínimo 30 t), aprobación pierde un punto también. Ampliar el relleno permite recoger retrasos acumulados. Online y Offline comparten migración al esquema 29. No se simulan todavía rutas por turno, contenedores, transferencia ni reciclaje selectivo.

- **Reciclaje (Alfa 0.45, fase 26 parcial):** guardado esquema 30. Cada planta pública conectada por calle recupera `min(recolección × 35%, capacidad instalada)` hasta 1,25 t/día. El tonelaje recuperado no ocupa relleno y genera $18/t de venta mensualizada; la planta requiere 32 kW, 6 m³/día, 16 puestos, y cuesta $650/mes. El flujo no recuperado ocupa relleno con el balance ya existente. Las cifras son un primer circuito económico; no hay clasificación por material, mercado privado ni logística de contenedores.

- **Gas y telecomunicaciones (Alfa 0.46, fase 26 parcial):** esquema 31; ambas redes guardan coordenadas por tramo vial y resuelven continuidad con BFS desde (4,10). Base de gas 240 m³/día y telecomunicaciones 500 Mbps; cada segmento conectado añade 4 m³/día o 8 Mbps. Demanda por uso y ocupación; mantenimiento de $1,10 y $0,60 por tramo/mes. Los comercios y hoteles multiplican operación por el menor porcentaje de electricidad, agua, tratamiento cloacal, gas y telecomunicaciones. Online/Offline usan las mismas reglas y los guardados previos se completan en la migración.

- **Averías y reparación (Alfa 0.47, fase 26 parcial):** esquema 32; la inundación daña como máximo un tramo conectado por episodio de tormenta, solo si la calzada del tendido aparece entre las parcelas inundadas. La avería se conserva con causa, coordenada y estado; BFS ignora segmentos cuyo estado no es reparada. Reparación con gasto compartido en el momento de asignación ($720 electricidad, $640 agua, $690 cloacas, $580 gas, $460 telecom), tres días de cuadrilla y restauración al completar. No se restaura capacidad en plantas ni se añade redundancia ficticia. Online/Offline comparten reglas.

- **Residuos logísticos (Alfa 0.48, fase 26 parcial):** esquema 33. Un contenedor instalado sobre calle suma 0,15 t/día a la capacidad de recolección por $350 de capital municipal. Un depósito operativo con ruta conectada actúa también como estación de transferencia de 12 t, con salida de 1,5 t/día; si el buffer se llena, la entrada sobrante vuelve al retraso urbano; lo ya almacenado permanece en el buffer cuando no hay salida suficiente. Sin estación, se conserva el procesamiento directo previo. Contenedores, saldo de transferencia e impacto se guardan en ambos modos.


- **Alfa 0.49 · respaldo crítico:** los edificios `civic`, `waterPlant` y `wastewaterPlant` pueden instalar un grupo de hasta 75 kW. Su depósito representa kWh de combustible, se consume a razón de potencia respaldada × 24 h al avanzar un día y se repone a $0,12/kWh. Instalación y tres días iniciales cuestan $2.800; mantenimiento añade $70/mes. El respaldo suma a la cobertura de potencia solo para ese edificio. No se habilita a hogares ni comercios. Online y Offline usan iguales costos, límites y estados.


- **Alfa 0.50 · rutas de residuos:** los camiones se originan en la base municipal y depósitos alcanzables por calle. Un BFS asigna contenedores a la ruta viable de menor costo; cada recorrido termina en transferencia (camiones de depósito) o destino alcanzable y vuelve al origen. La capacidad efectiva por ruta es 1,15 t/día para el camión municipal y 0,75 t/día por camión de depósito; cada parada alcanzable añade 0,15 t/día. Cada contenedor tiene 2 t de almacenamiento y produce hasta 0,15 t/día de la generación municipal; el camión retira hasta 0,15 t/día por parada. Si no hay ruta, el almacenamiento se acumula y el desborde alimenta la basura urbana pendiente. La asignación y costos son automáticos, sin una pantalla de edición de rutas.


- **Alfa 0.51 · alerta y preparación climática:** el escenario actual es una costa templada; el ciclo hidrológico ya definido anuncia una tormenta de 18 mm cinco días antes. La previsión calcula escorrentía esperada con el suelo, techos/calles y tendidos pluviales presentes, clasifica riesgo por volumen expuesto y conserva activos destacados. El despliegue cuesta $850, se asigna a una única fecha y agrega capacidad temporal de bombeo equivalente al 25% de la red durante ese día. El registro compara pronóstico, agua y parcelas realmente afectadas; no se presenta como probabilidad ni se extrapola a otras regiones. Online y Offline usan el mismo ciclo.


- **Alfa 0.52 · recuperación de activos públicos:** cada tormenta crea un expediente por tramo vial y edificio municipal que recibió daño. El equipo técnico cobra $150 y trabaja un día de juego antes de habilitar la licitación. Las tres constructoras ofrecen precio multiplicado por su perfil y plazo derivado de su tasa base; aceptar descuenta el contrato completo, ocupa cuatro trabajadores y consume un cupo de obra hasta terminar. La obra dura 3–5 días. Al finalizar devuelve el activo a calidad 82 y marca el expediente reparado. Los daños de hogares y empresas siguen por cuenta privada; cortes de redes continúan en el panel de Servicios.


- **Alfa 0.53 · episodios de calor y sequía (fase 27, parcial):** ciclo determinista de 360 días: calor en el día 25 del año (5 días) y sequía desde el día 46 (30 días), con alerta cinco días antes. La intensidad de salud varía con el terreno y la sombra generada por los árboles del mapa. El calor multiplica consumo eléctrico por 1,22 e hídrico por 1,18; los refugios requieren un centro cívico conectado por calle, personal y electricidad y cuestan $650. La sequía reduce a 55% la captación de base; asignación por prioridad existente deja los hogares expuestos a cobertura incompleta. Restricciones reducen 35% agua comercial y el factor de actividad de comercios/hoteles 12%; cisternas cuestan $1.200 y agregan 30 m³/día durante diez días. Es un único clima regional, no un modelo probabilístico ni una simulación climática global. Esquema 38; Online y Offline conservan costos, ventanas y efectos.


- **Alfa 0.54 · atención primaria/urgente (fase 28, parcial):** `civic` es centro sanitario y contrata trabajadores que alcanzan habilidad `salud` ≥48. Se migran perfiles existentes con un valor estable; la formación municipal sube 18 puntos por ciclo, hasta seis alumnos durante dos meses, con $420/ciclo prepagados. El centro inicial tiene 12 vacantes; una obra nueva, 16. Por profesional: 2,2 consultas primarias y 0,35 urgencias al día, multiplicadas por el mínimo de cobertura eléctrica/agua/cloacas. Los residentes se asignan al centro vial más cercano (máximo 45 min); el desborde primario genera cola con tope de 25% de población. Déficits sostenidos afectan servicios/apoyo una vez por mes. Cada consulta primaria cuesta $0,65 y una urgencia $2,40 en insumos; la facturación se incluye en balance mensual. El riesgo sanitario por agua/cloacas usa la seguridad mínima de ambas redes promediada por hogar durante 30 días para que una mejora tenga rezago. No hay edades, camas, ambulancias, diagnóstico ni tratamientos sensibles. Esquema 39; los mismos perfiles, costes, colas y accesos aplican Offline/Online.


- **Alfa 0.55 · educación pública (fase 28, parcial):** edificios `school` tienen cuatro aulas, 12 vacantes `educacion` (habilidad mínima 48) y salario $12. Cada plaza aporta hasta 18 alumnos y cada aula admite 24; capacidad final es el mínimo multiplicado por el peor servicio de energía/agua/cloacas. Los estudiantes de 5–17 años se asignan al establecimiento alcanzable más cercano por calle (≤40 minutos); una sola escuela puede registrar el exceso como espera. Operación $820/mes, insumos $0,35 por alumno/mes. En cada cierre mensual, estudiantes asistidos progresan; luego de 12 meses mejoran dos puntos en cada perfil laboral. No se mueven trabajadores a la categoría infantil para conservar el estado laboral existente; edad escolar se simula sobre residentes no elegibles para el mercado. Esquema 40. Capacidad educativa y nómina en ambos modos; compras y entregas de materiales pendientes en Offline.


## Bomberos y respuesta a incendios · Alfa 0.56

- El esquema pasa a 41, con migración aditiva `fireService`; ciudades antiguas inician contadores e historial vacíos. La mecánica se resuelve en el anfitrión Online y en la simulación Offline.
- El control mensual determinista aplica riesgo base 12%, más 2 puntos porcentuales por cada inmueble elegible y aumentos por calor/sequía; tope 82%. Hash estable selecciona el inmueble, con un máximo de un incidente en curso.
- La estación se construye como obra pública de $11.200 y 74 días base; Online usa el flujo de materiales existente. Offline no simula compra/entrega de materiales, limitación declarada en sus detalles de proyecto.
- Doce puestos requieren perfil Bomberos ≥48. Cuatro personas conforman una dotación, hasta tres por cuartel. Solo personal y ruta vial conectada habilitan respuesta; se escoge la opción más rápida y se calcula el tiempo como 5 min + 2,5 min por tramo. Cada salida bloquea el edificio por dos días.
- Daño por respuesta rápida: redondeo de tiempo/5, entre 1 y 18 puntos de condición. Sin respuesta el edificio pierde 2 puntos/día; al quinto día, servicios −2 y aprobación −1. Los hogares/negocios absorben pérdida de caja privada; no se simulan lesiones ni fallecimientos.
- Los controles de Ciudad muestran cobertura vial (hasta 14 tramos), disponibilidad de dotación y últimas llamadas. El camión 3D recorre la ruta un día de juego después del despacho; un incendio activo tiene marcador visual. Estas representaciones derivan del estado de incidentes y no alteran sus resultados.
- El costo operativo es $950/mes al habilitar el edificio; la nómina es un gasto público normal. No se factura combustible ni se simulan tipos de vehículo/equipo por separado todavía.


## Alfa 0.58 · hacienda inicial

El préstamo municipal usa amortización fija con interés del 1% mensual y plazos cerrados de 24 o 48 meses. Los montos se ofrecen en tres tramos; la solvencia limita la deuda total a $40.000 o ocho meses de ingresos de referencia (el menor) y el servicio mensual combinado no puede exceder 35% del ingreso. La proyección a 12/48 meses congela el flujo operativo actual y pagos mensuales; es una referencia, no pronóstico con crecimiento/inflación. Las obligaciones se comparten en el estado autoritativo Online y se persisten en el guardado Offline. Si la caja mensual no cubre gastos y deuda, la cuota se difiere y se marca mora; no se crea sobregiro.


## Alfa 0.62 · catálogo patrimonial y rehabilitación

- Ocho inmuebles iniciales con valor reconocible tienen años de fundación entre 1942 y 1968. El resto del parque recibe época y arquetipo contemporáneo; los futuros edificios toman el año actual cuando se migra el estado. El catálogo persiste uso original, reformas, condición, relevancia y ocupación.
- Protección parcial/integral no cambia de inmediato el uso ni expulsa residentes. La integral aporta mayor peso a la identidad; ambas reducen de 3 a 2 puntos la degradación anual, que continúa si el municipio no financia obras.
- La rehabilitación es contrato municipal pagado al adjudicar. Cuatro trabajadores y capacidad real de la constructora quedan ocupados; las cantidades de acero, madera, componentes y áridos se descuentan del stock del proveedor elegido por disponibilidad y costo. La obra espera la entrega y después avanza durante su plazo; completar deja registro, mejora conservación según calidad y libera cuadrilla. Online y Offline comparten validaciones; guardados pasan a esquema 46.

## Alfa 0.61 · presupuestos operativos municipales

- Tres programas presupuestarios agrupan gastos existentes: servicios (operación cívica, nómina e insumos sanitarios/escolares), redes y residuos (mantenimiento de redes y operación de residuos), y movilidad (operación de colectivos). Cada uno guarda asignación de 0–200%, mora y un historial limitado de cierres.
- El pago mensual se limita por asignación y caja libre; la mora no crea deuda bancaria ni se acredita como gasto pagado. El excedente sobre el costo corriente reduce mora previa. La reserva de deuda introducida en Alfa 0.60 liquida su cuota después de los programas para preservar compromisos programados.
- Los efectos funcionales se expresan como factores de servicio/capacidad aplicados a redes, residuos, salud/educación y buses. Las vistas Online y Offline aplican el mismo orden de liquidación y valores por defecto; migración de guardados al esquema 45.

## Alfa 0.59 · recaudación por caja

El impuesto inmobiliario anual usa una base de diseño de $2.400 por residente y se divide en doce vencimientos; el gravamen comercial aplica al porcentaje de ventas del mes, separado del impuesto turístico hotelero existente. Las facturas se cobran después de pagar salarios y realizar actividad mensual, desde el efectivo remanente. Pago parcial reduce la caja solo por lo cobrado y conserva el resto en `taxes.arrearsByAsset`; solo cobros entran al flujo municipal. La liquidación registra el mes procesado para impedir duplicación. Los topes de tasa permiten probar carga fiscal sin tasas arbitrarias sin límite.

- **Fondo municipal de deuda (Alfa 0.60):** caja reservada queda fuera de la caja libre y de los fondos disponibles para contratar; aportes solo toman efectivo no comprometido. Al cierre mensual se usa únicamente para completar el servicio contractual completo, sin crear pagos parciales. La mora y los fondos no gastados se conservan. Migración de guardados al esquema 44.

## Alfa 0.63 · cartera de mantenimiento vial

- Cada tramo conserva condición y recibe un factor de uso derivado de edificios adyacentes y grado de conexión. Se evita un desgaste uniforme: por mes cae entre 0,34 y 0,58 puntos según carga aproximada.
- La política preventiva municipal usa 0–200% en incrementos de 25; el costo de referencia es $12–$20 por tramo/mes según carga. El gasto se incluye en Redes y residuos y recibe el mismo límite de asignación y caja que el resto del programa. El factor efectivamente financiado limita la recuperación de condición.
- Una red con al menos 35% de sus tramos bajo 45% pierde un punto de servicios por cierre mensual; el mantenimiento no rescata calles afectadas por desastre, que conservan el sistema de inspección y contratos de recuperación. Es una primera capa de fase 31, aún sin suspensión temporal de calles. Online/Offline, esquema 47.

## Alfa 0.64 · rehabilitación correctiva de edificios públicos

- El ciclo de fase 31 abarca calles y activos municipales operativos (salud, educación, bomberos, logística, redes y terminales). Los edificios pierden entre 0,28 y 0,48 puntos de condición al mes según dotación y ocupación; el plan general y el pago efectivo del programa Redes compensan el desgaste. Su mantenimiento de rutina se suma a la factura mensual del programa.
- Bajo 60% se crea un expediente de deterioro con causa, condición y presupuesto. La inspección municipal cuesta $150 y ocupa un día; el informe habilita tres ofertas. La adjudicación respeta caja comprometida, liquidez del contratista y cuatro trabajadores, cobra al inicio, dura según contratista y restablece la condición del activo a 82% al inspeccionarse. El mismo contrato sirve para daños por tormenta y deterioro.
- Si 25% de los edificios públicos queda bajo 60%, igual que la regla vial, el nivel de servicios pierde un punto por cierre mensual hasta corregir la cartera. El panel de mantenimiento tiene subpestañas para no mezclar inventarios; guardados migran al esquema 48.


## Alfa 0.65 · degradación física de redes

- Cada tramo mantiene condición en `utilities.lineConditions` con clave de red y coordenadas. Las seis redes (electricidad, agua, cloacas, pluvial, gas y fibra) comparten estados compatibles Online/Offline y la migración al esquema 49 inicializa los tramos existentes en 82%.
- El desgaste mensual sube con edificios cercanos. El factor efectivamente pagado por Redes reduce el desgaste; no existe colapso aleatorio. Bajo 25% se registra una avería persistente, se interrumpe el tendido en ese segmento y la reparación municipal tiene costo según condición y plazo de tres días.
- La interfaz muestra promedio y cantidad de tramos críticos por red. El reporte no duplica los inventarios; deriva la condición desde el registro persistente.


## Alfa 0.66 · cierres de seguridad vial

- La condición menor a 25% cierra la calle sin borrarla del catastro. `route_between` y `offlineRoadRoute` excluyen ese segmento, de modo que todo destino busca ruta alternativa y devuelve sin acceso si no existe. El corredor de colectivos se vuelve a trazar contra la red abierta.
- La inspección y el contrato de rehabilitación ya existentes operan el activo cerrado; la recepción final retorna condición 82% y reabre el tramo. Barreras renderizadas se derivan de los mismos valores persistentes para evitar un estado visual desincronizado.
- No se crea una entidad puente ficticia: el mapa procedural actual no tiene agua interior ni margen opuesta conectable. El sistema de puentes requiere ampliar geografía y conectividad del mapa primero.

- **Capacidad de plantas y condición (Alfa 0.67):** centrales eléctricas, potabilizadoras y depuradoras tienen salida efectiva proporcional a `quality / 82`, limitada a 0–100%. El 82% inicial es capacidad de diseño; sus valores alimentan los balances de red y los porcentajes servidos. La rehabilitación existente vuelve a 82%. Se eligió para que mantenimiento cambie suministro real sin crear una mecánica paralela de fallas. No reemplaza inspección periódica: sigue pendiente la programación preventiva por edad/criticidad. Guardado esquema 51.

- **Inspección periódica de plantas (Alfa 0.68):** las centrales, potabilizadoras y depuradoras persisten `inspectionIntervalDays=180`, `nextInspectionDay` y `lastInspectionDay`. La cartera se revisa al cierre mensual; vencido el plazo crea un expediente preventivo con la condición/estimación de costo actuales. Inspección cuesta $150 y dura un día. Si la condición sigue ≥82%, el expediente se cierra sin contrato y se agenda el siguiente control; bajo 82% continúa por adjudicación/rehabilitación ya existente. La reparación reinicia el calendario y retorna calidad a 82%. Al migrar partidas, el primer control queda 180 días después del día actual. Es un piloto para activos críticos; otros edificios, redes y propietarios privados quedan fuera del calendario. Guardado esquema 52.

- **Fase 30 · reconversión privada (esquema 53):** solo locales cerrados sin deuda bancaria o tributaria y fuera del catálogo patrimonial pueden cambiar a vivienda. El permiso suma $200 al municipio; se descuentan $4.200 del capital privado y se transfieren al contratista. Cuatro trabajadores ocupan capacidad real de una empresa durante 20–30 días; el edificio conserva su parcela y solo cambia a vivienda tras inspección de habitabilidad. Gana 24 plazas, que la migración existente ocupa si hay vacantes y empleo. Cada nuevo hogar registra su día de mudanza y paga $24 por residente solo tras cumplir 30 días en la vivienda; la deuda impaga se acumula y, desde $600, reduce aprobación; la mora acumulada reduce aprobación al alcanzar $600.


## Alfa 0.70 · mandato y escrutinio por distrito (fase 32, parcial)

- El calendario usa 360 días por año de juego y celebra elecciones al completar 1.440 días de mandato. Las partidas ya existentes comienzan su primer ciclo electoral cuatro años después de la migración, sin adelantar comicios por cargar un guardado antiguo.
- Los distritos Oeste, Centro y Puerto derivan su población de hogares según coordenada X (<10, 10–17, ≥18). El apoyo combina aprobación municipal (28%), empleo local (24%), servicios (25%) y vivienda (23%). El desempleo se obtiene de los residentes elegibles; vivienda combina ocupación/capacidad y calidad. Se señala el factor más rezagado para orientar la gestión.
- El escrutinio usa 72% de participación en cada distrito y los votos previstos por su apoyo; no incluye un componente aleatorio. Una mayoría simple renueva el mandato por cuatro años. Una derrota persiste en la partida compartida, la pausa automáticamente y bloquea acciones de gobierno; cargar/guardar sigue disponible. Un anfitrión puede iniciar otra ciudad.
- `government` persiste mandato, calendario, estado e historial resumido de elecciones en el guardado esquema 54; `governmentReport` es una vista derivada del mismo estado anfitrión para Online y del estado local para Offline. Los resultados conservan voto/participación por distrito y motivos agregados. La derrota del equipo es única, no individual. Las pruebas actuales modelan el padrón como población residente, ya que las fichas aún no conservan edad cívica individual; esta limitación queda visible en la documentación y no debe confundirse con un padrón demográfico completo. El sistema cubre elecciones ordinarias; faltan plan municipal con objetivos, reclamos, confianza desagregada y mecanismo extraordinario de destitución.
- UI: Ciudad > Gobierno. La rejilla de categorías limita su altura y permite desplazamiento propio; las tarjetas del distrito se apilan en móvil y el cuerpo del popup conserva el desplazamiento vertical.


## Alfa 0.71 · plan, reclamos y crisis extraordinaria (fase 32, parcial)

- Cada mandato recibe metas a partir del estado al inicio: empleo formal = referencia +5 puntos (acotado a 60–85%), reserva habitacional = referencia +3 puntos (5–20%) y cobertura de servicios = referencia +5 puntos (60–85%). El avance se mide mensualmente con residentes empleados, plazas libres/capacidad y cobertura municipal. El sondeo suma 2 puntos por meta cumplida y resta 1 por cada una pendiente; se guarda el desglose con el escrutinio. Al renovar, se fijan nuevos objetivos según las condiciones actuales.
- Un reclamo se abre por distrito si empleo cae bajo 55%, vivienda bajo 65%, servicios bajo 55% o apoyo bruto bajo 45%. El registro conserva causa, evidencia, fecha y meses abierto; se revisa al cierre mensual y se resuelve cuando supera el umbral. Mientras siga abierto descuenta 2 puntos de apoyo, más 0,5 por mes hasta un máximo adicional de 3. El historial conserva hasta 36 reclamos recientes. La generación es automática desde los problemas simulados, no por un formulario externo.
- Destitución extraordinaria exige simultáneamente caja municipal en cero, servicios ≤30% y apoyo promedio ponderado por población <35% durante tres cierres mensuales. Al segundo cierre se muestra advertencia; recuperar caja o cobertura antes del tercero reinicia el contador y registra que se superó la crisis. El desenlace pausa y bloquea decisiones de gobierno, pero deja guardar/observar.
- Metas, reclamos y crisis están dentro de `government` y se sincronizan como estado autoritativo del anfitrión. El informe de Gobierno deriva porcentajes y estados en ambos motores; esquema 55.


## Alfa 0.72 · acuerdos municipales y panel de roadmap

Los reclamos territoriales enlazan hasta cinco entidades existentes de la simulación; el enlace es evidencia contextual, no una acción de reparación nueva. Los jugadores registran un acuerdo por reclamo abierto y mandato. El anfitrión fija un plazo de 180 días y autor; los cierres mensuales lo cumplen si el reclamo se resuelve antes del vencimiento, o lo marcan vencido. Un vencimiento añade presión al apoyo local; cumplimientos/vencimientos afectan el escrutinio con límites para que varios acuerdos no dominen el resto de la gestión. La acción rechaza duplicados vigentes y reclama el estado compartido Online; Offline aplica las mismas reglas. Guardado esquema 56.

El historial usa `release_notes.json` como fuente del panel de 34 fases. El porcentaje es una estimación orientativa de alcance funcional: se compara el resumen de sistemas ya presentes con los pendientes identificados por la auditoría; se redondea a 5 puntos y 100% requiere verificar todos los criterios de aceptación del roadmap. No se calcula el total global promediando fases porque sus dependencias y pesos de alcance no son equivalentes. Los textos pendientes se muestran fase por fase para hacer revisable la estimación.

## Alfa 0.73 · evolución demográfica y rehabilitación privada (fase 33)

El año simulado tiene 360 días. Los perfiles de edad inicial se asignan determinísticamente para que la migración de un guardado no cambie la composición. Cada cambio de año ajusta edades, empleo y jubilación; los nacimientos se procesan cada cuatro años solo con espacio de vivienda y caja doméstica. Los inmuebles privados envejecen fuera de obra y generan una oportunidad de rehabilitación por debajo de 70% de condición. El inversor paga materiales y trabajo desde capital privado; se retira stock real de la empresa, se reserva una cuadrilla de cuatro y la municipalidad percibe $100 de permiso. La obra progresa diariamente, conserva el inmueble ocupado y requiere una etapa final de inspección.

Los valores (18/67 años, umbral de 70%, $180 por nacimiento, lote 4/2/2/1 y obra base de 30 días) son parámetros iniciales, no equilibrio final. Fase 33 está parcial: no se ha verificado una trayectoria de 30 años ni el conjunto de escenarios de aceptación. El esquema de guardado sube a 57 en Online y Offline.

**Verificación Alfa 0.73:** la prueba Online confirmó que una misma acción del anfitrión crea una obra y cobra el permiso una vez. Chromium comprobó el flujo Offline, la conservación local y que la tarjeta de renovación puede alcanzarse con desplazamiento móvil. La UI no presenta overflow horizontal en 390 ni en 1440 píxeles. Las pruebas no equivalen al escenario aceptado de 30 años; esa simulación todavía es deuda de fase.


## Alfa 0.74 · compradores regionales finitos (fase 33)

Los tres mercados externos representan alternativas regionales constantes, no dinero que se crea al vender. Cada mes sus capacidades suman 265 unidades y $6.450 de presupuesto comprador. Puerto Claro captura como máximo 74% según el puntaje agregado de comercios con personal y ruta vial/portuaria; el puntaje por firma pondera personal, precio, estado, servicios y distancia. El volumen y presupuesto capturados se reparten por puntaje con mayores restos, y la demanda individual no supera presupuesto/unidad. Exportaciones compiten con venta local por inventario producido, sus ingresos se restringen al presupuesto y sus pedidos de puerto siguen sujetos al sistema logístico ya existente. Se repite la oferta al siguiente mes como nuevos ciclos de compra regional, sin capitalizar saldos no usados. Mismo cálculo en Online y Offline; persistencia/resumen en esquema 58. La cifra de 74% y capacidades son parámetros iniciales de balance, no criterio de aceptación del roadmap. Verificación 0.74: la prueba Online confirmó cupo de 127 unidades y $1.778 de ingreso dentro de $3.091 de presupuesto; Offline recorrió una liquidación mensual, vendió 116 dentro de 116 unidades y $1.624 dentro de $2.826. Chromium verificó el panel en 390×844 y 1440×900 sin desborde horizontal. La salida comercial no se confunde con el embarque: solo crea orden portuaria cuando el destino elegido para la firma es ese puerto; una ruta directa al límite regional no crea carga marítima.


## Alfa 0.75 · ofertas de inversión privada y actores inspeccionables (fase 33)

Una única propuesta comercial puede aparecer tras cierre mensual si el informe regional deja 12 o más unidades demandadas sin vender, el corredor de salida está conectado y queda una parcela comercial libre junto a calle, alcanzable por ruta. Se elige la constructora viable de menor cotización que tenga capacidad de proyecto y siete trabajadores. El inversor dispone del costo contractual menos permiso más $1.200 de reserva; la ciudad debe poder cubrir el permiso (12% del costo base). La propuesta expira en 90 días; aprobación o rechazo inicia enfriamiento de 90 días. La aceptación exige ID, fecha, parcela, tipo y contratista coincidentes para evitar duplicación. El permiso se cobra a tesorería y el capital del inversor se aplica una sola vez al pago del contrato; el proyecto sigue compras, cuadrilla, plazo y control final existentes. Reutiliza `place` en ambos motores y usa esquema 59. Es una primera oportunidad acotada a comercios; no se considera un sistema completo de promotores ni trayectoria empresarial.

La selección de actores proyecta posiciones de rutas simuladas a pantalla y elige el actor visible más cercano dentro de un radio corto. Peatones vinculados a perfiles reales describen empleo e ingreso; viajes agregados listan los perfiles relacionados que estén disponibles; colectivos y transporte logístico muestran el servicio/carga. Los autos ambientales sin identidad continúan como ambientación. La navegación de Ciudad usa flex horizontal con `overflow-x`, gesto táctil y traducción de rueda vertical a horizontal, manteniendo visible la pestaña activa tras repintar.


## Alfa 0.76 · identidades en la migración residencial

Una mudanza del cierre mensual modifica ocupación, padrón y población en la misma transacción lógica. Cada llegada recibe un ID estable por fecha/hogar, edad de cohorte reproducible, etapa de vida y elegibilidad calculada contra el 42% de población potencialmente activa. Los elegibles obtienen habilidades y preferencias de salario/auto mediante el hash estable ya usado por el mercado laboral; menores y jubilados no se ofrecen a vacantes. El crecimiento sigue limitado por aprobación, plazas vacantes y capacidad laboral agregada. Al salir, se prioriza retirar un residente no empleado del hogar de menor calidad; si debe salir una persona empleada, su perfil se elimina y la siguiente asignación libera el puesto. Se actualizan población, ocupación, alquileres por residente e ingreso futuro de $3 mensuales por persona. Online y Offline comparten cohortes y reglas; no requiere migración de esquema.


## Alfa 0.77 · delegación administrativa con tope

La política `privateInvestments.delegation` es opt-in y contiene `enabled` y `maxPermit`. El tope se limita a $1.500. Al generar una oferta comercial, la simulación solo la contrata si el permiso no supera el límite. Revalida capital, tesorería, disponibilidad contractual y demanda al momento de asignar. El proyecto conserva el contrato estándar, etapas y materiales; la delegación paga el permiso, descuenta capital privado y paga el anticipo al contratista. Las ofertas por encima del tope permanecen disponibles para decisión manual. En Online continúa la logística de materiales; Offline todavía no integra abastecimiento como condición para avanzar obras. Se normaliza sin subir el esquema de guardado.


## Alfa 0.78 · cartera contractual intermandatos

Los proyectos de construcción registran `contractedMandate` y `contractedDay` al adjudicarse. `government_contract_portfolio()` / `governmentContractPortfolio()` suman el saldo `max(0, cost-paid)` en categorías pública y privada, y clasifican como heredados los proyectos adjudicados antes del mandato vigente. La instantánea se incluye en el resultado electoral, y el reporte actual alimenta el panel Gobierno. No hay reinicio ni movimiento de fondos en la elección; los pagos siguen su flujo contractual. El cambio es aditivo al estado de proyecto/resultado y se mantiene esquema 59. Esta primera cartera no cubre aún todos los contratos especializados de rehabilitación, crédito municipal y obligaciones de mantenimiento.


## Alfa 0.79 · reglas de zonificación y mercado (entrega anterior)

Una zona pintada es un permiso municipal persistente, no una construcción. El jugador puede pintar una franja con arrastre y cambiar el permiso de una parcela vacía. Casas y comercios automáticos requieren demanda, calle, cuadrilla, capital y, en Online, materiales comprados a proveedores existentes; permiso e inversión se descuentan de cajas diferentes. Las viviendas pasan inspección desocupadas y el contador de migración solo cae cuando entran personas.

La fábrica vende bienes básicos al mercado de insumos con coordenada de origen, costo y plazo de entrega. Producción depende de personal asignado y disponibilidad de agua, energía y cloacas. Esto desplaza compras a proveedores externos de producto terminado, pero aún no simula materias primas de una cadena industrial completa. La primera implementación de Offline mantiene los contratos de obra existentes, aunque estos todavía avanzan sin gasto de materiales.


La versión de guardado sube de 59 a 60 para agregar campos inicializados automáticamente `housingDemand` y `localIndustry`. La semilla Offline histórica se mantiene sin modificar y el adaptador migra el estado al abrirlo.


## Alfa 0.81 · crecimiento pintado y equipo sin bloqueos

La zonificación es permiso de uso sobre una parcela vacía, no propiedad ni obra. Los tres valores son `home`, `shop` y `factory`, representados en verde, azul y amarillo; los permisos nuevos se crean por acción explícita y requieren acceso vial. Una solicitud de lote es atómica para evitar pintar solo parte si alguna parcela no es elegible.

La demanda residencial persiste en `housingDemand.unmet`; empleos/aprobación producen candidatos, pero su llegada exige plaza vacante y capacidad laboral. Un hogar solo descuenta el backlog al mudarse. El promotor consume caja privada, permiso municipal, stock real de materiales, capacidad de constructor y tiempo contractual; el inicio mensual se limita para evitar colocar una fábrica o varias viviendas sin capacidad económica.

La fábrica usa plantilla y acceso simultáneo a energía, agua y tratamiento cloacal para determinar producción. Su proveedor local tiene stock finito, precio y coordenada vial; el mecanismo de compra existente compara costo entregado y disponibilidad y registra pedido desde el origen de la fábrica. Los pagos devuelven ingresos al capital fabril. Materias primas, insumos industriales y contratos offline con materiales siguen como pendientes explícitos. Guardado continúa en esquema 60.

## Alfa 0.81 · inversión privada automática y equipo sin restricciones por cartera

- La zonificación es permiso de uso, no un comando de colocación. Una pasada mensual evalúa demanda residencial, compras domésticas sin cubrir y comercios existentes antes de contratar viviendas, locales y fábricas con presupuestos privados y permisos municipales.
- Las oportunidades de tiendas ahora pueden originarse en escasez local de hogares, además de demanda regional. Los inversores eligen parcelas conectadas; si faltan fondos, cuadrillas o materiales, se aplaza el crecimiento en vez de inventar edificios o recursos.
- Offline reproduce la activación automática residencial, comercial e industrial sobre su motor existente. Su construcción simplificada aún no consume materiales; se mantiene como limitación explícita.
- Las carteras del equipo cooperativo son etiquetas voluntarias para coordinarse. No hay permisos por rol ni acciones de gestión reservadas al usuario anfitrión: cualquier jugador puede hacer todo, usar herramientas, gestionar tiempo, guardar/cargar o iniciar otra ciudad. Las carteras solo organizan la conversación. La identidad anfitriona marca el proceso servidor y se conserva al reiniciar/cargar para no transferir autoridad técnica.


## Alfa 0.82 · abastecimiento industrial por carretera

- Se usa una cooperativa regional finita para abastecer a la procesadora con grano. La empresa paga el pedido desde caja privada, el stock del proveedor se descuenta al despachar y el insumo solo ingresa al recibir la carga por ruta. El límite de reposición mensual y el stock máximo evitan importaciones infinitas.
- Cada unidad de grano permite procesar como máximo una unidad de alimento terminado. La producción también requiere plantilla, servicios y lugar en el inventario local; los comercios compran los alimentos y acreditan ventas a la fábrica. Se mantiene separado del proveedor de insumos minoristas para evitar que una tienda compre grano crudo.
- El mismo objeto de pedido se usa para entrega temporal y representación en el mapa 3D. Online actualiza distancia recorrida con congestión; Offline estima llegada por ruta y días. No se afirma una simulación de tráfico idéntica entre motores.


## Alfa 0.83 · revisión reproducible del plazo

El riesgo de demora se evalúa al menos una vez por cada 30 días transcurridos desde la adjudicación. Su probabilidad es 2,5% base + 22% de la falta de confiabilidad histórica + 4 puntos porcentuales si la empresa mantiene ocupada toda su capacidad. El resultado se deriva de coordenadas de obra, ciclo y empresa; no requiere estado de RNG nuevo y persiste mediante `lastRiskReviewCycle`. Si se materializa, suma entre 2 y 5 días, consume la jornada sin avance y redistribuye los certificados sobre el plazo ampliado. La regla es idéntica en Python y JavaScript para conservar guardados y paridad Offline. No se cobra sobrecosto ni penalidad: el precio adjudicado permanece fijo hasta implementar órdenes de cambio y reclamos.


## Alfa 0.84 · base de pago contractual

El anticipo existente equivale al 20% del contrato. Para el 80% restante, se calcula el objetivo acumulado como `costo × (0,20 + 0,80 × hitos_completados / cantidad_de_hitos)`. El hito se completa al cruzar `floor(progreso_físico × cantidad_de_hitos)`; entre hitos no hay certificados diarios. `paid` conserva el acumulado y `certificationHistory` registra día, etapa, avance, certificado y acumulado. Antes de consumir materiales se comprueba que la tesorería cubra el nuevo certificado municipal; de lo contrario el proyecto queda suspendido en el avance anterior. Para las empresas privadas el capital ya se comprometió al contratar y el certificado acredita fondos a la constructora. En rescates, `milestoneBase` excluye del nuevo contrato las etapas ya ejecutadas y divide el saldo entre los hitos físicos restantes. No se retienen fondos aún; garantía, reclamos y penalidades permanecen como trabajos futuros. La migración de proyectos existentes deriva el hito vigente desde su progreso guardado para no duplicar pagos.


## Alfa 0.85 · retenciones y garantías de contratos municipales

Los proyectos públicos **nuevos** llevan `retentionPct: 0.10`: el anticipo permanece 20%, los certificados intermedios acumulan hasta 90% y el 10% de cierre se mueve de caja a `finance.contractEscrow.balance` al recibir provisionalmente el activo. El control de fondos del hito final incluye ambas salidas. Para conservar compromisos aceptados, proyectos guardados que no tienen el campo usan cero y la construcción privada también usa cero. La retención no es gasto ni caja disponible. Cada garantía persiste en `contractGuarantees`, con contratista, calidad y confiabilidad congeladas, coordenadas y fechas. Después de 30 días se calcula una incidencia determinista usando coordenadas, día de adjudicación y orden de constructora: riesgo base 2,5% + 18% de la brecha de calidad + 12% de la brecha de confiabilidad. Al detectar defecto se reduce 12 puntos de calidad y el reclamo bloquea el fondo. La acción cooperativa `repairContractGuarantee` asigna tres trabajadores y cinco días; al terminar restaura la calidad y libera el fondo al contratista. Revisión idempotente por estado. Paridad de calendario y fórmula de riesgo en Python/JS.


## Alfa 0.86 · cambio de alcance en contrato

Cada proyecto recibe a lo sumo una revisión técnica determinista al cruzar 20% de progreso. El hash de coordenadas, día de contratación y orden de contratista alimenta el mismo roll de Python/JS. La posibilidad es 11% + la brecha de calidad de la firma × 18%, más 2,5 puntos en infraestructura. La incidencia genera adicional entre 8% y 14%, 4–8 días y penalidad de 12 puntos; detecta redes enterradas comparando la parcela con las capas físicas existentes.

El proyecto cambia a `cambio_pendiente` y no avanza hasta la decisión cooperativa. Aprobar calcula fondos como caja menos saldo no pagado de todos los contratos públicos, suma el adicional al precio y conserva avance mediante `scheduleBaseProgress`, `scheduleBaseElapsed` y `scheduleRemainingDays`. Rechazar mantiene precio/calendario y acumula `qualityPenalty`, aplicada al certificado de calidad final y al riesgo de garantía. La historia se limita a 40 entradas.

## Alfa 0.87 · cantera industrial y venta de áridos

El primer edificio `factory` histórico sigue siendo procesadora de alimentos. Cuando ya existe una fábrica, la próxima inversión industrial se tipifica como `industryType: quarry`; el estado queda en el negocio para que guardados y cierres no cambien especialidad. La cantera recibe 2.400 unidades de reserva, capacidad de patio 360 y hasta 48 unidades por mes calculadas como personal × 1,5 × el menor porcentaje de electricidad/agua/efluentes, limitadas por reserva y patio. Paga la nómina registrada y $320 de operación mensual. La insolvencia cierra el edificio y libera empleos.

`Cantera local` es un proveedor de materiales con stock, precio 0,76 de la tarifa de áridos y 1 día de preparación. La compra conserva el contrato logístico existente: costo de material/flete, ruta vial desde coordenadas reales de la cantera, cola de autoelevador y destino seleccionado. Se resta el inventario del proveedor y del lote de la firma; el vendedor recibe el precio base del material y el flete queda fuera de su caja. Si no alcanza stock o no existe ruta, el pedido no puede simular que llegó. Las fuentes regionales cubren el faltante. Esta primera etapa solo opera en sala Online; el adaptador Offline aún no admite pedidos de materiales.


## Alfa 0.88 · hormigón como insumo industrial (fase 18)

La especialización se guarda en `business.industryType`: el siguiente factory posterior a la cantera pasa a `concrete`; luego las nuevas fábricas vuelven al rubro de alimentos. `advance_local_concrete_plants` reserva de inventario de cantera y debita caja al ordenar; el `marketOrder` guarda fuente/route y al llegar repone el inventario bruto de la planta. Cada dos áridos entregados generan un hormigón, sujeto a personal, factor mínimo de electricidad/agua/saneamiento y patio de 240. El proveedor local mantiene stock sincronizado con las existencias de la firma; `settle_concrete_sale` abona ventas a la hormigonera. Recetas existentes suman hormigón reduciendo una parte de áridos, para no aumentar toda la cantidad de material pétreo.

Guardar compatibilidad: `MATERIAL_NAMES`, inventario inicial regional/contratista y `SUPPLIER_STOCK` incorporan `concrete`; `ensure_supply_state` añade ceros a proveedores, constructoras y depósitos antiguos. Las compras Online al proveedor `Hormigonera local` salen desde las coordenadas de una planta activa, pasan por la red vial existente y usan la descarga normal. Offline sigue sin pedidos de materiales y no debe mostrar esta cadena como jugable allí hasta implementar su circuito equivalente.


## Alfa 0.89 · inventario y abastecimiento Offline

La modalidad Offline implementa una capa de materiales coherente con el formato compartido: claves `aggregate`, `concrete`, `steel`, `timber`, `components`; recetas por `kind`; `materialsUsed` por avance, con partidas previas migradas desde su progreso actual. Los proveedores Offline tienen stock finito y una reposición mensual limitada. `orderMaterials` descuenta inventario proveedor y caja de la constructora de forma atómica, valida el stock, espacio de patio/depósito y conectividad vial, y crea una orden con preparación y viaje. `processOfflineMaterialOrders()` transfiere existencias al destino contratado; el tick de obra las consume y la suspende si el próximo lote falta. Los promotores autónomos compran su receta directamente y el costo se suma a su chequeo de capital antes de iniciar. No mezclar el almacenamiento agregado de interfaz con la capacidad por ubicación usada al pedir. Mantener el botón de materiales disponible en Offline y la confirmación del diálogo fija/visible mientras su lista desplaza.


## Alfa 0.90 · cadena forestal / aserradero

En Online la industria privada se decide en `next_factory_industry`: alimentos → cantera → hormigonera → aserradero → vuelve a alimentos. El estado persistente usa `localIndustry.timberReserve` (1.800 troncos iniciales, máximo 2.400), regeneración mensual 18 y contadores producidos/vendidos. Cada tabla consume dos troncos, tiene capacidad máxima mensual 30 y queda limitada por cuadrilla, servicios y proveedor con 240 plazas. `SUPPLIERS` y `SUPPLIER_STOCK` declaran `Aserradero local`; el endpoint `orderMaterials` identifica `industryType=sawmill` y usa su coordenada como origen. Las ventas descuentan `business.timberStock` y pagan tarifa al aserradero. Offline conserva food processing en la primera fábrica y ofrece sawmill en la segunda; `advanceOfflineSawmills()` consume la misma reserva y produce al cierre mensual. Antes de ordenar en la interfaz, sugerir solo las categorías que el proveedor seleccionado puede entregar, para que un aserradero con madera no incluya por defecto áridos/hormigón/acero/componentes.

## Alfa 0.91 · acero importado → metalúrgica → componentes

El acero se fabrica en componentes de obra con una metalúrgica privada; no se crea acero local de la nada. Online/Offline la planta repone acero del Corralón con una orden industrial y ruta vial, guarda hasta 48 unidades de acero crudo en vuelo/insumo y convierte 1:1, limitada a 24 componentes por ciclo por personal, electricidad, agua y saneamiento. El almacén de salida admite 180; los pedidos de construcción descuentan el proveedor Metalúrgica local y pagan a la caja privada. La industria se habilita tras cantera, hormigonera y aserradero. Las ciudades heredadas reciben la ficha de proveedor vacía por la migración estándar de existencias.


### Alfa 0.92 — exclusividad de industria y validación automática

Una planta con industryType quarry, concrete, sawmill o metalworks solo participa en su cadena específica, no en la de alimentos. Offline ya filtra estas cuatro clases igual que simulate_business_month Online. Las pruebas de logística construyen una obra controlada con faltante de componentes, camión y una metalúrgica existente para evitar confundir la simulación de pedidos con la habilitación de plantas nuevas, que sigue pendiente. El workflow de GitHub Actions corre tests Python y Node sobre main.


### Alfa 0.93 — identidad de planta a la adjudicación y transformación sin generación de materia

Las construcciones `kind=factory` nuevas guardan `industryType` al contratar (actividad elegida según especialidades abiertas o ya adjudicadas), no al pasar la inspección. Secuencia compartida: food, quarry, concrete, sawmill, metalworks. El destino queda fijado para obras en curso aunque otra fábrica termine primero. Para nuevos contratos industriales la reserva operativa pertenece al capital privado y se traspasa a caja de la empresa al abrir, sin inventar dinero.

Offline incorpora `Cantera local` y `Hormigonera local` a los proveedores persistentes usando migración de existencias por defaults. La cantera reduce `quarryReserve` al extraer y la hormigonera consume 2 unidades de `rawMaterialInventory` para crear 1 `concreteStock`. La compra resta simultáneamente stock del proveedor y stock vendible de la cantera, acredita caja de cantera, debita caja de hormigonera y crea una sola orden de transporte. La recepción se bloquea si se corta la ruta vial; los materiales no aparecen por haber pagado. La venta de hormigón a constructoras reduce el stock vendible de planta y mantiene el contador industrial. Tests acotan diferencias con el servidor.


### Alfa 0.94 — traspaso de industria quebrada a nuevo operador

`industrialRecovery` se guarda dentro del edificio `kind=factory` existente, con `contractor`, `workersAssigned=5`, `contractedDay`, `readyDay`, `operatingReserve=4200`, `cost=5300`, estado y causa; `industrialRecoveryHistory` conserva cada transferencia. No se reemplaza la parcela ni se crean obras estándar incompatibles con ocupar un edificio cerrado; la constructora sí reserva capacidad y cinco trabajadores durante siete días. Pago: capital privado -5300, municipio +200, caja del contratista +900, nueva firma +4200 al abrir; ninguna emisión de caja. Se requiere demora 90 días desde `closedDay` (guardados legados pueden establecer fecha al primer chequeo). El nuevo `business.id` distingue al empleador; `industryType` no cambia, bienes/ruta de insumos se reinician y `quarryReserve` retiene lo no extraído. El cierre anula inventario vendible del proveedor y deja el remanente empresarial en cero, para evitar doble destrucción al reocupar. Servicio mínimo 65% y acceso por ruta verificables al adjudicar y al inspeccionar. La pantalla refleja estados sin generar cálculos de economía en cliente.


### Alfa 0.95 — oferta industrial por instalación

Para compras manuales a un proveedor industrial local, la cotización es por planta habilitada con `industryType` coincidente, stock suficiente para todo el lote, ruta vial disponible y costo total `productCost + freight`. Se ordenan ofertas por costo, recorrido y coordenadas para reproducibilidad. La venta decrementa exactamente el campo de inventario de esa planta; `localIndustry` registra cantidad vendida, `business.cash` registra solo mercancía y `supply.logisticsCash` solo flete. La identidad del ganador, origen, ruta, tarifa y desglose del precio permanecen en la orden. No dividir pedidos por múltiples plantas implícitamente; hacerlo requerirá órdenes/camiones distintos. La hormigonera usa la misma liquidación específica al comprar áridos, con cotización de producto y tránsito propios.

`industrialSalesSincePricing` es acumulador independiente de `lastLocalSales`: los cierres mensuales reinician estadísticas de producción antes de actualizar precios; el acumulador evita perder ventas realizadas entre cierres y se reinicia solo tras valorar la política de tarifas. Se mantienen `materialPriceFactor` entre 0.8 y 1.35 y el precio genérico para proveedores regionales. La interfaz puede sugerir un máximo por planta, pero el servidor vuelve a validar la ruta y el lote al adjudicar. Las compras automáticas previas de promotores conservan su proceso simplificado hasta que exista planificación vial para esos contratos.


### Alfa 0.96 — compras diferidas de promotores y elasticidad laboral

Las nuevas obras `zonedDevelopment` no reciben directamente las materias primas al firmar. Las órdenes privadas (`privateContract=true`, `projectId`, `supplier`, `source`, `route`, `destinationId`, `items`, `productCost`, `freight`, `cost`, `supplierReadyDay`, `arrivalDay`) quedan en `supply.orders`, usando la descarga existente. El cálculo previo no altera inventario ni caja; solo después de aprobar la viabilidad de todos los lotes se ejecuta la compra. El inversor paga de `privateCapital`, nunca del presupuesto municipal. Cada depósito debe disponer de espacio no reservado y ruta hacia la obra, además de ruta desde el proveedor. Un proveedor local debe tener el lote en una planta concreta conectada, con saldo e ingreso individual; el transportista recibe el flete por separado. La falta de stock o capacidad impide contratar, no genera materiales ficticios. Los guardados legados no necesitan migración destructiva.

El ajuste mensual de empleo crea/cancela `jobSlots` según ganancias, demanda, stock, caja y ocupación; al expandirse se transfiere dinero desde caja de la empresa a `supply.businessEquipmentCash`. Sin inversor y sin ventas no hay expansión. Los despidos modifican los residentes (`unemployedSinceDay`, `employerId`, `previousEmployer`) y ajustan `state.jobs`. `staffingSalesCheckpoint` evita contar dos veces las ventas industriales. Se mantienen techos y mínimos de vacantes para evitar oscilaciones explosivas; los históricos solo registran decisiones efectivas.


### Alfa 0.97 — contratos de abastecimiento con caja de custodia

`supply.tradeContracts[]` guarda acuerdos activos y finalizados, por `id`, `buyerId`, `vendorId`, cantidad, total, escrow, remesas entregadas/canceladas, importes liquidados y recuperados. Cada remesa se representa también en `supply.marketOrders[]` con `supplyContractId`, fechas `supplierReadyDay` y `deadlineDay`, precio y flete. La firma **descuenta una sola vez** el stock físico de la cantera y la caja compradora; el procesamiento diario entrega al inventario receptor por ruta y después paga desde escrow a productor/logística; los fondos aún retenidos no se cuentan como caja de ninguna compañía. El plazo es `supplierReadyDay+14` días; se cancela solamente la remesa pendiente, acredita el reembolso al comprador y devuelve stock a cantera si su firma sigue activa. Un proveedor desaparecido deja material perdido marcado en el contrato, no inventario gratuito. `contractSettled` previene liquidación repetida y la totalidad de remesas determina estado final. Los guardados viejos migran con `setdefault`/fallback sin reiniciar partidas. Esta capa se aplica a materias primas áridas entre canteras y hormigoneras, sin fingir que todas las categorías usan todavía custodia.

### Alfa 0.98 — prórroga de contrato frente a corte vial

Una acción `renegotiateTradeContract` exige contrato activo no prorrogado, al menos una remesa sin liquidar y antes del vencimiento, ausencia de ruta real, y ambas empresas solventes/abiertas. La tarifa `max(20, floor((contractValue+10)/20))` se debita de la caja compradora y acredita a la vendedora directamente: no modifica `escrow`, pagos de transporte ni existencias. Solo los `deadlineDay` pendientes aumentan en 14. `renegotiatedDay` impide repetir; el almacenamiento legado sigue compatible, sin migración destructiva. Ambas implementaciones validan la acción, no la interfaz.

## Convención de versiones de las entregas (obligatoria)

Las Alfas se etiquetan como `0.N` con `N` entero sin límite de cifras, conservado como **texto**: `0.99 → 0.100 → 0.101 → 0.102 → ... → 0.999 → 0.1000`. Nunca cambiar a `1.0` ni interpretar `0.100` como número decimal (equivaldría erróneamente a `0.1`). La próxima versión se calcula incrementando `N` y anteponiendo `0.`. Las entregas agrupan sistemas y mecánicas; ajustes aislados permanecen en la misma Alfa. Los campos `currentVersion`, `versions[].version`, la cabecera visible y los nombres de artefactos deben reflejar el mismo identificador.

## Requisito visual 3D obligatorio — intervención del usuario (Alfa 0.102, sin incrementar versión)

Toda mecánica de ciudad que tenga un actor físico debe representarse en el mundo Three.js, **no sólo en paneles**: vehículos, construcción, servicios, tráfico y labores visibles en tiempo real. La prioridad inmediata era hacer visibles **policía, bomberos y ambulancias**: las bases equipadas muestran coches policiales; los cuarteles exhiben autobombas; los hospitales, ambulancias. Con dotación activa, los patrulleros recorren calles conectadas; cuando hay incidente policial o incendio atendido, se reconstruye y anima la ruta de respuesta real, guardada por el motor. Los traslados de ambulancia se guardan en `health.ambulanceDispatches` (idempotentes por día, con origen, destino, pacientes y ruta) y se reproducen en el mundo cuando existen. Sin ruta transitable, el actor permanece estacionado, nunca atraviesa parcelas. Al seleccionar un actor móvil en Three.js, el panel describe su labor. No fabricar misiones visuales que no existen en la simulación.

El pipeline de render mantiene vehículos móviles en `trafficRoot`; `world3d.js` añade `makePoliceCar`, `makeAmbulance`, `spawnEmergencyActors`, búsqueda de ruta vial sin segmentos inhabilitados, patrullaje físico y reproducción temporal de incidentes. La función de diagnóstico `window.__ciudadViva3D()` expone la posición real de los actores Three.js para el test visual automatizado. `tests/test_ui_layout.mjs` cubre 390 y 1440 px, comprueba que las tres clases existen de verdad en el árbol de escena, tienen ruta y cambian de posición al transcurrir el tiempo. Esta validación corresponde a Alfa **0.102**, no crear 0.103 por una mejora de presentación de la misma mecánica.

**Norma futura:** diseñar cada sistema en tres capas simultáneas: estado/cálculo Online-Offline, interfaz informativa accesible y representación concreta en el mapa 3D. Una cifra en el panel no sustituye al actor físico. Las intervenciones históricas se muestran como reproducción visual de lo ocurrido, no como nuevas intervenciones reales; las unidades sin operación deben verse estacionadas. Faltan aún animaciones más profundas de entrada en edificios, evacuaciones, reparaciones y otras tareas urbanas; no declararlas hechas.

## Alfa 0.104 · jardín, primaria, secundaria y universidad con educación efectiva

Se agregaron cuatro obras municipales en Construir, con licitación y recursos materiales realmente proporcionales: jardín ($6.200, 52 días, 8 vacantes, radio 5 tramos, 5–6 años), primaria ($9.600, 68 días, 12 vacantes, radio 8, 7–12), secundaria ($17.800, 100 días, 18 vacantes, radio 12, 13–17), y universidad ($32.000, 145 días, 30 vacantes, radio 17, 18–24). Las bases tienen aulas y operación mensual $580/$820/$1.550/$3.200 más nómina e insumos por inscripto. La simulación de Online y Offline toma un residente identificable, una edad compatible y un máximo de ruta por calles abiertas; si una sede se llena, busca otra accesible. Los cupos dependen de profesores cualificados efectivamente empleados, aulas, electricidad, agua, saneamiento y presupuesto. Tras doce meses realmente asistidos por nivel, se registra la formación y aumentan las competencias laborales según ciclo, sin acreditar nada por informes repetidos o edificios vacíos. Las partidas antiguas con edificios u obras school sin serviceModel conservan su funcionamiento previo para edades 5–17.

La escena 3D distingue jardines y edificios mayores, y muestra en verde sobre calles transitables el radio del establecimiento seleccionado o previsualizado. Se incorporan regresiones Online/Offline y se actualiza el empaquetado CI. Los estudiantes todavía no se mueven individualmente por las calles de Three.js; tampoco existen carreras universitarias completas ni oferta técnica especializada. Fase 28 queda parcialmente en 75%, progreso global no cuantificable. CI se verificará después de publicar; LAN física y Vercel siguen sin comprobar.

**Siguiente gran mecánica sugerida:** protección social por hogar con elegibilidad objetiva, presupuesto y cupos mensuales realmente acotados y efectos comprobables. Seguir la serie Alfa 0.N: 0.105 → 0.106.


## Alfa 0.105 · interfaz rosa minimalista, avisos físicos y construcción comprensible (histórico)

La interfaz pasa a rosa empolvado/crema, superficies blancas, controles con jerarquía y navegación simplificada sin ocultar el simulador. En el muelle inferior hay **Avisos** y **Ayuda**. El módulo cityGuide.js obtiene alertas de datos calculados por las simulaciones Online/Offline: policía, incendios, ambulancias, basura visible, contenedores casi llenos, tramos dañados y obras pausadas. Cada aviso tiene identificador, posición real y texto accionable; la proyección de la cámara coloca botones 2D sobre el edificio o la calle (giro y zoom incluidos). Pulsar una alerta abre descripción y permite inspeccionar parcela. No se fabrican incidentes sin causa simulada. Los eventos resueltos solo se ven por un período limitado; los incidentes sin respuesta no se confunden con los atendidos. Los avisos son lectura y localización de hechos existentes, no despacho municipal manual.

Los cubos junto a calles corresponden a **contenedores de residuos**, **bolsas de basura no recogida** o **barreras de calzada deteriorada**, no a bloques de construcción. Al tocar la parcela se identifican con cantidad/capacidad o condición y medidas de solución. Las zonas amarillas son **permisos industriales, no fábricas terminadas**. Al tocarlas se puede elegir especialidad, o hacerlo en Construir: procesadora de alimentos, cantera, hormigonera, aserradero y metalúrgica. Los dos motores validan y guardan la especialidad elegida, sin cambiar la asignación automática de inversiones zonificadas y partidas anteriores sin selección explícita.

**Cómo conseguir hormigón:** en Obras → Pedir materiales, elegir proveedor con hormigón físico en stock, ruta para camión, destino con espacio y caja del contratista. Para producir localmente: dos parcelas industriales conectadas; construir primero cantera (áridos), después hormigonera. La receta del juego consume *dos áridos físicos por unidad de hormigón*, además de necesitar personal, electricidad, agua, saneamiento, capital privado y cadena logística. No afirmar que se modela cemento por separado. Las obras no terminan al pintar suelo: la guía explica etapas, certificados, esperas, causas y materiales aún por consumir, diferenciados de stock entregado o en tránsito.

Three.js añade detalles decorativos y diferenciación a todas las familias, patios, señalética, jardineras, fachadas, cubiertas, instalaciones industriales y luminarias, además de iluminación más cálida; se mantiene como base el modelado procedural previo, sin importar modelos CAD externos. En móvil se omiten adornos adicionales costosos. **Pendientes**: efectos activos de humo/llamas, tutorial con pasos validados, remodelación total de cada activo con malla de alta calidad, despacho manual de emergencias y mejoras adicionales de rendimiento. No declarar esos sistemas completos. Las regresiones cubren clasificación de avisos, fuentes, guía de materiales, especialidad industrial Offline y UI responsive. Verificar CI después de publicar; red LAN física y Vercel requieren comprobación separada.

**Próxima etapa:** emergencias con decisiones y respuesta municipal sobre el mundo; después optimización visual y tutorial por objetivos persistente.

La fase 13 avanza del 35% al 40%. En el panel Ciudad → Servicios, una avería permite contratar reparación normal al costo base y tres días, o despachar una cuadrilla prioritaria por el doble y un día. La respuesta urgente verifica conectividad vial y caja municipal libre después de compromisos de obra; las acciones repetidas se rechazan. El corte aparece en Avisos con causa, ubicación, afectados y opciones. La ruta y el estado de la cuadrilla persisten y Three.js presenta un vehículo seleccionable durante el trabajo y hasta un día después de restablecer la red. Online y Offline usan el mismo costo, plazo y requisitos. Tests: `test_utility_response_online.py`, `test_utility_response_offline.mjs`, `test_city_guide.mjs` y revisión UI responsive.

**Pendiente:** responder con opciones específicas a enfermedades, accidentes y otras crisis; completar el catálogo causal de fase 13. La UI integral queda como etapa posterior a esta tanda mecánica, según la instrucción del usuario. El progreso global sigue sin estimarse: el registro de roadmap no define pesos verificables comunes para ponderar las 34 fases. Fase 13: 40%.

**Siguiente entrega:** ampliar fase 13 con respuesta sanitaria y movilidad ante accidentes, e integrar sus efectos persistentes. A continuación iniciar el rediseño visual integral solicitado. Mantener controles sin límites para invitados.

## Alfa 0.107 · rediseño integral Atlas municipal

La interfaz adopta una dirección cartográfica propia: azul petróleo, papel cálido, acento terracota y verde de acción. `design.css` concentra el nuevo sistema para pantalla de inicio, barras superiores, indicadores, mapa, dock, ventanas, catálogo, formularios, avisos y paneles de ciudad. El archivo se sirve también por el anfitrión LAN. Se corrigió la cuadrícula heredada: como los paneles laterales están en ventanas, el mapa ocupa todo el ancho de escritorio; en móvil ocupa toda la altura entre indicadores y pie. Los controles y textos largos permiten envolver y desplazar contenido. La navegación y mecánicas siguen disponibles. Comprobar visualmente 390×844 y 1440×900, además de las pruebas de interfaz existentes.

Fase 15 sube de 60% a 65% por coherencia visual y legibilidad comprobables. Progreso global aún no estimable: faltan pesos comunes verificables para las 34 fases. Pendientes: sesiones de usabilidad con personas y revisión de accesibilidad. Próxima entrega: respuestas sanitarias y viales de fase 13.

## Alfa 0.108 · movilidad y lectura de la ciudad (2026-11-01)

- El mapa dibuja estrés vial con viajes ya simulados, señales visuales en intersecciones, vehículos en carril derecho y giros de orientación suavizados. Los semáforos detienen visualmente los actores; la espera semafórica aún no entra en el cálculo autoritativo de tiempos.
- Se ampliaron geometrías y detalles de árboles, coches, buses, casas y fábricas. Se aumenta el zoom a 4×. En móvil se reduce la cantidad de árboles decorativos para sostener el rendimiento.
- Avisos reutilizados entre actualizaciones, pulso suave y ubicación baja para basura/calles. El panel de aviso conserva causas y acciones.
- Construir tiene grupos visibles; Economía separa producción, Hacienda y mercado; Ciudad muestra un menú vertical. Tema claro/oscuro guardado localmente. Sonido ambiental procedimental tras interacción.
- Al cambiar ventanas, los nodos de controles regresan a sus contenedores originales. La lista LAN consulta `/api/rooms` si existe un iniciador y muestra sesiones anunciadas. En Vercel no es posible descubrir máquinas LAN desde un sitio estático bajo HTTPS; se ofrece estado vacío y unión manual, sin simular salas.
- Verificación: sintaxis JS, pruebas Python 52/52, inspección visual móvil y escritorio de Construir, Ciudad, Economía y Tráfico. La prueba completa de Playwright terminó correctamente en 390 y 1440 px tras evitar el render 3D detrás de ventanas; también pasó la prueba visual de respuesta de servicios. Se verificaron por navegador la lista vacía LAN, el panel flotante de tráfico y el tema oscuro. Pasó también el stress económico de 30 años con cuatro perfiles y 360 cierres mensuales por perfil. La prueba entre dos computadoras físicas sigue pendiente.
- Progreso global: no cuantificable todavía. El método por fase usa incrementos de 5 puntos con evidencia, pero no hay pesos estables y verificables para agregar las 34 fases. Fases 7 y 15: 70% cada una, ambas parciales. Hito actual F; próximo: completar simulación vial con tiempos autoritativos, accidentes y otros sistemas pendientes de F.

## Render y simulación sin tirones (Alfa 0.117)

Offline delega el adaptador a un Worker de módulo (`offline_worker.js`); `offline_client.js` adapta su ciclo de mensajes a la API async usada por `game.js`. El Worker imita `localStorage` con una memoria persistente pasada desde la página y devuelve snapshots cuando guardar/cargar o cambió la revisión; también sincroniza un checkpoint de reloj cada cinco segundos. Si el navegador no soporta Worker, conserva el adaptador directo como compatibilidad. El host LAN permanece en Python y autoritativo.

`stateRevision` cambia por acciones y días terminados, nunca por cada incremento del reloj; el HUD actualiza la hora independientemente. La firma visual del Three.js contiene proyecciones de propiedades que alteran mallas, rutas, proyectos, incidentes y capas. No incluye el reloj, el día general ni el contenido salarial/residencial completo. `requestAnimationFrame` no tiene espera adaptativa ni tope de 50 ms.

## Reloj, calendario y luz (Alfa 0.116)

La hora es parte del estado de la partida: `timeOfDayMinutes` usa 0–1440 y se persiste. El factor de velocidad multiplica el tiempo de juego; una hora simulada transcurre cada segundo real a ×1. El calendario cambia únicamente al cruzar medianoche. Esta escala permite que la hora visible corresponda con demanda y horarios de movilidad, manteniendo el avance diario existente a un ritmo jugable. El host online es autoritativo; el render 3D interpola la luz entre actualizaciones de estado. Offline guarda la misma variable en el snapshot local.

El mapa alterna gradualmente iluminación solar y artificial; farolas muestran luz local cálida y reflejo de suelo nocturnos. La hora/franja activa se muestra junto al calendario y en el panel de Tráfico. No se recalcula el modelo diario de colas en cada frame: conserva las nueve franjas discretas y muestra el informe de la franja vigente.


## Alfa 0.134 · cuidado de personas mayores

El centro de acompañamiento domiciliario ofrece acompañamiento domiciliario, no residencia permanente. La elegibilidad se deriva de edad real (75+; prioridad alta desde los 80), sin sacar personas de su hogar ni modificar población. La asignación mensual exige personal, ruta vial hasta el hogar, servicios de electricidad/agua/saneamiento y presupuesto efectivo de Servicios. Capacidad: cuatro visitas por trabajador, limitada por el cupo físico. Es una simplificación intencional del primer corte; transporte accesible, cuidados por nivel de dependencia y seguimiento longitudinal quedan pendientes.


## Alfa 0.135 · refinanciación de deuda municipal

Oferta fija, visible y determinista: tomar saldo principal más mora, amortizar a 72 meses y 18% anual. Solo se permite una refinanciación por crédito, cuando quedan más de tres cuotas y el pago nuevo resulta menor. La mora se capitaliza, el efectivo no varía y el usuario ve costo restante anterior frente al costo total nuevo antes de confirmar. No hay quita ni capital nuevo. Se persiste un asiento de reestructuración y vínculo con el préstamo original.


## Alfa 0.136 · libro neto de caja municipal

`finance.cashLedger` se persiste en los estados Online/Offline. `openingBalance + receipts - payments` se contrasta con el efectivo actual; las diferencias se exponen en Hacienda. Se agrega una fila solamente al variar el saldo entre límites de operación/API, con día, cantidad, referencia del evento reciente y saldos anterior/posterior. La interfaz muestra los últimos 12; el estado guarda hasta 120 y conserva acumulados totales para conciliar aunque rote el detalle.

Un guardado anterior inicia el libro con el efectivo actual y sin entradas inventadas. El dato describe variación neta por límite de operación/cierre; no implica clasificación contable completa ni partida doble. Cambiar efectivo hacia la reserva de deuda es salida de la caja disponible, aunque no sea gasto consolidado. Se mantiene fase 29 en 40% (100/50/50/0/0) mientras este bloque de auditoría esté incompleto.


## Alfa 0.137 · sensibilidad fiscal a doce meses

`municipal_finance_scenarios` y `offlineMunicipalScenarios` reutilizan el motor existente de caja, obras y deuda en tres casos paralelos: base 0/0, favorable +10% ingresos y −5% gastos, adverso −15% ingresos y +10% gastos. Cada motor copia las cuotas; no descuenta efectivo, no cambia obligaciones ni guarda la hipótesis. El resultado mantiene contratos, prioridades, reservas y condiciones tributarias actuales; esa limitación se muestra al jugador. El caché usa los campos que afectan a proyección y se invalida ante cambios relevantes.

`municipal-scenarios` es plegable para no saturar Economía; muestra supuestos, ingreso/gasto aplicado, caja y mora al mes 12, déficit y primer impago. La fase 29 pasa a 50% porque el bloque de escenarios se considera parcial (cinco bloques iguales; 100/50/50/0/50). El alcance plurianual, inflación, población, salarios y demanda queda explícitamente pendiente.


## Alfa 0.142 · inicio directo de obras

La acción de ubicar una calle/edificio reutiliza `/api/action` con el contratista elegido automáticamente y ya no abre una confirmación en cada parcela. `placeQuick` encadena los clics en `placementQueue` para que cada respuesta actualice el estado antes de elegir la siguiente cuadrilla. El servidor continúa siendo autoridad para costo, sitio y capacidad. No cambiar el avance por etapas ni la animación asociada a los proyectos.

La ayuda del catálogo es no bloqueante y se activa con `pointerenter`, foco y toque. Muestra datos de descripción del botón y agrega costo/plazo/cuadrilla calculados con el mismo multiplicador de la cuadrilla disponible. La estimación puede cambiar al terminarse otra obra; la cifra definitiva siempre la valida el servidor. Zonificación y redes que tienen acciones propias describen su operación sin fingir que crean un proyecto por etapas.


## Alfa 0.143 · traslado funerario por carretera

La preferencia familiar se fija por identidad y persiste en el registro de fallecimiento (70% sepultura, 30% cremación); una familia no cambia de servicio para resolver falta de oferta. El despacho sólo considera equipamiento municipal funerario habilitado, accesible por ruta vial dentro del radio del modelo de servicio. Cementerio: radio 14, capacidad permanente 120. Crematorio: radio 16, capacidad 24 por año. La capacidad se reserva para cada viaje activo y se consume al arribo; esto serializa el último cupo ante muertes simultáneas.

`funeralTrip` conserva clase de servicio, destino, ruta ida y vuelta, salida y llegada estimada; el actor de escena sigue esa ruta y es seleccionable. Si no existe destino válido, `waitReason` contiene causa y se representa con un aviso en el hogar. Online (`server.py`) y Offline (`offline.js`) deben conservar paridad. Los radios se miden en distancia vial más corta, no por distancia euclídea.

## Alfa 0.144 · demanda HUD y conectividad del barrio

`growthDemandState()` en `game.js` refleja las reglas actuales de `advance_zoned_development`: vivienda normalizada a la demanda inicial de 36; comercios requeridos desde 24 residentes y a razón de un local cada 90 habitantes; fábricas según locales activos que registran ventas/insumos y una por cada dos comercios (tope actual de seis unidades requeridas). El motor construye hasta cubrir ese objetivo y cuenta edificios y obras privadas ya iniciadas. Son indicadores del sistema existente y no crean demanda ni construcciones por sí solos. Los medidores son verticales y permanecen sobre el mapa.

`building_road_access()` en Online y `offlineRoadRoute()` en Offline definen el camino continuo entre edificio y entrada regional. El resultado se agrega sólo a la vista como `roadAccessConnected`/`roadAccessReason`; no altera guardados antiguos ni el estado de construcción. Una alerta seleccionable identifica un corte. Colocación requiere calle adyacente ya terminada; el desarrollo automático zonificado requiere también ruta a la entrada exterior. Sistemas de movimiento, comercio y cobertura ya usan el grafo vial.

# Decisiones técnicas · Alfa 0.145

- El terreno construible se guarda en `landClaims`: `chunkSize=8`, lista de sectores `cx,cy` y contador de expansiones. La nueva ciudad recibe cuatro sectores iniciales que ocupan una cuadrícula 16×16; el acceso vial exterior queda en `(4,10)`. Las coordenadas negativas usan división de piso coherente Online/Offline.
- Se habilita solo un sector ortogonalmente contiguo a otro ya adquirido. El precio depende del anillo de coordenadas respecto al origen (mínimo $3.500 y suma $2.200 por anillo); la tesorería disponible descuenta compromisos de contratos antes de permitir el pago. Todos los jugadores comparten la misma acción y tesorería.
- La respuesta pública del estado calcula el frente bloqueado actual; al comprar una zona se recalcula. No se persiste una lista infinita de terreno: el guardado almacena sectores adquiridos, por lo que el tamaño de la partida crece con lo realmente comprado.
- Los guardados sin `landClaims` se migran conservando terreno ocupado por calles, edificios, obras, parcelas y ruinas. No se fuerza un reinicio de ciudades existentes.
- El suelo 3D amplio se desplaza por segmentos bajo la cámara para no presentar un borde visual al navegar. Es una escena plana con costa local, no una generación de biomas ni un terreno topográfico sin límite. La expansión jugable no tiene borde artificial de coordenadas; precisión/renderizado y rendimiento limitan en la práctica ciudades extremadamente extensas.
- Hito actual: fase 1, extensión territorial. Próximo foco: completar catastro y derechos de propiedad y probar rutas/guardados en mapas grandes; luego retomar nuevas mecánicas de fases con menor cobertura.

## Decisión Alfa 0.155 · migrar colecciones offline ausentes

Las partidas locales sobreviven a cambios de versión; una colección de estado que no existía en el esquema guardado se inicializa como `[]` al migrar, antes de que simulación/UI/3D la consulten. El render 3D conserva también fallbacks locales para `buildings` y `projects`. La prueba de arranque cubre save nuevo y save heredado incompleto y corre en CI en cada push.
