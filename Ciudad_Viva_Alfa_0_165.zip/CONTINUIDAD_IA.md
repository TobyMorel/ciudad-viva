## Continuación · verificación Alfa 0.165

Se alinearon las regresiones de incendios con el contrato vigente (`deaths`, ruinas de `fireService` y llegada del despacho por `responseRoute`) y el recorrido Chromium con la versión publicada 0.165. Se retiró una comprobación duplicada obsoleta; el comportamiento equivalente sigue cubierto por `test_realistic_city_services_offline.mjs` y `test_fire_destruction.py`. Verificación local: 146 pruebas Python, 94 Node y `test_offline_boot_recovery.mjs` en Chromium pasaron. No cambia el alcance funcional ni el porcentaje orientativo de fases. Próxima mecánica: fase 7, transporte de pasajeros no laborales y transbordos accesibles; probar el efecto en viajes reales y costo operativo, Online/Offline. LAN física pendiente.

## Alfa 0.165 · viajes persistentes en el mapa 3D

Al construir una calle se conservan la posición y ruta de actores ya existentes. Se retiraron peatones y camiones decorativos sin itinerario causal. Los viajes de trabajo, compras y servicios permanecen ligados a personas de la simulación. 142 pruebas Python pasaron. Progreso global no estimable sin pesos verificables de las 34 fases.

## Continuidad más reciente · Alfa 0.159

El botón Construir envía `place` sin contratista para `clinic`, `medicalCenter`, `generalHospital`, `policePost`, `policeStation`, `policeHQ`, `firePost`, `fireStationPlus` y `fireCommand`. `server.py` y `offline.js` cobran el precio de modelo completo y agregan `building` inmediatamente; no agregan `project` ni comprometen cuadrillas. Mantener validación de terreno, ruta y caja; no activar servicio efectivo sin personal/redes. Los proyectos anteriores en guardados terminan por la vía previa. Regresiones: `test_instant_public_services.py`, `_offline.mjs` y `_ui.mjs`; el test antiguo de modelos se actualizó. Fases 4/7/9=60/95/75%; global sin ponderación.

## Continuidad más reciente · Alfa 0.158

`world3d.js` dibuja un río continuo norte-sur mediante `riverEdges(z)` y tres mallas (agua y dos orillas); el túnel regional sigue definido antes de ellas. `waterTile`, `offline.js` (`landWater`), `server.py` (`is_water`) y `game.js` usan x=24 o x=25 como agua, para que la simulación coincida con el mapa y el este conserve terreno desbloqueable. Los montículos esféricos estáticos se retiraron. Test de continuidad en `test_new_settlement.py` y `test_new_settlement_offline.mjs`; no afirmar que hay puentes. Verificar en Chromium el render inicial después de editar geometría: una malla con triángulos orientados hacia abajo desaparece aunque no haya error JS. Pasaron 126 pruebas Python y 83 Offline, más el arranque Chromium y captura de escritorio. Las pruebas de geología y refugio se ajustaron a la nueva inmigración diaria de Alfa 0.157, que aporta capital privado y aumenta el número de llegadas. Fases 4=60%, 7=95%, 9=75%; global sin estimar.

## Continuidad más reciente · Alfa 0.157

`move_households` (server.py) y `advanceOfflineHouseholdMigration` (offline.js) se ejecutan cada día; generan interesados sin techo inicial de 120 y llenan viviendas disponibles. Cada migrante añade 280 de capital privado, la demanda pendiente conserva un mínimo de 4 y se acumula sin parcelas o vacantes. `game.js` mantiene mensajes vecinales descartados en un Set de sesión y una bandeja plegable; CSS móvil la sitúa debajo de las barras de demanda. Tests: `test_new_settlement.py`, `test_new_settlement_offline.mjs`, `test_citizen_inbox_ui.mjs`. Fase 4=60%, global aún no estimable.

## Continuidad más reciente · Alfa 0.156

El reloj compartido pasa a 4 segundos reales por hora del juego en x1: días de 96/48/24 segundos en x1/x2/x4. `simulation_time.js` define el factor JS; `offline.js` lo usa en tiempo real y `server.py` replica la tasa. El render coloca farolas en `(x+y)%2===0`. Las pruebas dedicadas están en `tests/test_simulation_time.mjs` y `tests/test_simulation_clock.py`. Siguiente mecánica: fase 7, pasajeros/transbordos.

# Continuidad inmediata · Alfa 0.154

El menú Offline debe permanecer visible hasta completar `createOfflineWorkerAdapter()` y la primera petición `/api/state`; solo entonces ocultarlo y renderizar después de dos `requestAnimationFrame`. Si falla, mantener el menú, limpiar `S` y permitir reintento. `api()` debe preferir `offlineAdapter` siempre que exista, aunque una ruta vieja intente cambiar el modo. Regresión en `tests/test_offline_boot_recovery.mjs`: Play/Pausa debe alternar el guardado, Ciudad abre `Informe municipal`, construcción no consulta `/api/action` HTTP.

El catálogo usa preview 120px escritorio/100px móvil y escala/cámara más cercana; ajustar el grid si el nuevo tamaño provoca scroll excesivo, sin volver a hacer las tarjetas diminutas. Túnel regional = 4,4 unidades; deja 2 tramos del acceso descubiertos. Verificar en Chromium de catálogo y en miniatura visual al ampliar.

# Continuidad anterior · Alfa 0.153

La partida offline debe quedar como modo autoritativo antes de iniciar y usar un contador `modeGeneration` para invalidar solicitudes LAN antiguas. `startOffline()` espera a que el layout del mapa esté listo, obtiene estado local, invalida `visualSignature` y fuerza `draw()`. `world3d.sync()` construye una escena vacía aunque haya un panel abierto; el bucle animado mantiene `renderer.render()` activo incluso en pausa. Para el túnel `gatewayTunnel`, techo y laterales cubren 8,4 unidades (cuatro tramos exteriores). El panel Construir omite la capa antigua de pestañas de `reference-ui.js`: no volver a envolver `.tool-list`, porque cambia su jerarquía y deja sin altura el grid. Las previews usan un renderer compartido, manejo de error por pieza y geometrías Three válidas.

Pruebas de Alfa 0.153: `tests/test_offline_boot_recovery.mjs` cubre escena/offline, construir sin `/api/action`, túnel y carrera de respuesta LAN; `tests/test_build_catalog_ui.mjs` cubre catálogo, tarjetas 3D y tamaño móvil/escritorio. No declarar probado LAN físico. Taxi UI conserva un timeout pendiente al seleccionar el actor.

# Continuidad anterior · Alfa 0.152

El catálogo del botón Construir se compone en `setupBuildCatalog()` en `game.js`: conserva los listeners de cada herramienta, mueve tarjetas con canvas a una bandeja inferior, filtra por `data-build-category` y llama a `world.renderBuildPreviews()`. Ese método usa un único WebGL renderer reutilizable y una escena de miniaturas generadas con la geometría del juego; no crear un renderer/contexto por tarjeta. Para ampliar los modelos revisar `makeBuildPreview`. En teléfonos: 3 columnas, en escritorio: 6.

Las herramientas `busStop` y `taxiStop` sirven para elegir un depósito existente en el mapa, abrir el editor de línea/circuito y marcar posiciones de parada en calles. El backend de ruta cobra por parada ($350 bus, $220 taxi). Todavía no existe un asiento de pasajero/embarque físico de taxi ni una entidad `taxiStop`; no describirlos como completados.

En `world3d.js`, `view.servicePreview` solo debe reconstruir su cobertura vial. Su coordenada no debe formar parte de `visualSignature`, pues invalidar `trafficRoot` reinicia la orientación de los vehículos en cada desplazamiento del cursor. La cobertura usa celdas de `TILE*.92` para ocupar todo el tramo y se reemplaza con `refreshServiceCoverage()`.

Se corrigió el crecimiento automático inicial para que corra cada día y se quite la barrera de empleos a la primera cohorte de residentes. Verificar zonas conectadas en la misma coordenada de acceso. Las calles se conectan desde `[4,10]`; para visitantes el render usa `cityEntryRoute(openRoads)`, debe recalcularse al cambiar el conjunto de calles. La vegetación procedural de `world3d.js` se actualiza por vista/zoom; no ampliar la densidad sin medir el costo de render. El túnel de entrada se centra en el extremo exterior de esa misma vía.

Construcción: no exigir áridos/acero/madera/hormigón para vivienda, servicios, calles o rehabilitación. Las materias primas permanecen como entradas de producción industrial. La cola `factoryExportOrders` mueve excedentes por carretera, avión o puerto y paga al productor al completar el viaje. Hay prueba terrestre en ambos motores; completar cobertura de barco/avión y revisar logs de CI publicados.

Lógica visual nueva: semáforo se ubica en cada aproximación vial y debe mirar hacia el vehículo entrante; la cara local `+Z` se invirtió en cada eje. Una farola por tile de calle con brazo/lámpara encima del asfalto. Comprobar intersecciones en captura de Chromium si falla el workflow. La ventana de modalidad y demanda tienen escalas compactas/mayores respectivamente.

Verificación tras los cambios: `python3 -m unittest discover -s tests -p 'test_*.py' -v`, suite Node Offline y `node tests/test_ui_layout.mjs`, junto con pruebas de cámara/marcadores. Correo de commit: `66056611+TobyMorel@users.noreply.github.com`. Publicar `main`, confirmar SHA/checks y entregar ZIP sin `.git`, dependencias instaladas ni archivos de partidas. Estimación global sigue no disponible; fases 4/7/9 conservan 60/95/75%.

# Continuidad inmediata · Alfa 0.150

## Alfa 0.150 · taxis con circuito manual visible

`index.html` añade Depósito de taxis a Construir → Logística; quita duplicados en el catálogo. `game.js` reutiliza el editor de paradas con límite taxi de 2–8, acciones de pausa/reanudar/retiro y panel de Movilidad. `server.py` / `offline.js` crean un vehículo único por circuito cerrado, con tope de cuatro por depósito, precio de $2.800 + $220 por parada y $260 de operación mensual. `world3d.js` dibuja el taxi en movimiento y señal física por parada. Las rutas requieren calles conectadas al depósito. Estado de guardado expone rutas y depósitos.

Verificación: `tests/test_manual_taxi_route.py`, `tests/test_taxi_route_offline.mjs`, `tests/test_taxi_route_ui.mjs` y `tests/test_bus_route_ui.mjs` pasan. En Chromium 390×844 y 1440×900 se comprobó el panel sin desborde horizontal, el trazado de paradas, el actor 3D y la ficha al tocar el taxi. La regresión acumulada pasa: 122 pruebas Python y 78 Offline. El render invalida su firma cuando cambia `taxiRoutes`. Taxis todavía no incluye conductores asignados, pasajeros, destinos ni tarifa dinámica; no representar estas partes como completas.

Hito: fase 7 permanece 95%; fase 4 60%; fase 9 75%; estimación global no disponible por falta de ponderación/aceptación común verificable. Próximo alcance: sistemas de pasajero/conductor de taxi, luego subte con estaciones y cámara por debajo de superficie; luego cruceros con turismo y acceso urbano al aeropuerto.

No empezar desde cero. Priorizar mecánicas conectadas, entregar sistemas nuevos en vez de encadenar pulido, ejecutar las verificaciones existentes y publicar cada versión en `main` con GitHub noreply. Leer también `ESTADO_DESARROLLO.md`, `DECISIONES_TECNICAS.md`, `SIGUIENTE_ENTREGA.md` y `AUDITORIA_ROADMAP.md`.

## Alfa 0.149 · líneas diseñadas desde depósitos

`game.js`: desde Movilidad, desplegar cochera, «Trazar línea desde este depósito», seleccionar 2–12 calles en orden con clics, deshacer/cancelar y confirmar flota. Paradas numeradas siguen al mapa y se convierten en señales del mundo. `server.py` y `offline.js`: validan conectividad entre paradas, terminación de depósito, una línea por depósito, fondos disponibles después de contratos; cobran $350/parada y $700/bus y conservan la línea exacta. El cálculo de viajes admite ambos sentidos y transbordos solo en paradas compartidas entre líneas manuales. Líneas automáticas existentes siguen funcionando en partidas viejas.

Pruebas dedicadas: `tests/test_manual_bus_route.py`, `tests/test_bus_manual_route_offline.mjs`, `tests/test_bus_route_ui.mjs` (Chromium 390×844 y 1440×900). Revisar el workflow GitHub tras cada push. Fase 7 sigue 95% por taxis, metro y alcance multimodal aún incompletos; fase 4 60%, fase 9 75%; progreso total no estimable sin pesos verificables.

Siguientes mecánicas: taxi depot y rutas/paradas; transporte subterráneo con capa de cámara; pasajeros/cruceros y turismo portuario; integrar vuelos con destinos y accesos locales. Ya existe comercio por barcos y se dibujan barcos de carga/aviones en condiciones existentes, pero no equivale a cruceros, pasajeros o red aeroportuaria completa.

# Continuidad previa · Alfa 0.148

No empezar desde cero. Priorizar mecánicas conectadas y evitar varias entregas de pulido. Lee también `ESTADO_DESARROLLO.md`, `DECISIONES_TECNICAS.md`, `SIGUIENTE_ENTREGA.md` y `AUDITORIA_ROADMAP.md`. Publicar cada versión en `main` con el correo GitHub noreply configurado.

## Alfa 0.148 · mensajes de vecinos

`game.js` muestra los avisos accionables de `collectCityAlerts` en `#citizenInbox`. La persona que escribe se elige de forma estable entre residentes del hogar más cercano; el texto describe la necesidad registrada. Hay dos tarjetas visibles con enlace «Ver avisos» al panel completo. «Ver» centra/selecciona la ubicación con `world.focusTile` sin modal adicional. La fuente solo usa sistemas/eventos existentes. CSS responsive y tema oscuro en `design.css`; markup en `index.html`.

Prueba `tests/test_citizen_inbox_ui.mjs`: Chromium 390×844 y 1440×900, nombre, mensaje, foco de cámara, solapamiento y popup. `tests/test_city_guide.mjs`: 7 pasan. Fase 9 sigue en 75%, fase 4 en 60%; progreso global no estimable.

## Alfa 0.147 · calles instantáneas

Las rutas se colocan directamente desde el mapa: un clic, un tramo conectado, $1.200 de costo único, sin animación, materiales, proyecto ni cuadrilla. La herramienta continúa seleccionada para encadenar clics. El mantenimiento municipal de $15/mes por tramo sigue integrado al sistema de redes. Acciones Online y Offline validadas, además del modo heredado `place`/`road`.

Pruebas: `tests/test_road_instant.py`, `tests/test_road_instant_offline.mjs`; suite Python reportó 117 aprobadas, Offline 63 aprobadas. Fase 4 continúa en 60%, avance global no estimable.

## Alfa 0.146 · sirenas, fuego, bocinas y semáforos

`game.js` genera sirenas cortas ligadas a intervenciones policiales recientes y respuestas de bomberos, crepitación mientras hay incendios activos, y bocinas ocasionales cuando la cola/demora de tráfico supera los umbrales. Se usa Web Audio procedural para mantener el juego sin paquetes externos; respetar mute, pausa y visibilidad de la pestaña.

En `world3d.js` todos los cruces con tres o más accesos tienen semáforos tridimensionales rojo/ámbar/verde por defecto. La ficha táctil del cruce se implementa en `game.js`; la acción `toggleTrafficSignal` guarda `trafficSignalOverrides` en `server.py`/`offline.js`, por coordenada. `false` es retiro; `true` reinstala. La señal modifica tanto el modelo visual como la espera de vehículos y la espera incorporada al tiempo del viaje. El servidor procesa la acción bajo el lock común para todos los jugadores.

Pruebas añadidas: `tests/test_signal_delay.py` y `tests/test_traffic_signal_offline.mjs`; UI táctil responsive: `tests/test_traffic_signal_ui.mjs` (390×844/1440×900). Antes de cerrar, comprobar la ejecución del workflow `Validación Ciudad Viva` para el SHA publicado. No subir fase 7 (95%) ni fase 9 (75%): permanecen pendientes alivio/confiabilidad del transporte y, en fase 9, patrullaje policial físico, docentes/cobertura y otros bloques listados en `release_notes.json`.

## Estado previo · Alfa 0.145

## Estado de la expansión territorial

La partida nueva arranca con cuatro sectores construibles de 8×8 (16×16 parcelas) y el acceso regional en `(4,10)`. Los sectores contiguos del frente muestran candados 3D. Al seleccionar uno aparece su tamaño, coordenadas, precio y un botón para comprarlo. La compra exige adyacencia y fondos municipales libres tras reservar contratos; cada compra queda persistida y habilita calles, zonas y obras. El precio del sector depende del anillo: `$3.500 + $2.200 × (anillo−1)`, mínimo $3.500.

Lógica Online en `server.py`: `ensure_land_claims`, `land_chunk_info`, `land_frontier`, `unlock_land_chunk`; `place`/`zone` validan que el sector esté comprado. La acción `/api/action` corre bajo el lock global. Lógica Offline paralela en `offline.js`: `ensureOfflineLandClaims`, `offlineLandInfo`, `offlineLandFrontier`, acción `unlockLand`. Interfaz y selección en `game.js`; iconos en `world3d.js`; ficha en `design.css`. El estado guarda solo la lista de sectores adquiridos y calcula el frente al leer, para no persistir una lista infinita. Coordenadas negativas usan floor en ambos motores. Guardados anteriores abren automáticamente el terreno ocupado.

El mapa jugable no tiene límite fijo de coordenadas; el suelo visual se desplaza alrededor de la cámara. No se han implementado aún biomas ni relieve procedural, y la escala práctica sigue limitada por memoria, precisión y rendimiento del equipo. Fase 1 pasa de 70% a 75%; siguen pendientes catastro/derechos de propiedad y pruebas de ciudades grandes.

## Verificación de Alfa 0.145

114 pruebas Python; 74 pruebas Node Offline/modelo; cuatro escenarios de estrés con 30 años cada uno; Chromium de cámara/alertas, UI general y compra de terreno en 390×844 y 1440×900; sintaxis y JSON válidos. Prueba de LAN física entre dos computadoras no realizada. Global no estimable: no existen pesos de aceptación comunes verificables para las 34 fases.

## Próximo trabajo

Completar catastro y derechos de propiedad de parcelas en Online/Offline, persistir dueños/usos y conectarlos con expansión; añadir pruebas de guardado/carga y cámara en sectores muy alejados. Luego rotar hacia mecánicas de menor cobertura (fase 9, patrulla física que recorre calles y responde incidentes). Evitar profundizar la presentación de candados por varias versiones.

## Reglas de publicación

Configurar autor exacto `Tobias Morel <66056611+TobyMorel@users.noreply.github.com>`, hacer push directo a rama `main`, confirmar SHA y estado de CI y entregar ZIP completo excluyendo `.git`, cachés y ZIP anteriores. No declarar una prueba LAN o porcentaje global sin evidencia.

## Continuidad histórica

El usuario pidió retirar confirmaciones repetitivas al construir calles y edificios. En `game.js`, `placeQuick` invoca la acción autoritativa `place`/`rescue` con cuadrilla automática y encadena acciones en `placementQueue`; deja activa la herramienta para repetir clics. Las obras conservan animación y progreso por etapas. El diálogo de `bidBackdrop` se quitó del HTML y ya no hay llamadas a `openBid`. Errores de presupuesto, sitio o cuadrilla siguen apareciendo mediante `send`/aviso.

En catálogo, `showBuildHelp` crea una ayuda compacta con descripción, costo, plazo, dotación y etapas para las obras. Se activa con hover, foco y toque móvil. El precio/plazo es estimativo con la cuadrilla disponible en ese momento; validación final autoritativa del servidor no cambia. No confundirla con la ficha municipal al seleccionar parcelas ni con confirmaciones de pedidos de materiales.

Regresión: `tests/test_build_preview_ui.mjs`, Chromium 390×844 y 1440×900; verifica la ayuda y la colocación sucesiva de dos consultorios sin modal y con el modo activo. Fase 2 queda en 75%; este cambio es usabilidad y no cumple criterios nuevos de fase. Global `null` por falta de pesos comunes verificables. Siguiente mecánica: fase 9, patrulla física para incidentes; luego farolas garantizadas en nuevas calles. Autor Git: `66056611+TobyMorel@users.noreply.github.com`. Publicar a `main`, revisar CI/Vercel y crear ZIP completo desde el commit publicado.

# Continuidad para otra IA · Alfa 0.141

**No empezar de cero.** Lee `CONTINUIDAD_IA.md`, `ESTADO_DESARROLLO.md`, `DECISIONES_TECNICAS.md`, `SIGUIENTE_ENTREGA.md` y `AUDITORIA_ROADMAP.md` antes de modificar el motor. Conserva Online/Offline en paridad y los guardados viejos; no cambies servicios, economía o infraestructura existente por contadores cosméticos.

Esta entrega agrega mortalidad y capacidad funeraria: `server.py` (`ensure_urban_evolution_state`, `natural_death_threshold`, `process_funeral_queue`, `advance_urban_evolution`, `urban_evolution_report`); `offline.js` tiene la paridad con `ensureOfflineUrbanEvolution`, `offlineNaturalDeathThreshold`, `processOfflineFuneralQueue`, `advanceOfflineUrbanEvolution`, `offlineUrbanEvolutionReport`. Los catálogos de modelo están duplicados coherentemente en `game.js`, `server.py` y `offline.js`; el catálogo UI está en `index.html`; el aspecto 3D en `world3d.js`. Pruebas añadidas: `tests/test_funeral_services_online.py`, `tests/test_funeral_services_offline.mjs`; UI dedicada en `tests/test_funeral_ui.mjs` y catálogo ajustado en `tests/test_ui_layout.mjs`. Verificado: 107 Python, 71 Node, estrés de 30 años × cuatro perfiles y Chromium en 390×844/1440×900.

Importante: `ensureOfflineUrbanEvolution()` corre antes de que algunas constantes del catálogo estén inicializadas. Mantén esa migración sin leer `SERVICE_MODELS` desde la zona TDZ. El fallecimiento retira a la persona y deja una plaza; la migración mensual puede ocuparla después, esto no es duplicación de población. La cola funeraria debe procesarse a diario aunque la edad sólo avance por cambio anual. Cemetery limit 120 permanente; crematorium limit 24/año; conectividad vial hasta acceso `(4,10)` y ruta de origen a instalación.

Continuar en este orden: (1) robo con patrulla física y asignación de unidades disponibles, (2) farola por tramo apuntando a calzada y ciclo nocturno, (3) revisar crecimiento visible de nueva partida y demanda residencial. Cortes breves por mecánica; el usuario prioriza sistemas jugables sobre pulido visual prolongado. No retirar materiales de la obra pública ni el flujo de contratista: las exenciones ya existentes son para desarrollo residencial/comercial/industrial privado.

Para publicar cada versión: configurar commit como `Tobias Morel <66056611+TobyMorel@users.noreply.github.com>`, subir a rama `main`, comprobar SHA/estado CI y crear ZIP completo excluyendo `.git`, archivos ZIP antiguos y caches. Progreso total sigue `null`/no estimable mientras no se establezcan pesos verificables comunes para las 34 fases.

# Continuidad para otra IA · Alfa 0.140

Objetivo vigente del usuario: desarrollar sistemas nuevos del roadmap de forma acumulativa; evitar varias entregas de pulido. Mantener todo en GitHub `main`, probar Online/Offline y la UI si cambia, no afirmar cobertura sin evidencia. Cada paquete de continuidad debe incluir el repositorio completo. Conservar autor Git configurado `66056611+TobyMorel@users.noreply.github.com`.

Esta versión trabaja fases 1/4/5/9: el servidor Online inicia vacío, y nuevas partidas Online/Offline también con 0 habitantes, puerta vial regional, demanda inicial 36 personas y migración de arranque que no exige empleos; el mapa representa la carretera exterior y vehículos entrantes; vivienda zonificada con insumos incluidos en inversión privada; desarrollo comercial por población y fábricas por actividad; partículas 3D de incendio (11 llamas/18 humos por evento); avisos policiales y de bomberos explícitos y seleccionables. Guardados existentes se conservan.

Archivos de lógica: `server.py`, `offline.js`, `world3d.js`, `cityGuide.js`, `game.js`. Pruebas añadidas: `tests/test_new_settlement.py`, `tests/test_new_settlement_offline.mjs`; modificadas: `tests/test_private_construction_supply_online.py`, `tests/test_private_construction_supply_offline.mjs`, `tests/test_port_import_ui.mjs`. La prueba de importación/UI pasó en Chromium con 390×844 y 1440×900. En la primera suite integral se encontró el contrato viejo que esperaba que zonificación privada enviara insumos municipales; fue cambiado según la petición del usuario. Repetir la batería completa antes de dar por cerrada.

Pendientes expresos: mortalidad y cupos de cementerio/crematorio; delito como evento físico y patrulla visible/resolutiva; farola real por tramo de calle; hacer más observable/rápido el crecimiento de parcelas; conexión LAN en dos PC. No declarar esas características listas.

No hay pesos comunes verificables para estimar el juego completo: `overallProgress` debe quedar `null`/no estimable. Fase principal 4 conserva 60%; no elevarla por el mero conteo de pruebas. Consulta `ESTADO_DESARROLLO.md`, `DECISIONES_TECNICAS.md`, `SIGUIENTE_ENTREGA.md` y el roadmap visual en `release_notes.json`.

# Continuidad inmediata · Alfa 0.139

Se completó un tramo de fase 23: importación portuaria de acero visible e inspeccionable. Referencias: creación de remesas en `server.py`/`offline.js`, avance y descarga en `advance_maritime_steel_shipments`/`advanceOfflineSteelShipments`, escena/actor en `world3d.js`, informe Ciudad → Puerto en `game.js`. Datos de importación reutilizan `supply.portVoyages` con `direction: "importación"` y `shipmentId`; no mezclar con viajes exportadores. El buque se mueve suavemente en fracción de día, queda atracado con entrega parcial y se retira al descargar. El acero entra al proveedor por capacidad real diaria. Remesas antiguas crean viaje visual al procesarse. No detener el loop de 3D al mostrar popup: los actores deben seguir animados debajo. Al inspeccionar actores, `selectedActor` debe limpiarse al volver a Ciudad para mostrar sus secciones. Regresiones: `test_maritime_steel_import_online.py`, `test_maritime_steel_import_offline.mjs`; responsive y selección en `test_port_import_ui.mjs`. Pasan Python (99) y Node Offline/modelos (66). Fase 23: 45%, parcial. Próximo: otras mercancías/depósitos con cadena real y límites físicos; alternar después a otra fase subdesarrollada en vez de profundizar detalle portuario en varias entregas.

# Continuidad inmediata · Alfa 0.138

Se añadió una estimación parcial de ciclo de vida a la ficha municipal en `game.js`, con horizontes 1/4/10/20 años, construcción, operación explícita de ciertos modelos educativos/sociales y reserva presupuestaria de mantenimiento del 2,5% anual. Es crucial conservar la semántica: costos no implementados dicen “no cuantificada”; mantenimiento es un supuesto de planificación, no se descuenta. No presentar esto como la fase 29 terminada. La fase sube 50→60 porque el quinto bloque de la rúbrica fija (ciclo de vida) pasa de ausente a parcial; 100/50/50/50/50. Prueba responsive ampliada en `tests/test_build_preview_ui.mjs`. Próximo foco: hacer que costos por personal, suelo/diseño, operación, renovación y cierre se alimenten desde los sistemas reales; ampliar escenarios fiscales a 1/4/10/20 años. Mantener entregas de mecánicas nuevas, evitando pulido prolongado.

# Continuidad inmediata · Alfa 0.133

El usuario decidió quitar la licitación/selección manual de constructora para iniciar edificios. El modal core vive en `game.js` (`openBid` conserva ese nombre legacy; renombrar en una pasada posterior si se desea). Ahora presenta costo estimado, plazo base, trabajadores, pagador y etapas; `automaticContractor` filtra disponibilidad y elige la oferta compatible de menor costo. El botón dice “Iniciar construcción”. La acción `/api/action` y el contrato/stages siguen funcionando como antes, por lo que el edificio todavía exige cuadrilla, materiales, presupuesto y revisión. El modo Offline usa el mismo flujo de cliente. Anexos y rehabilitaciones ya no muestran selectores de empresa; la asignación se hace internamente. La prueba Playwright `tests/test_build_preview_ui.mjs` valida ficha, precio del consultorio, ausencia de empresas, encuadre responsive e inicio real de la obra a 390×844 y 1440×900; `tests/test_school_expansion_ui.mjs` comprueba que el anexo no ofrezca selector. Verificación: 92 pruebas Online, 51 Offline y stress 30 años × cuatro perfiles.

No confundirlo con demolición del sistema de contratistas. Al usuario le interesa quitar el trabajo de comparar/seleccionar empresas, conservar construcción por etapas y dedicar próximas versiones a contenido nuevo del roadmap. La fase 2 queda en 75%, global `null`; no inflar avance por este cambio de interfaz. Próximo alcance: fase 28, atención/cuidado de adultos mayores conectada con vecinos, accesibilidad, transporte, personal y caja.

# Continuidad inmediata · Alfa 0.132

Mantener el objetivo del usuario: añadir mecánicas del roadmap en cada entrega, no encadenar varias versiones de pulido. Cada cambio se publica en `main`; si hay UI, comprobar móvil y escritorio sin textos ocultos/solapados. Entregar ZIP del `HEAD` publicado. Autor Git: `66056611+TobyMorel@users.noreply.github.com`.

La mecánica de refugio de Alfa 0.131 ahora también ampara hogares establecidos afectados por desastres. `server.py:displace_home_residents` y `offline.js:displaceOfflineHomeResidents` mueven residentes conservando identidad, empleo y padrón. Tormenta fuerte (runoff >=75 m³) o inundación repetida; incendios con calidad <=35. Reserva el lote original siete días, prioriza esas familias en camas y permite regreso si la vivienda está habitable. La migración mantiene una cola independiente; un evacuado no reduce demanda pendiente ni convierte en vaga una casa reservada. Economía identifica personas evacuadas.

Regresiones añadidas: `tests/test_social_shelter_online.py` incluye inundación/retorno; `tests/test_disaster_displacement_offline.mjs` recorre una tormenta real del calendario Offline y el retorno luego de reabrir la partida. El patrón `tests/*_offline.mjs` ya las incorpora al workflow. `tests/test_ui_layout.mjs` revisa la tarjeta de desplazados en Economía a 390×844/1440×900. Verificado en esta entrega: 92 pruebas Python, 62 Node Offline, stress de 30 años × cuatro perfiles, batería UI completa y checks de sintaxis/diff limpios.

Siguiente mecánica: fase 28, cuidado de adultos mayores ligado a población que envejece, capacidad sanitaria/accesibilidad, personal y transporte. Después educación técnica vinculada con puestos. Fase actual 28=85% orientativo; global sin estimar por falta de ponderación común. LAN física pendiente. Verificar Actions/Vercel y generar ZIP desde el commit confirmado.

# Continuidad inmediata · Alfa 0.131

Objetivo de trabajo actual: ampliar mecánicas del roadmap con alcance útil por entrega; no encadenar varias versiones de detalle visual. El usuario espera que cada cambio llegue a GitHub `main`, UI revisada si se modifica, y ZIP completo para continuar en otra sesión. Mantener el autor `66056611+TobyMorel@users.noreply.github.com`.

Esta entrega añade refugio público temporal en `server.py`, `offline.js`, `game.js`, `world3d.js` e `index.html`. Se construye desde el catálogo; cuesta $14.800, tarda 92 días y al recibirse opera por $1.180/mes. Tiene 30 camas, 12 empleos base, admite solo con personal, ruta y servicios y limita capacidad al financiamiento de Servicios. Admite migrantes que no hallaron hogar; cuando queda una vivienda, se realojan antes de la siguiente admisión, conservando el mismo conteo poblacional. Economía expone capacidad, espera, ocupación, costos y resultados.

Regresiones dedicadas: `tests/test_social_shelter_online.py` y `tests/test_social_shelter_offline.mjs`; el test de modelos comprueba catálogo y recepción; `tests/test_ui_layout.mjs` incluye tarjeta/catálogo del refugio en 390×844 y 1440×900. No declarar suite integral o stress pasado hasta ejecutarlos en esta sesión.

Próximo sistema: alojar temporalmente hogares ya residentes desplazados por emergencias y conectar adultos mayores a capacidad de atención. Asegurar identidad/conteo poblacional sin duplicación, fondos y realojamiento. Fase 28=83% orientativo; global sin estimar por falta de pesos comunes verificables; LAN entre equipos físicos pendiente. Usar author arriba, publicar a `main`, verificar SHA/Actions/Vercel y construir el ZIP desde el commit publicado.

# Continuidad inmediata · Alfa 0.130

Implementado primer programa jugable de protección social: cupo de ayuda de alquiler por mes, priorización por ingreso/habitante, elegibilidad solo con mora real en vivienda convertida por reconversión privada y transferencia directa al propietario. Tope $5.000, ajuste $250; el gasto se suma a Servicios y la financiación fiscal determina cuánto llega. Se registra balance en `socialServices.lastReport/history` y en cada hogar. No entregamos cash indiscriminado. `game.js` expone el ajuste y el resultado dentro de Economía; `server.py` y `offline.js` aplican el mismo cierre.

Pruebas: `tests/test_social_housing_aid.py`, `tests/test_social_housing_aid_offline.mjs`; 89 Python, 59 Offline y stress de cuatro perfiles × 30 años pasan. Se añadió comprobación responsive de la nueva tarjeta a `tests/test_ui_layout.mjs`; Chromium pasó a 390×844 y 1440×900, sin recorte/overflow y con ambos controles visibles. Próxima mecánica prioritaria: refugios con personal, cupos, acceso y resultados. Fase 28=78%, global `null` por falta de pesos comunes verificables. Conservar autor Git `66056611+TobyMorel@users.noreply.github.com`; publicar en `main`, comprobar GitHub/Vercel/Actions y hacer ZIP.

## Continuidad inmediata · Alfa 0.129

La ampliación escolar existe en `server.py` y `offline.js`; el panel y selección de constructoras permanecen en `game.js`/`style.css` de Alfa 0.128. Este release encontró y arregló un bloqueo real: al completarse un anexo Offline, la recepción llamaba `completeOfflineSchoolExpansion(p, quality)` aunque esa variable no existía dentro de `complete()`. Usa ahora la calidad derivada del contratista; Sur Obras y Delta dan calidades diferentes. La recepción persiste materiales consumidos/requeridos, costo, calidad, plazas y vacantes en `school.expansionHistory` y crea la garantía contractual.

Pruebas de flujo completo: `tests/test_school_expansion.py` avanza la obra Online hasta el último certificado; `tests/test_school_expansion_offline.mjs` avanza días Offline, comprueba perfil Sur Obras, cinco materiales consumidos, cuatro certificados, nuevas plazas e historial. Suite local: 86 Python, 58 Node Offline; sin cambios de interfaz.

Evitar versiones de pulido: la siguiente mecánica debe ser protección social con hogares elegibles, presupuesto real y efectos medibles; comprobar antes que los anexos ya ampliados contraten profesores sin asignación gratuita. Progreso: fase 9=70%, global null por falta de pesos verificables comunes. Mantener `66056611+TobyMorel@users.noreply.github.com`, push a `main`, verificar Vercel/Actions y entregar ZIP.

## Continuidad inmediata · Alfa 0.128

La acción municipal **Ampliar escuela** vive en `server.py` (`contract_school_expansion`, `complete_school_expansion`) y `offline.js` (`contractOfflineSchoolExpansion`, `completeOfflineSchoolExpansion`). El panel está en `game.js` dentro de `educationPanel()` y sus controles responsive en `style.css`. Agrega hasta dos aulas por contrato, una obra activa por sede y máximo de seis aulas adicionales sobre el modelo inicial. El pago de anticipo no habilita cupos: aulas, vacantes docentes y costo de operación cambian al inspeccionar. El empleo de docentes sigue siendo una decisión de simulación; las vacantes no se cubren mágicamente.

Pruebas nuevas: `tests/test_school_expansion.py`, `tests/test_school_expansion_offline.mjs`, `tests/test_school_expansion_ui.mjs`; el workflow responsive incluye la última. En el estado de esta entrega pasan 85 pruebas Python, 57 Node Offline y la prueba UI 390×844/1440×900. La prueba completa de entrega/consumo de materiales y recepción final sigue pendiente.

No volver a pulir pantallas durante varias versiones: cerrar esta mecánica con una prueba de obra integral y luego añadir cobertura/docentes/demanda y otro sistema del roadmap. Fase 9=67%; progreso global null por falta de pesos comunes verificables. Conservar el autor de GitHub `66056611+TobyMorel@users.noreply.github.com`, publicar cada versión en `main` y comprobar SHA/CI antes de cerrar.

## Continuidad inmediata · Alfa 0.127

En Economía se elige `programPriority` para ordenar los pagos de servicios, redes/residuos y movilidad cuando hay caja insuficiente. `server.py`: `municipal_program_priority`, `set_municipal_program_priority`, `settle_municipal_program_budgets`, action `setProgramPriority`. `offline.js`: migración en `defaultProgramBudgets`, action equivalente y liquidación que respeta el orden. `game.js`: botón “Poner primero” por programa. Las asignaciones impagas conservan mora y afectan cobertura/mantenimiento/recogida/operación. Pruebas: `tests/test_municipal_budget_priority.py`, `_offline.mjs` y UI integrada en `test_municipal_forecast_ui.mjs`.

Fase 8=97% orientativo; todavía falta un escenario fiscal recuperable completo y medir continuidad/recuperación de salud, educación, redes, residuos y colectivos. Global sin porcentaje; LAN física sin verificación entre equipos.

## Continuidad inmediata · Alfa 0.126

La previsión fiscal ahora expone `earlyWarning` Online (`municipal_finance_forecast`) y Offline (`offlineMunicipalForecast`) con primer mes de `fundingGap`: etiqueta/offset, faltante, presiones del mes y sugerencias. Es solo proyección; no toca caja ni asignaciones. `game.js` lo muestra fuera del acordeón mensual para que sea visible sin abrirlo. `tests/test_municipal_forecast_ui.mjs` carga una ciudad insolvente y mide aviso/textos/overflow/solapamientos en 390×844 y 1440×900.

Fase 8=95% orientativo; falta escenario fiscal recuperable punta a punta y prueba de cinco servicios. Global no estimable sin pesos comunes verificables; LAN física pendiente. Suite: 80 Python, 54 Node, stress 30 años × 4 perfiles y aviso responsive pasan.

**Siguiente:** ensayar déficit moderado, mora, decisiones y recuperación de cinco servicios en ambos motores.

## Continuidad inmediata · Alfa 0.125

La fase 8 ahora mide `taxes.lastReport.pressure` (ambos motores): tributos pagados / salarios de hogares + ventas empresariales + tributos. La barra “Presión impositiva” existente en Economía consume este dato. Sobre 5%, cada tramo completo adicional de 5 puntos resta un punto de apoyo distrital y un candidato mensual a la migración (máximo cinco). La presión alta solo usa pagos reales; los impagos siguen con sus efectos de mora. Los helpers Online son `tax_pressure_penalty` y `tax_adjusted_migration_demand`; Offline exporta `taxPressurePenalty` y `taxAdjustedMigrationDemand`.

Tests: 80 Python / 54 Offline; stress 30 años × cuatro perfiles pasó. Fase 8 sigue 90%: falta escenario integral crisis-recuperación incluyendo cinco servicios. Global no estimable por falta de pesos verificables comunes. Playwright de Economía pasó en 390×844 y 1440×900, sin desbordes ni solapamientos. LAN física pendiente.

**Siguiente:** probar la crisis moderada de punta a punta y medir servicios; no hacer una entrega de pulido.

## Continuidad inmediata · Alfa 0.124

La mora tributaria de una empresa reduce su línea de crédito: `business_credit_limit_after_tax` en `server.py` y `taxAdjustedBusinessCreditLimit` en `offline.js` restan los atrasos del límite comercial. Con tres cierres seguidos impagos los nuevos giros se congelan; la deuda bancaria existente sigue su calendario. Al quedar al día, vuelve el límite disponible. La regla se usa al financiar caja y compras, no solo para mostrar el dato. El cobro emite eventos al tercer impago y al regularizarse. Tests: Online cubre cálculo, giros y ciclo de mora; Offline cubre límites equivalentes. Sin cambios de interfaz.

Fase 8=90% orientativo; falta probar el escenario fiscal completo enlazando impuestos, presupuestos, caja, empleo, demanda, apoyo y recuperación de cinco servicios en ambos motores. El avance global sigue no estimable sin pesos comunes verificables para 34 fases. LAN física pendiente.

**Siguiente:** priorizar la validación integral de la crisis recuperable; no dedicar una entrega solo a pulido.

## Continuidad inmediata · Alfa 0.123

Fase 8 suma recuperación fiscal gradual del nivel de servicios. `finance.programBudgets.financialServiceImpact` (Online) y su contraparte Offline registran solo los puntos que efectivamente bajaron por la falta de fondos del programa de servicios. No incluye pérdidas por contaminación, deterioro, epidemias u otras causas. Cuando la factura corriente está cubierta y toda la mora de servicios se cancela, se restaura un punto por cierre mensual, limitado a la deuda fiscal registrada y al máximo 100. La migración crea el campo en partidas previas. Tests Online y Offline cubren default, mora que bloquea recuperación y disminución gradual del saldo.

No se modificó la UI. Fase 8=85% orientativo; faltan escenarios que conecten impuestos/presupuesto con empleo, demanda y apoyo, además de validar una crisis y recuperación a lo largo de salud, educación, residuos, redes y colectivos. Global no estimable sin pesos comunes verificables para 34 fases. LAN física sigue sin verificar.

**Siguiente:** completar la cadena causal económica de fase 8 y validar los cinco servicios sin dedicar una entrega a detalle visual.

# Continuidad de desarrollo para otra IA

## Continuidad inmediata · Alfa 0.122

Fase 8 añade mora persistente en créditos municipales Online (`server.py`) y Offline (`offline.js`). Un mes sin fondos suficientes para la cuota, incluso contando la reserva utilizable, agrega esa cuota a `paymentArrears`, conserva principal y plazo sin amortizar y aumenta `delinquentMonths`. En recuperación se cobra la cuota corriente más hasta una cuota vencida por crédito; el registro vencido se reduce, pero no se suma otra vez al principal. Los préstamos no se cierran hasta saldar principal y mora; el mes final ajusta la liquidación al saldo restante. La capacidad de crédito descuenta mora.

La previsión móvil simula los mismos impagos, el uso de reservas, mora de cuotas y recuperación. Economía muestra la mora y el calendario previsto. Chromium pasó Hacienda con mora de prueba en 390×844 y 1440×900, incluyendo textos, límites, desbordes y solapamientos. El workflow omitirá screenshots del canvas 3D por SwiftShader, pero conserva un artefacto texto con el resultado de las comprobaciones. Suite de esta entrega: 73 pruebas Python, todas las pruebas Node Offline, inspección responsive de finanzas, checks sintácticos y stress 30 años × 4 perfiles. Fase 8=80% orientativo; falta enlazar una crisis fiscal completa con recuperación real de cinco servicios, empleo/demanda y apoyo ciudadano. Avance global no estimable por falta de pesos verificables comunes para 34 fases.

## Continuidad inmediata · Alfa 0.121

Corrección del workflow responsive reportado por GitHub: Playwright capturaba páginas completas repetidamente mientras el navegador dibujaba Three.js en software; el screenshot del panel turístico excedió los 30 segundos. `tests/test_ui_layout.mjs` ya no hace screenshots. Conserva las comprobaciones del DOM y límites de viewport para Economía, turismo, salud, seguridad, tráfico y vehículos de emergencia a 390×844 y 1440×900. Se quitó el paso de subir capturas que ya no se generan. La suite responsive completa local (camera markers + layout + respuesta de servicios + previsión financiera) pasó en el orden configurado por CI. El progreso jugable no cambia: fase 8=75% orientativo; avance global no estimable. Próximo sistema sigue siendo estrés fiscal y continuidad de servicios.

## Continuidad inmediata · Alfa 0.120

La fase 8 suma una previsión fiscal móvil de doce meses en Online (`server.py:municipal_finance_forecast`) y Offline (`offline.js:offlineMunicipalForecast`). Recalcula impuestos con las tasas vigentes y la cobranza observada; conserva ingresos no tributarios y costos operativos al nivel actual; aplica partidas presupuestarias y acumula atrasos; agenda obligaciones de obras dentro del plazo pendiente; amortiza créditos mes a mes. Informa el primer mes con caja negativa, compromisos, garantías y caja libre después de obras y mora. Es una consulta, no modifica el saldo real. La tarjeta “Previsión móvil” está en Economía/Hacienda y despliega los doce meses.

La inspección UI se ejecutó con Chromium en 390×844 y 1440×900: doce tarjetas, sin desborde horizontal, recorte ni solapamiento. Pruebas de esta entrega: 68 Python, todas las pruebas Node Offline, syntax checks, tres regresiones Online de finanzas, una regresión Offline de finanzas y estrés 30 años/4 perfiles. Global no estimable: no existe ponderación común verificable para las 34 fases. Fase 8=75%; faltan escenarios, estrés de déficits recuperables/impagos y continuidad de servicios. Próximo: completar esa validación fiscal, con efectos en servicios.

## Referencia previa · Alfa 0.119

Los desvíos de fase 7 ya afectan el transporte de materiales en ambos motores. Online (`server.py:process_supply_orders`) y Offline (`offline.js:processOfflineMaterialOrders`) conservan `currentPosition`, la última intersección alcanzada. Cada día buscan ruta desde ese punto; si coincide con el sufijo vigente mantienen el avance; si la ruta cambió reinician el progreso solo desde la intersección actual. Al cerrarse el camino el camión espera con su posición guardada, y reanuda desde ahí cuando vuelve a haber conexión. El tiempo previsto usa `plannedArrivalDay` como línea base, sin reiniciar la demora al recalcular la ruta. Online aplica congestión de los tramos aún pendientes; Offline incorpora el aumento real de longitud por el desvío.

Regresiones: `tests/test_supply_detour_progress.py` y `tests/test_supply_detour_progress_offline.mjs`; el flujo de compras automáticas Offline conserva su entrega tras el cambio. Antes de la entrega pasaron 65 tests Python, 47 Node no visuales y stress de 30 años/4 perfiles. No se cambió la interfaz. Repetir pruebas responsive cuando haya entorno GPU/de navegador con tiempo suficiente; LAN física no comprobada.

Fase 7=95% orientativo, no elevar sin medir alivio en redes grandes y fiabilidad de buses. Progreso global no estimable sin pesos comunes verificables para las 34 fases. Próximo sistema: fase 8, previsión presupuestaria móvil de 12 meses, con ingresos, costos, reservas, contratos y deuda conectados al saldo real.


## Continuidad inmediata · Alfa 0.116

`simulation_time.js` comparte formato HH:mm, evaluación de noche/luz solar y asignación de las franjas pico. `server.py:advance_simulation_clock` mide avance en horas: elapsed segundos × velocidad; `simulation_loop` toma como autoritativa `state.timeOfDayMinutes`, y procesa una jornada al cruzar 24:00. Offline interactivo hace lo mismo; conserva un solo día por paso y guarda `timeOfDayMinutes`. No cambiar la ejecución determinista de pruebas/regresiones que usa días artificiales sin activar `setRealtimeClock(true)`. A ×1 una jornada dura 24 s reales y a ×4 dura 6 s.

`game.js` dibuja hora y franja del reloj en el mapa y panel Tráfico. `world3d.js:updateLighting` interpola cielo, niebla, hemisferio, luz solar/exposición, y las farolas de `addRoad` habilitan PointLight, bulbo y charco de luz cálida. El render anima la transición a frame por frame mientras el estado de simulación se actualiza en la frecuencia correspondiente. Las franjas de demanda siguen modeladas por colas de día, no se recalculan cada segundo; la pantalla marca qué franja horaria está activa.

Pruebas: `tests/test_simulation_time.mjs`, `tests/test_realtime_clock_offline.mjs`, `tests/test_simulation_clock.py`; workflow contempla el nuevo módulo. Siguiente mecánica prioritaria en fase 7: conexiones alternativas/desvíos con efecto medible en las colas, además del retraso logístico. Mantener pruebas responsivas del mapa, formato de estado persistido, CI, publicación a main y ZIP integral.

## Continuidad inmediata · Alfa 0.115

Mecánica añadida: en `server.py`, `traffic_queue_step`, `traffic_queue_delay` y `advance_traffic_queues` calculan carga/capacidad y colas por tramo para nueve horarios. En `offline.js`, `advanceOfflineTrafficQueues` mantiene el mismo formato. Estado guardado: `traffic.queueState = {lastDay, queues}` y reporte `traffic.queueReport` con resumen de franjas y segmentos. La rutina es idempotente dentro del día, depura segmentos que ya no son calles y transporta el remanente al próximo día. Demanda: viajes en auto por ventana, salidas de buses por horario y pedidos de suministro en tránsito; en Online se anticipa el retorno laboral para cargar la franja de tarde/noche, y el regreso también suma su espera de cola y semáforo.

La demora suma a rutas motorizadas y recalcula asistencia y puestos efectivos; peatones quedan fuera. El panel se dibuja en `game.js:renderTrafficPanel` y usa datos reales `S.traffic.queueReport`; sus estilos viven en `design.css`. `traffic.js` comparte helpers y `tests/test_traffic_model.mjs` los prueba. `tests/test_traffic_queues_offline.mjs` protege el informe persistido Offline; `tests/test_traffic_capacity.py` protege la acumulación e idempotencia Online. Mantener formato/paridad de ambos motores cuando cambien horarios, buses o logística.

Progreso global no estimable por falta de ponderación verificable de las 34 fases. Fase 7=90% orientativo; hito actual F. Próximo: desvíos por obras/cortes y prueba de alivio al abrir un acceso alternativo; después seguir a la fase 8 o a sistemas F restantes, sin dedicar una entrega a pulido menor. LAN entre equipos físicos continúa sin verificar.

# Continuidad de desarrollo para otra IA

## Continuidad inmediata · Alfa 0.114

En `server.py`, `advance_simulation_clock()` preserva tiempo pendiente y `simulation_loop()` procesa como máximo una jornada por vuelta, a intervalos de 50 ms; una pausa pone el acumulador a cero. Mantén el límite de un día por vuelta para evitar ráfagas que bloqueen peticiones LAN.

En `offline.js`, `setRealtimeClock(true)` activa el modo interactivo: una sola jornada por consulta y deuda de tiempo pendiente conservada. `game.js:poll()` consulta a 1/2/4 Hz de juego (una vez, dos o cuatro veces por segundo) compensando el tiempo que tardó la consulta. Las pruebas de regresión no activan el reloj real salvo `tests/test_realtime_clock_offline.mjs`; no alteres el modo determinista que usan los tests existentes.

En `world3d.js`, `simulationClock` escala actores con la velocidad y los congela en pausa sin detener la cámara ni el oleaje. `applyTrafficQueue()` en `traffic.js` ordena actores por tramo dirigido y carril para mantener distancia; en una señal roja el primero se detiene y los demás forman fila. La función de cola se prueba en `tests/test_traffic_model.mjs`. Próximo: demanda por hora con colas persistentes que entren al cálculo de viajes y colectivos Online/Offline. No dedicar versiones a pequeños detalles mientras el resto de las 34 fases siga parcial.

Progreso global no estimable; fase 7=85% orientativo. Validar ambas plataformas al ampliar la lógica; la conexión entre dos equipos LAN sigue sin verificación física.

# Continuidad de desarrollo para otra IA

## Continuidad inmediata · Alfa 0.113

Cambio de cámara: en `game.js`, las rutas de arrastre, rueda, zoom, rotación y teclado llaman `setCameraView()`, que agrupa un `requestAnimationFrame` y ejecuta `renderAlertMarkers()` mientras el gesto sigue activo. No volver a actualizar solo en `pointerup`/`wheel` terminado. `tests/test_camera_markers.mjs` comprueba coordenadas cambiantes antes de `mouseup` en móvil y escritorio.

Fase 7: `server.py:road_incident_report` y `offline.js:calculateOfflineRoadIncidents` generan choques deterministas con causas y consecuencias, bloqueo vial, duración, costo/servicio, respuesta de bomberos y ruta animada en `world3d.js`. `cityGuide.js` informa del motivo. Preservar la paridad Offline/Online y probar los bloqueos; no mostrar iconos solo por decoración. Siguiente mecánica: capacidad y colas persistentes por horario para tráfico, manteniendo el foco del usuario en contenido de sistemas y no varias versiones de detalle.

Progreso global no estimable: siguen faltando pesos globales verificables para las 34 fases. Fase 7 orientativa 85%. Verificar la publicación `main` y estado Vercel después del commit; LAN física no verificada.

# Continuidad de desarrollo para otra IA

## Continuidad · Alfa 0.112

La capacidad de cada tramo considera jerarquía vial (eje principal 2.4, barrio 1.2) y baja con la condición de `roadAssets`. `traffic.js` comparte el cálculo Offline y sus pruebas. Online aplica el mismo factor en `traffic_factor`; el mapa amplifica el estrés con `trafficFactor`. Próximo sistema: accidentes viales con causa, bloqueo y respuesta municipal. Pruebas: Python 55 y Offline 40.


## Continuidad · Alfa 0.111

Fase 7 integra 30 s de espera por semáforo en rutas motorizadas para ambos motores; helper `signal_delay_minutes`/`signalDelayMinutes`. Próximo: capacidad por tramo y accidentes.


## Continuidad inmediata · Alfa 0.110

El usuario aportó siete imágenes en `design_reference_3d/` y un texto de requisitos. `ARTE_3D.md` resume la dirección e inventario. La implementación visual nueva está en `world3d.js`: `premiumArchitecture`, `roof`, `tree`, `addRoad`, `addSite`, costa y caché de geometrías. No modificar mecánicas ni inventar datos; viviendas, comercios, industrias y servicios deben depender del estado real. Comprobar las cuatro rotaciones, selección, calles conectadas y zoom. Evitar que el trabajo de detalle frene nuevas mecánicas: el siguiente sistema prioritario es tráfico autoritativo y accidentes. `reference.css` corrige solapamiento en Tesorería y evita que el aviso temporal cubra el menú. `game.js` difiere la vista previa 3D del menú 1,8 segundos y la cancela al empezar, para no bloquear el clic. Progreso global no estimable; fase 15 80% orientativo, hito F en curso.


## Continuidad inmediata · Alfa 0.109 (2026-11-01)

El usuario quiere que el juego se vea como las trece referencias en `design_reference/`. La interfaz actual usa `reference.css` y `reference-ui.js`; `game.js` decora los paneles existentes y conserva los nodos funcionales en `.ref-source`. Al modificar una pantalla, revisar que sus controles sigan accesibles, sin solapamiento en 390/1440 px y que cualquier nueva cifra venga del estado real `S`. Los trece PNG son referencias de diseño, no instrucciones de arquitectura ni datos de juego. El backend LAN y el motor Offline no fueron reemplazados. La siguiente mecánica prioritaria es tráfico autoritativo y accidentes; no dedicar varias versiones seguidas a detalles de una sola mecánica. Guardar ZIP y publicar cada cambio en `main` con email válido. Progreso global sin estimar por falta de matriz estable de pesos; fase 15 al 75%, hitos A–E parciales y F en curso.


Este documento es el punto de relevo de Ciudad Viva. Léelo junto con `ROADMAP_JUGABILIDAD_CIUDAD_VIVA_V2_REALISMO_PROFUNDO.md`, que sigue siendo la especificación principal, y con `ESTADO_DESARROLLO.md`, `AUDITORIA_ROADMAP.md`, `DECISIONES_TECNICAS.md` y `SIGUIENTE_ENTREGA.md`.

## Cómo continuar con el mismo criterio

- Priorizar mecánicas nuevas y circuitos jugables de extremo a extremo. El usuario pidió explícitamente no dedicar muchas versiones a pulir detalles mientras falten sistemas del roadmap.
- Las decisiones deben tener causas, recursos finitos, costos, tiempos, actores y efectos visibles en la ciudad. No sustituir una mecánica por una barra sin consecuencia.
- Toda regla central nueva debe funcionar en los dos modos: `server.py` (estado autoritativo online/LAN) y `offline.js` (motor local del navegador). Evitar duplicar cálculos de UI como si fueran reglas de simulación.
- La construcción existente proporciona el circuito común: parcela, contratista, capacidad de cuadrilla, fondos, materiales, etapas, avance, inspección y activación. Reutilizarlo cuando corresponda.
- Mantener una causa verificable y persistente en el estado, migraciones explícitas del esquema y una explicación accesible desde los paneles existentes.
- No declarar completa una fase porque tenga un prototipo. Mantener los porcentajes de fase conforme al criterio de cobertura documentado en `release_notes.json` y la auditoría. El avance global permanece sin estimar: no hay una matriz global de ponderaciones verificable.
- El usuario requiere subir cada entrega completa a `main` y comprobar el resultado. El commit debe llevar un email real válido de autor, nunca el valor `0`. No reemplazar una rama remota más nueva ni afirmar publicación sin comprobar el SHA.
- Empaquetar cada entrega completa en un ZIP que incluya esta guía y los documentos de estado.
- Probar los cambios con comprobaciones proporcionales al alcance. Para cambios de interfaz verificar escritorio y móvil, textos legibles, scroll utilizable y ausencia de solapamientos/overflow. Indicar si LAN física o Vercel no se comprobaron.

## Arquitectura actual

- `index.html`: interfaz principal y carga del cliente. Sigue siendo una página estática usable en Offline; Online/LAN requiere el anfitrión con `server.py`.
- `game.js`: cliente, herramientas, paneles emergentes, selección de parcelas/actores, peticiones y renderizado de UI. Usa modo offline mediante el adaptador, o modo online contra el estado del servidor.
- `world3d.js`: escena Three.js isométrica, edificios/terreno/actores visibles y proyección del puntero a entidades seleccionables. La escena de cada actualización se reconstruye desde el estado compartido.
- `server.py`: fuente autoritativa de simulación Online/LAN, acciones serializadas, guardados y migraciones. Las peticiones LAN no dependen de servicios externos.
- `offline.js`: simulación/persistencia local. Mantener paridad funcional con el servidor.
- `style.css`: estilos adaptables y paneles. Comprobar anchos cercanos a 390 px y escritorio para contenido nuevo.
- `release_notes.json`: historial de versiones y datos de la guía visual de fases. Actualizar la versión y los cambios de la interfaz con cada subida.
- Documentación: auditoría, estado, decisiones y próxima tarea deben concordar con código y pruebas.

## Estado histórico al cerrar Alfa 0.78

- Roadmap: hito F; fase activa 33, parcial (40%). La fase 21 está al 60% tras enlazar migración y perfiles de personas. Estos son porcentajes por fase, no del juego completo. El avance global permanece “sin estimar” por falta de pesos globales basados en criterios verificables.
- Estado de partida: el servidor inicia/salva en esquema 59; el adaptador Offline completa los campos y eleva el guardado local a 59. `offline_seed.json` conserva el valor legado 21, se normaliza al iniciar y no debe editarse solo para cambiar ese número. Versión de cliente: Alfa 0.76. La mecánica de migración no añade campos persistentes nuevos.
- Mercado exterior de fase 33 tiene volúmenes y presupuestos finitos. La oferta cambia de acuerdo con trabajadores, precio, condición, servicios y acceso.
- Si queda demanda regional sin atender, hay una parcela comercial libre conectada, existe capital privado y reserva, el permiso cabe en caja municipal y una constructora tiene cupo y siete trabajadores, se crea una sola propuesta privada de comercio. La oferta expira a 90 días. Rechazarla no gasta fondos ni reserva parcela y activa una espera de 90 días.
- Aprobar exige el ID vigente de la oferta y la misma parcela/contratista; se cobra solo el permiso y el proyecto usa la tubería ya existente de construcción por etapas, materiales, cuadrilla e inspección. La propuesta no abre un local instantáneamente.
- Al inspeccionar una vivienda, el panel muestra residentes, edad, empleo, empleador, ingresos y posesión de vehículo si está disponible. Actores seleccionables muestran su tipo, ruta/actividad y datos de pasajeros vinculados. La densidad y cantidad visible varían según los perfiles simulados; no todos los autos ambientales tienen perfil individual.
- Las categorías de Ciudad forman una tira horizontal desplazable en móvil y escritorio. La categoría activa se lleva a vista cuando cambia el panel.
- Alfa 0.76: cada nueva mudanza agrega una persona con edad de cohorte y etapa de vida; los elegibles tienen habilidades de trabajo y pueden encontrar vacantes por el sistema existente. Al emigrar, una persona específica se elimina, ocupación/padrón quedan sincronizados y su empleo puede liberarse. Se aplica tanto al migrar como al irse y no da ingresos/empleos gratuitos.

## Verificaciones registradas para esta entrega

Estado comprobado de Alfa 0.76:

- Sintaxis de Python/JavaScript y JSON del registro: correcta. Guardados cargados Offline se elevan a esquema 59 durante la inicialización; la semilla histórica `offline_seed.json` conserva versión 21 y se normaliza al crear la partida.
- Oferta y aceptación Online: verificada, incluyendo costo de ambas cajas, siete trabajadores y rechazo de duplicado.
- Oferta y aceptación Offline: verificada en guardado de prueba al primer cierre mensual; costos $432/$3.168, siete trabajadores y propuesta causada por demanda no atendida.
- Chromium a 390×844 y 1440×900 comprobó documento sin overflow horizontal, etiquetas de la tira legibles y categorías accesibles mediante desplazamiento. La tira restaura su posición al repintarse el resumen. Captura móvil revisada.
- Python: siete llegadas con padrón/ocupación sincronizados, edad y habilidades; cinco salidas retiran perfiles y reducen población por el mismo número. Offline Chromium: siete llegadas al cierre mensual y padrón/ocupación de 627.
- El ZIP y la publicación `main` de Alfa 0.76 se verifican antes de entregar.
- LAN entre dos computadoras físicas y publicación/ejecución en Vercel: no probadas en esos entornos.

## Siguiente tarea exacta

Continuar la fase 33 con simulación reproducible de varias décadas. Hacer pruebas de al menos 30 años en ambos motores y observar si demanda finita, inversión, obras, materiales, empleo, migración con registros personales, envejecimiento, caja y elecciones forman un ciclo estable. Encontrar y corregir bucles de generación/destrucción de capital; registrar ciudades que se vacían, se estancan o crecen sin soporte. Después ampliar la propuesta privada a los tipos de empresa que realmente permitan los mercados/cadenas ya simulados y ejecutar los escenarios pequeño, metropolitano, portuario y turístico que enumera el roadmap. Hacer una sola mecánica de contenido significativa por entrega y actualizar porcentajes solo con evidencia.


### Alfa 0.77 (actual)

- La fase 33 queda al 35%: delegación municipal opcional para propuestas comerciales con tope configurable. El anfitrión aplica la política en Online; Offline sigue la misma condición. Una contratación crea proyecto estándar, descuenta permiso de la caja, inversión del capital privado y abona anticipo de contratista; asigna siete trabajadores. Online incluye el abastecimiento por materiales; Offline aún permite avanzar sin inventario y eso debe corregirse en una entrega de mecánica, no de detalle.
- Prueba comprobada Online: permiso $432, capital $3.168, anticipo $634, siete trabajadores. Tope $0 deja oferta pendiente sin crear obra. Chromium comprobó Ciudad > Puerto en móvil 390×844 y escritorio 1440×844, sin overflow horizontal ni errores JS.
- Antes de dar el sistema por verificado en Offline, reproducir la misma propuesta bajo el motor local y probar topes $0/$500. Próximo contenido: escenarios largos de la fase 33, comenzando por 30 años en los perfiles básico y metropolitano; no invertir entregas sucesivas solo en UI.
- Versión en index y notas: Alfa 0.77. Esquema persistente sigue en 59; sin migración.


### Alfa 0.78 · anterior

- Proyecto estándar registra `contractedMandate` y `contractedDay`. Gobierno muestra cartera activa, pagos/saldos municipales y privados, etapa y cuadrilla, con etiqueta de obra heredada. La instantánea de la cartera se anota en cada elección; una victoria no reinicia pagos ni proyectos.
- Online, contrato escolar heredado por $10.000, pagado $4.000 y saldo $6.000; tras la elección renovada conservó el mismo proyecto. Offline, una elección en día 1.440 renovó del mandato 2 al 3, guardó el saldo $5.885 tras el pago diario y mantuvo proyecto/etapa activos. UI revisada en Chromium 390×844 y 1440×844; sin errores JS o desborde horizontal.
- Límite: cartera cubre proyectos estándar, no centraliza contratos especiales, deuda y mantenimiento. Fase 33 al 40%; ejecutar escenarios de 30 años sigue siendo la prioridad. Esquema 59.


### Alfa 0.79 · entrega anterior: zonificación por permisos y promotores autónomos

- Cliente con herramientas residencial verde, comercial azul e industrial amarilla. Arrastrar pinta un lote de parcelas y cada franja se aplica como acción atómica al estado Online. Las zonas requieren calle adyacente, no pisan parcelas ocupadas, y pueden cambiar de color. Las parcelas no edificadas comienzan sin permiso.
- `housingDemand.unmet` conserva candidatos a migrar hasta que cada uno entra a una vivienda; empleo y capacidad de casas limitan la llegada. Las casas que termina una constructora quedan vacías hasta que el proceso de migración las ocupa.
- `advance_zoned_development` crea proyectos privados en parcelas residenciales permitidas al llegar a 12 candidatos y compra déficit de materiales a proveedores con cargo al capital privado. Requiere permiso municipal, capital restante, cuadrilla y materiales. La oferta comercial no cubierta y una parcela azul generan una inversión comercial automática con materiales pagados.
- Las fábricas de bienes básicos (parcela amarilla) son negocios privados con 20 puestos. Capacidad depende de mano de obra asignada y acceso a energía, agua y cloacas. El producto se agrega a proveedores con origen vial, inventario, precio y plazo; las tiendas lo compran por su flujo de procurement ya existente, reduciendo importación de producto terminado. Cadena de materias primas y transformación detallada sigue pendiente.
- Funciona en `server.py` y `offline.js`. Limitación conocida: las construcciones Offline no consumen materiales de obra (la ruta vieja tiene materiales en cero), aunque las obras automáticas sí aplican capital, permisos, tiempo, constructor y etapas.
- Estado actualizado al guardado esquema 60 con campos retrocompatibles `housingDemand` y `localIndustry`. Fases: 1=70%, 4=55%, 5=65%, 16=20%, 17=55%, 18=50%, 20=50%, redondeo por saltos documentados de 5 puntos. Global sigue sin estimación por falta de pesos del roadmap.
- Pruebas de esta entrega: acción HTTP de pintura en lote/recoloreo atómica; sin zona no hay casa automática; promoción residencial Online compra materiales; hogar baja demanda solo tras mudanza; fábrica Online: 16 producidas y 15 suministradas a comercios; Offline: vivienda autónoma con demanda pendiente y fábrica produce/vende 25 unidades con servicios y personal completos; Chromium 390×844 y 1440×900 sin overflow horizontal ni errores JS. Físico LAN/Vercel no probados.

**Siguiente punto exacto:** validar construcción Online hasta inspección y llegada posterior de residente; auditar el agotamiento/margen de fábrica con múltiples cierres mensuales; completar consumo de materiales de obra en Offline y probar comercio/fábrica bajo escasez y competencia; luego retomar los escenarios de 30 años de fase 33.


### Alfa 0.81 · crecimiento privado autónomo (actual)

- Se conserva el sistema de permisos verde residencial, azul comercial y amarillo industrial. El arrastre aplica el permiso a una franja de parcelas; parcelas vacías nuevas siguen sin zonificar y cambiar el color revoca el uso anterior.
- La demanda residencial queda acumulada mientras haya candidatos sin vivienda. Cada casa privada se construye en una parcela residencial conectada por calle, consume capital/permiso/materiales, usa contratista y cuadrilla, y solo descuenta demanda al llegar un hogar real.
- Fábricas privadas visibles requieren permiso industrial, cuadrilla, capital, materiales, empleo y servicios. Producen insumos con trabajadores y servicios disponibles; los comercios priorizan el proveedor local por precio y ruta, lo que reduce la compra externa. La cadena de materias primas y el agotamiento de insumos aún no están simulados.
- Disponible en Online y Offline; guardado esquema 60. La limitación Offline de consumo de materiales en obras generales sigue abierta.
- **Siguiente punto exacto:** probar la secuencia Online hasta inspección y llegada de residente y los ciclos mensuales de fábrica con competencia/escasez; cerrar consumo de materiales en obras Offline; después retomar pruebas de 30 años de fase 33.

### Alfa 0.81 · promotores autónomos y equipo abierto (actual)

- El usuario pidió que no tenga que construir viviendas, mercados o fábricas manualmente. Las parcelas pintadas habilitan a promotores privados; sus obras comienzan automáticamente cuando hay demanda, empleo o escasez comercial y se encuentran permisos, capital privado, contratista, cuadrilla, acceso y recursos. La pintura no produce edificios instantáneos. Los servicios públicos e infraestructura siguen en manos de jugadores.
- Se agregó activación de nuevas tiendas por demanda doméstica local además de ventas regionales; la industria puede iniciar automáticamente cuando comercios activos ya venden o compran insumos. Offline mantiene su limitación conocida de no consumir materiales en obras.
- La instrucción explícita del usuario es que todos los jugadores invitados puedan hacer todo. Las carteras municipales son rótulos voluntarios, se pueden reasignar y no autorizan ni bloquean acciones.
- Revisar y ejecutar escenarios para verificar inicio residencial/comercial/industrial en ambos motores, condiciones de capital/cuadrillas y demanda. La UI de parcela requiere comprobación responsive.
- El progreso global no puede estimarse con rigor: el roadmap no asigna pesos entre sus 34 fases. Avances por fase estables: 1=70, 4=60, 5=70, 16=20, 17=60, 18=55, 20=55, redondeados a múltiplos de 5.


### Alfa 0.82 · cadena regional de alimentos (actual)

La procesadora compra grano finito a una cooperativa regional, paga con caja empresarial, espera preparación y ruta vial, produce solo con insumo real y vende stock de alimentos a comercios por el mercado existente. La ficha informa pedidos, inventario, faltantes y ventas; los camiones 3D pueden seleccionarse. Verificado Online y Offline con llegadas y producción.

**Próximo punto:** implementar las cadenas áridos→hormigón→obra y madera→aserradero→materiales, y hacer que el abastecimiento de fábricas compita por cuotas bajo escasez. Después avanzar fase 19 (licitaciones y dirección de obras); continuar gobierno electoral del hito E más adelante. Conservar las acciones abiertas a invitados y documentar las diferencias Offline conocidas. El global continúa no estimable sin pesos de fase.


### Alfa 0.83 · cumplimiento contractual con efecto real (actual)

Fase 19: el riesgo de demora ya afecta calendario y avance en Online/Offline. `assess_contract_delay()` en `server.py` y `assessOfflineContractDelay()` en `offline.js` revisan ciclos de 30 días. La probabilidad depende de confiabilidad y saturación de capacidad; el resultado es reproducible por coordenadas/ciclo/empresa. La obra guarda `lastRiskReviewCycle`, `delayDays` y `lastDelayReason`; la tarjeta de obra los muestra. Mantener ambas fórmulas iguales al modificarlas y probar un caso de demora y otro sin demora. No hay multas, orden de cambio ni reclamos todavía. Siguiente: agregar pagos por hitos físicos y retenciones o la garantía técnica; evitar ampliar detalle visual aislado.


### Alfa 0.84 · pago por certificado de etapa (actual)

Fase 19 suma pagos por hitos físicos en `server.py` y `offline.js`: anticipo del 20%, 80% dividido por etapas; sin avance de caja entre hitos. `certificationHistory` guarda los hitos y `paid` el acumulado. El control de tesorería ocurre antes de consumir insumos/avanzar. Tarjeta Obras muestra hitos y pagos. Evitar duplicar certificados en guardados heredados: el hito inicial deriva del progreso anterior si falta el campo. La prueba cubrió caja insuficiente y el ciclo completo. Próximo avance de fase 19: retención final con período de garantía y reparación/reclamo atribuible a calidad; preservar presupuesto reservado y responsabilidades del contratista al diseñarlo.


### Alfa 0.85 · garantías de obra (actual)

Online/Offline: los contratos públicos nuevos retienen 10% en escrow y siguen pagando 20% de anticipo más 70% por hitos. Exigir el saldo del certificado y el fondo de garantía de forma atómica antes del último avance. Guardados previos (sin `retentionPct`) y proyectos privados mantienen 0% de retención. `contractGuarantees` persiste recepción provisional, revisión día +30, contratista, riesgo congelado, defecto, reclamo y reparación. Una falla reduce 12 puntos de calidad. Acción `repairContractGuarantee` compromete tres trabajadores durante cinco días; al cumplirse restaura calidad y paga escrow una sola vez. `release_notes.json` reporta fase 19 = 45%; global continúa nulo/no estimable.

Verificado: Python expuso certificado final de 90%, reclamo, reparación y pago idempotente. Chromium Offline completó obra nueva con retención $100 y suspendió obra con caja insuficiente sin avanzar. La acción de reclamo creó plazo de cinco días. Obras se revisó en viewports móvil/escritorio sin overflow horizontal y con tarjeta legible. Probado también: una garantía defectuosa quedó en reclamo con calidad −12; tras cinco días asignados restauró calidad y liberó $100 una sola vez. Siguen pendientes disputa/orden de cambio, LAN física y Vercel.


### Alfa 0.86 · órdenes de cambio (actual)

La incidencia se revisa una vez por obra pública al alcanzar 20%; está persistida por `changeOrderReviewed`. El status `cambio_pendiente` pausa la cuadrilla. Resolver con `approveContractChange` o `rejectContractChange`: aprobar verifica caja después de compromisos, añade costo y plazo conservando progreso, rechazar aplica `qualityPenalty`; las decisiones se guardan en `contractChangeHistory`. Mantener el roll Python/JS idéntico. Pruebas incluidas: HTTP de aprobación/rechazo/fondos insuficientes/duplicado; Chromium Offline de aprobación persistente. Fase 19 = 50%. Próximo sistema amplio: completar cadena áridos-hormigón en fase 18.

### Alfa 0.87 · cantera de áridos (actual)

Cambios Online en `server.py`/`game.js`: primer factory conserva procesado de alimentos; el siguiente factory terminado toma `industryType: quarry`. `advance_local_quarries` produce en ciclo mensual a partir del personal efectivamente asignado y el menor factor electricidad/agua/saneamiento, con reserva finita y stock de proveedor 360. `orderMaterials` para `Cantera local` sale desde la coordenada física de planta, usa ruta, tráfico, descarga, caja del contratista; la empresa recibe venta y reduce `aggregateStock`. Los proveedores regionales siguen como sustitutos. `localIndustry.materialProduced/materialSold` guarda el balance agregado. Ver pruebas HTTP/API y Chromium documentadas en `ESTADO_DESARROLLO.md`. La oferta de materiales no funciona aún Offline porque ese adaptador no tiene órdenes; no copiar el botón Online sin implementar su ciclo completo. Próximo sistema: hormigonera local que convierta áridos y venda hormigón que consuma la obra. Fase 18=65%; global null.

**Notas para retomar Alfa 0.87:** el capital operativo de la cantera se reserva desde capital privado en ambos contratos industriales: $4.200, no se debe inicializar un saldo libre mayor al fondo comprometido. La capacidad útil es `min(48, round(personal*1,5*servicios))`; separá capacidad potencial de salida efectiva para que faltas de red/personal aparezcan como faltantes y causa, no como producción cero sin explicación. La compra local cuesta $28,88 por unidad antes de flete (por diez unidades, $289), el ingreso va a la firma y las rutas guardan `source=[x,y]`; el tick de reparto respeta ese origen. Testear fondos insuficientes sin debitar, stock agotado, calle cortada, patio lleno, descargador ocupado e insolvencia antes de dar fase 18 por cerrada. No llamar completa la cadena: todavía no hay hormigonera ni consumo de hormigón en obra. Cambios recientes pendientes de publicar en esta sesión: rama `main`, Alfa 0.87. El ZIP debe incluir esta guía.


### Alfa 0.88 · hormigonera (histórico)

Online en `server.py` y Economía en `game.js`. Orden de especialidad para nuevas fábricas privadas: alimentos → cantera → hormigonera → alimentos. La planta vive en `business.industryType="concrete"`; `advance_local_concrete_plants(workplaces, employees)` opera en el ciclo mensual, gasta nómina/costo mensual, escala con trabajadores y mínimo de electricidad/agua/saneamiento, usa patio local de 240 hormigones y mantiene `concreteStock` sincronizado con el proveedor. Compra áridos desde `Cantera local`, limita por stock, reserva/caja, paga al productor, guarda `source`, ruta y fecha de recepción; `process_market_orders()` deposita el insumo cuando llega. Regla 2:1; `settle_concrete_sale()` reduce el inventario de firmas y les paga. Las recetas en `MATERIAL_NEEDS` tienen nueva clave `concrete`; cambiar recetas conserva demanda total aproximada de agregado+concreto. `ensure_supply_state()` migra stocks viejos con cero. Compras de obra usan el endpoint existente `orderMaterials`; agrega proveedores locales y origen real de planta.

Verificado local: 30 áridos producidos/trasladados, entrega por carretera de 4 tramos, 15 hormigones producidos, pago correcto por 3 unidades, casa demanda 7 y migración. Popup de Economía probado en 390×844 / 1440×900. La acción HTTP `orderMaterials` ya vende desde Hormigonera local y rechaza un pedido mayor al stock sin débito; `missing_materials` detecta el bloqueo de concreto por etapa. Queda probar una obra/tick end-to-end que se detenga, reciba el camión y reanude; implementar Offline completo (actualmente el adaptador no ofrece stock/pedido de obra); probar descuentos/ruta/insolvencia de planta; seguir con madera/acero, no quedarse puliendo detalles. No declarar probado en Vercel ni LAN físico. Fase 18=70%; global null. Referencias: `ESTADO_DESARROLLO.md`, `DECISIONES_TECNICAS.md`, `SIGUIENTE_ENTREGA.md`, `AUDITORIA_ROADMAP.md`.


### Alfa 0.89 · compras y materiales de obra Offline (histórico)

`offline.js` ya da paridad básica para materiales de construcción: migración de todas las existencias heredadas, inventarios por proveedor/contratista/depósito, costos unitarios y producción/reposición mensual finita, compra accionada desde Obras, caja de contratista, capacidad por destino, ruta vial, ETA, recepción y consumo por etapa. La obra se suspende si falta el siguiente lote y el bucle vuelve a intentar al recibir existencias. Las viviendas y comercios autónomos financian materiales antes de cargar permiso/proyecto, en vez de aparecer gratis. `game.js` expone Pedir materiales también Offline; `style.css` mantiene la confirmación sticky en modal largo móvil/escritorio. Verificado con Chromium: orden de 6 hormigones, pago $372, entrega y uso en una calle de prueba; modal 390×844 y 1440×900, sin errores JS, botón visible. Node syntax/diff checks pasan.

**No declarar verificado:** el escenario específico suspensión por escasez → entrega → reanudación en ambos motores aún no se ha cubierto deliberadamente; no se probó conexión LAN física ni Vercel. Siguiente: agregar el test de tick/continuación en Online y Offline; después producir madera en aserradero y acero en una cadena industrial, con insumo finito, puestos/servicios, logística real, ventas a constructoras y receta visible. Evitar reducir caja privada por debajo de cero al sumar materiales; `offlinePrivateMaterialCost()` participa en las comprobaciones de capital de promoción. Actualizar roadmap JSON y guía al cierre. Fase 18=75%, global sigue no estimable: las 34 fases no tienen un peso comparable auditado.


### Alfa 0.90 · aserradero y madera local (actual)

La fase 18 ahora incluye un `sawmill` tras la cantera/hormigonera en Online. `advance_local_sawmills()` integra nómina, costos, límite de servicios, reserva forestal/regeneración, capacidad y stock; madera sale como `Aserradero local`, ordenable en obras desde el origen real, con pago e inventario sincronizados. La segunda fábrica Offline se especializa en aserradero; la producción mensual usa puestos, servicios, reserva y capacidad, y la venta local acredita caja del negocio. `game.js` muestra stock, reserva, producción y estado en Economía. Cambiar de proveedor actualiza la sugerencia de materiales a lo que tiene ese proveedor, evitando intentar pedir áridos/hormigón cuando se eligió madera local.

Verificado: test de motor Online produjo 25 tablas usando 50 troncos y pagó $690 por venta de 10; Chromium Offline pidió 4 tablas desde el aserradero, pagó $276, redujo inventarios y acreditó al negocio; panel Economía en 390×844/1440×900 sin overflow ni errores. `python -m py_compile server.py`, `node --check` y JSON validan. No declarar completa la fábrica por menú; falta flujo UI de obra industrial y prueba de producción offline con trabajadores asignados. Siguiente: testear obra suspendida al faltar madera y retoma tras entrega, y luego añadir cadena de acero/importaciones realistas. Hacer contenido nuevo, evitar pulido aislado. Fase18=80%; progreso global sigue no estimable sin peso común auditable para 34 fases.

## Alfa 0.91 · continuación de la cadena industrial

La metalúrgica implementa acero regional → componentes de construcción: `industryType=metalworks`, proveedor `Metalúrgica local`, orden industrial de acero desde Corralón con ruta/ETA, inventario de materia prima y producción condicionada por personal, servicios, caja y espacio. `settle_metalworks_sale` reduce stock privado y acredita la firma en Online; Offline usa `advanceOfflineMetalworks`, entrega vial y venta al pedir materiales. El orden industrial objetivo queda alimentos → cantera → hormigonera → aserradero → metalúrgica. El próximo trabajo debe verificar una obra suspendida por escasez de componentes, pedir a la metalúrgica, recibir, reanudar y no duplicar inventario/pago en ambos motores. Revisar tarjeta Economía en Chromium (390×844, 1440×900), actualizar progreso y registrar prueba real. No gastar otra entrega en detalles de cantera ni atribuir pruebas LAN/Vercel que no se hayan hecho.


## Alfa 0.92 · paridad industrial y regresiones (actual)

El mercado mensual Offline ya excluye cantera, hormigonera, aserradero y metalúrgica de la producción de alimentos, como Online. La misma planta no debe registrar una segunda nómina ni producir stock alimentario ficticio. Se agregaron pruebas automatizadas que fuerzan una obra a suspenderse por componentes, encargar a una metalúrgica local, esperar camión/descarga, recibir y consumir el material una sola vez, inspeccionar la obra y no duplicar el pago. Un test adicional verifica que la metalúrgica no aparece como procesadora alimentaria. En el workflow de GitHub Actions se completaron con éxito sintaxis/JSON y los tests Online/Offline (run 41260659327).

Fase 18 permanece al 85%; avance global sin estimación. No se hizo prueba LAN física, Vercel ni visual con Chromium en esta entrega. Estas pruebas usan una fábrica y una obra controladas, no acreditan todo el ciclo de permiso, obra industrial y habilitación.

**Próxima tarea:** comprobar la cadena completa de metalúrgica nacida de un permiso y contratista, luego inspección, puestos, servicios, acero regional, producción real, pedido y consumo por una obra. Revisar y corregir diferencias de secuencia de especialidades industriales Online/Offline. Luego escasez entre meses y escenarios de 30 años.


## Alfa 0.93 · cantera → hormigón también Offline (actual)

Se implementaron las dos especialidades industriales que faltaban en Offline: cantera con reserva geológica finita, trabajadores, servicios, costos y stock; hormigonera con compra de áridos reales a cantera por ruta, costo contra caja privada, pedido industrial, entrega diferida y receta de conversión 2:1. El hormigón producido se ofrece como proveedor local a la construcción y el cobro acredita a la planta; compras desde Obras usan la posición real del proveedor. La simulación mensual ahora procesa cantera → hormigonera → aserradero → metalúrgica, y el mercado de alimentos excluye estas cuatro ramas.

La especialidad `industryType` se fija **al contratar** una fábrica, también cuando la construye automáticamente un promotor. Online y Offline consideran fábricas activas y proyectos ya adjudicados para escoger alimento, cantera, hormigonera, aserradero o metalúrgica, evitando que dos contratos simultáneos cambien de destino al abrir. La fábrica nueva reserva $4.200 de caja privada. En Online ya se aplicaba este descuento al contratar; Offline manual ahora lo paga y la caja al habilitar procede de la reserva. Los proyectos legados sin `industryType` conservan fallback.

Pruebas nuevas: Python verifica reserva de especialidades, extracción, compra vial, entrega y producción 2:1; Node verifica contratación de tres plantas con capital privado, producción con residentes empleados, abastecimiento y conversión real en la segunda mensualidad. Regresiones anteriores de obra con componentes siguen activas. La suite de Chromium en GitHub Actions verifica 390×844 y 1440×900, sin sustituir prueba LAN física/Vercel. Fase 18=90%; global no estimado.

**Siguiente tarea:** ampliar fase 17 con competencia y reasignación de trabajadores bajo insolvencia industrial, órdenes y proveedores ante precios rivales, recuperación/reutilización de plantas cerradas; después ensayar escasez/contratos con décadas en los cuatro perfiles de fase 33. Evitar gastar versiones en retoques de tarjetas. Verificar la ejecución más reciente del workflow y su ZIP.


## Alfa 0.94 · recuperación autónoma de plantas privadas (actual)

Nueva mecánica de fase 17 en Online/Offline: al cerrar por insolvencia una fábrica especializada se marca fecha de quiebra y su inventario vendible sale del proveedor; deja de ofrecer los 20 puestos. Un empresario puede recuperar ese edificio a partir de 90 días cerrado si mantiene zonificación industrial, hay demanda de proyectos/comercios, calle accesible, electricidad/agua/saneamiento >=65%, capital privado y cupo de constructor con cinco trabajadores. Se reserva una inversión privada real de $5.300: $4.200 se mantienen como caja inicial del nuevo operador, $900 van a la empresa de obra, $200 se cobran como permiso. Durante siete días la planta sigue cerrada y ocupa la cuadrilla; si la inspección final falla por acceso o servicios, no reabre hasta resolver la causa. Al aprobarse se crea nueva firma con identidad y caja distintas, 20 puestos por cubrir, sin inventar producto ni restaurar reservas geológicas agotadas. Se conserva historial y causa legibles desde Economía/ficha de planta. Las nuevas órdenes no recuperan insumos del titular anterior.

Pruebas automáticas: `tests/test_industrial_recovery_online.py` (demanda, capital, cupo, tiempo, bloqueo e idempotencia), `tests/test_industrial_recovery_offline.mjs` (espera, capital, puesto nuevo, identidad y ausencia de inversión sin demanda). La validación móvil 390×844 y escritorio 1440×900 cubre Economía y el popup. Fase 17=65%, fase 18=90%; global sigue no estimado.

**Siguiente punto:** competencia entre múltiples proveedores industriales, contratos reales de exportación/compra en almacenes y ajuste de empleo a demanda; después simulaciones de 30 años en los perfiles pequeño, metropolitano, portuario y turístico del hito F. No hacer entregas para detalles aislados. LAN física/Vercel no probados; actualizar estado después de ver resultados CI reales.


## Alfa 0.95 · competencia material real (actual)

Se entregó un mercado competitivo de insumos industriales en Online/Offline. Una categoría local (Cantera local, Hormigonera local, Aserradero local, Metalúrgica local) puede incluir varias instalaciones abiertas y conectadas: la obra elige la fábrica individual con un lote completo y menor costo de mercadería + flete vial. Las órdenes registran `vendorId`, `vendorName`, `source`, `route`, `productCost`, `freight` y `quotedFactor`. El vendedor pierde físicamente su inventario y gana exactamente el valor de producto; el costo logístico entra en `supply.logisticsCash` sin crear doble pago. No se permite combinar dos inventarios parciales en un solo camión. La hormigonera compra sus áridos a la cantera mejor cotizada con ruta y caja disponibles; ya no mezcla ruta de una planta con mercadería de otra. `materialPriceFactor` se adapta cada mes a ventas realmente acumuladas (`industrialSalesSincePricing`) y stock inmóvil, acotado entre 0.8 y 1.35 de la base.

Economía muestra por planta el stock, la tarifa industrial y las ventas; el pedido advierte que la oferta agrupada no equivale a un lote único y limita la cantidad sugerida a la existencia máxima en una planta. Se agregaron tests `test_industrial_competition_online.py` y `test_industrial_competition_offline.mjs`, e inyección de dos rivales para validar la UI en 390×844 y 1440×900 con Chromium. Las compras automáticas de materiales de promotores privadas anteriores siguen usando una selección y entrega simplificadas: convertir esas compras en órdenes con rutas y competencia es un próximo objetivo, no declararlo completado.

**Siguiente mecánica prioritaria:** contratos comerciales a plazo entre privados y compras de promotores con transporte real, y sistema de expansión/reducción de plantillas por rentabilidad. Después probar la fase 33 en partidas de 30 años. Mantener 17=70%, 18=90% y global no estimado. LAN física y Vercel no probados en esta entrega.


## Alfa 0.96 · logística de promotores + empleo adaptable (actual)

La fase 17 incorporó dos sistemas jugables en ambos motores:

**Construcción privada sin materiales ficticios.** `advance_zoned_development` Online cotiza `plan_private_construction_deliveries` y contrata `commit_private_construction_deliveries`; en Offline `fundOfflinePrivateMaterials` genera órdenes de transporte, no inyecta stock al contratista. Las compras cuentan contra `privateCapital` y se materializan en `supply.orders` con ruta, día de preparación, comprador, vendedor individual de industria cuando existe, destino, flete y costo del producto. Se valida capacidad libre real, incluso reservas de pedidos en tránsito; el almacén destino debe estar conectado también a la obra. El inventario vendedor baja al adjudicar, pero el de la constructora no crece hasta la descarga. Una compra a fábrica local acredita su propia caja y separa el flete en logística. Si no hay lote entero, ruta, espacio o capital, el proyecto autónomo no inicia. También quedan cubiertas las obras comerciales delegadas Offline. Guardados existentes siguen disponibles, pues las nuevas propiedades son opcionales.

**Empleo privado adaptable.** Después de liquidar actividad y salarios, `rebalance_private_staffing` / `rebalanceOfflinePrivateStaffing` evalúan pedidos/ventas, inventario, caja, beneficio y plazas realmente ocupadas. Abren una vacante con equipamiento comprado a proveedor regional ($150 comercio, $240 industria) o, tras dos cierres malos de demanda, reducen hasta dos. Los residentes efectivamente excedentes se desasignan por su identidad y buscan trabajo; el total de vacantes se ajusta sin emitir puestos mágicos. La metalúrgica mejora su capacidad instalada si tiene vacantes nuevas ocupadas. Hay tests Online para expansión, despidos y ventas industriales no reutilizadas; en Offline se prueba baja real de vacantes industriales. La modelización de convenios, alquileres empresariales y expansiones de instalaciones físicas sigue pendiente.

**Pruebas:** `tests/test_private_construction_supply_online.py`, `tests/test_private_construction_supply_offline.mjs`, `tests/test_private_staffing_online.py` y `tests/test_private_staffing_offline.mjs`; se mantienen las regresiones anteriores y Chromium móvil/escritorio. Fase 17=75%, 18=90%, global no estimable. Próxima tarea: contratos a plazo y reservas entre privados, competencia minorista/rentas, luego partidas de treinta años. No dedicar versiones a cosmética. LAN física y Vercel pendientes.


## Alfa 0.97 · contratos privados cantera → hormigonera (actual)

La fase 17 incorpora negociación y ejecución de acuerdos privados a plazo para áridos, Online y Offline: `sign_aggregate_forward_contract` / `signOfflineAggregateForwardContract` seleccionan una cantera individual con producción real, almacén, vía conectada, precio y comprador solvente. La firma reserva stock del vendedor y del proveedor agregado sin aumentar stock comprador; el capital se retira de su `business.cash` a `supply.tradeContracts[*].escrow`, sin ingreso inmediato de venta. En cantidades de nueve o más áridos hay tres remesas semanales, cada una en `supply.marketOrders` con preparación, ruta, plazo contractual, cantidad, precio y flete. El procesamiento diario autoriza entrega real tras el trayecto y liquida solo esa remesa: dinero al vendedor, flete a logística, material a inventario físico de hormigonera. Si el comprador cierra o se supera plazo, se cancela la remesa pendiente, se devuelve su pago y se recupera mercancía en cantera todavía abierta; con firma desaparecida se registra pérdida explícita, sin fabricar existencias. Cada línea se liquida una sola vez con `contractSettled`; el contrato termina `cumplido` o `incumplido` y conserva su cierre.

Se agregó visibilidad en Economía para los contratos activos/incumplidos y remesas recibidas, importe pagado, devuelto y saldo en custodia; visual verificado en resoluciones 390×844 y 1440×900 por Chromium en CI. Nuevos tests `tests/test_forward_contracts_online.py` y `tests/test_forward_contracts_offline.mjs` cubren reserva y cobro al llegar, corte vial y devoluciones, insolvencia de comprador y falta de capital. Tests previos de cantera→hormigonera fueron adaptados a tres remesas y objetivos de compra condicionados a plantilla.

**Siguiente mecánica:** ampliar acuerdos de suministro con reserva y custodia a otras industrias y clientes, penalizaciones económicas y negociación de vencimientos; después stress real de 30 años bajo cuatro perfiles (fase 33). Fase 17=80%, 18=90%, total global no estimable. LAN física y Vercel pendientes; no declarar equivalencia entre pruebas automáticas y validación de red real.

## Alfa 0.98 · prórroga privada ante interrupción vial (actual)

Los contratos cantera→hormigonera permiten la acción `renegotiateTradeContract` desde Economía si existen remesas vigentes detenidas por ausencia real de ruta. Ambas empresas deben operar y la compradora abona al proveedor una compensación del 5% del valor original (mínimo $20). El pago va de caja privada a caja privada, fuera del escrow. Solo los plazos de remesas pendientes crecen 14 días; no cambia material reservado, pagos ya liquidados ni inventarios. Se registran `renegotiatedDay`, `extensionDays` y `extensionFeePaid`; una segunda prórroga se rechaza.

Hay regresiones Online/Offline de caja, inventario, extensión y entrega tras el vencimiento original; la revisión Chromium está incluida en CI. Fases 17=80% y 18=90%; global sin estimar. **Siguiente sistema:** contratos con reserva y custodia en otras cadenas B2B y compradores, competencia comercial y partidas de 30 años bajo cuatro perfiles. LAN física y Vercel no verificados.


## Continuación · incumplimiento económico B2B

Los contratos de áridos entre cantera y hormigonera ahora penalizan una remesa vencida mientras ambas firmas siguen abiertas: el proveedor transfiere al comprador hasta un 5% del producto no entregado, limitado por su caja. La devolución del depósito permanece separada de esta indemnización; `defaultPenaltyPaid` se registra por remesa y contrato y la liquidación idempotente evita cobros repetidos. Misma regla en Online y Offline. Pruebas específicas de vencimiento incorporadas; comprobar CI. Próximo: ampliar contratos a otras cadenas y escenarios de 30 años. Porcentajes sin cambios; LAN/Vercel pendientes.


## Continuación · quiebra del proveedor en contrato B2B

Si una cantera proveedora cierra mientras mantiene remesas reservadas para una hormigonera, el procesador diario Online/Offline cancela todas las pendientes de inmediato, sin esperar al vencimiento. Restituye desde escrow el importe pagado por cada remesa al comprador y anota `lostReservedUnits` si el inventario del proveedor insolvente no se puede recuperar. Una línea `contractSettled` no se liquida dos veces. La causa `Proveedor insolvente` permanece en las órdenes y el contrato termina incumplido. La multa por plazo vencido no se cobra a una firma ya cerrada. Pruebas para ambos motores añadidas; validar CI. No hubo modificaciones visuales. Fases y estimación global sin cambios. Siguiente contenido: acuerdos de otras cadenas B2B y simulaciones de décadas.


## Continuación · competencia minorista adaptativa

Nueva mecánica de fase 17 en ambos motores: tras las ventas mensuales los comercios ajustan su precio hasta un peso por mes en respuesta al volumen vendido, inventario, demanda y beneficio reales. Con ventas suficientes y existencias bajas pero no agotadas pueden subir; con stock inmóvil o margen negativo bajan. Banda inicial $8–$36. Los compradores ya ponderan precio y distancia en el siguiente período, por lo que la decisión modifica competencia y caja futura, pero no crea dinero inmediatamente. Cada empresa registra `lastPriceChangeDay` y `lastPriceCause`; hay eventos verificables. Pruebas unitarias Online agregadas; validar integración Offline y resultados CI antes de dar por probada esa ruta. Interfaz no modificada; porcentajes sin cambios. Próximo: contratos entre otras cadenas y campañas de 30 años.


## Continuación · alquiler comercial operativo

Comercios abiertos asumen una renta mensual según localización y `monthlyRent` opcional; el costo reduce caja/beneficio y puede llevar a cierre por insolvencia. Los pagos efectivamente cubiertos quedan en `supply.propertyRentalCash` como recaudación de propietarios, no ingreso del municipio ni capital generado. Se implementó en Online y Offline sin modificar UI; Online eliminó además el ajuste minorista anterior duplicado para mantener una sola decisión de precios por cierre. Pendiente validar resultados de CI y ajustar pruebas de rentas en escenarios largos. Fases sin cambiar; próximo sistema: contratos B2B ampliados y escenarios de 30 años.


## Continuación · mercado regional de acero y pruebas

El Corralón del Puerto aplica cotización por existencias al abastecer metalúrgicas: multiplicador 1,5 bajo 20 unidades, 1,25 bajo 60 y 1 desde 60. Online/Offline calculan costo antes de reservar lote y deducen efectivo y acero físico; la producción posterior aún requiere llegada por carretera, trabajadores y servicios. Se registra `lastSteelPriceFactor` en el proveedor; tests nuevos Online miden precio, caja y stock. No se alteró la interfaz. Se revisaron dos fallos de CI previos: vencimientos escalonados del test Offline y remesa ficticia desconectada del test responsive. Revalidar ejecución CI; porcentajes sin cambios. Próximo: completar contratos entre otras materias primas y pruebas de décadas.


## Continuación · accesibilidad comercial real en Offline

La asignación de demanda minorista de hogares utiliza ahora `offlineRoadRoute`, con conectividad y calidad vial, en lugar de una distancia Manhattan que admitía compras a través de barrios incomunicados. Solo comercios alcanzables compiten por precio y distancia efectiva de ruta; un corte puede suprimir ventas, ingresos y, en cierres posteriores, provocar reducción de empleos o insolvencia. Online ya exigía `route_between` y conserva la misma condición. Nueva regresión Node compara demanda con calles conectadas frente a una red completamente retirada, incluida en CI. No hubo cambio de interfaz. Siguiente tarea: escenarios largos de fase 33 y contratos B2B restantes; no aumentar porcentajes sin resultados CI.


## Continuación · negociación automática de alquileres comerciales

Los comercios privados abiertos renegocian la renta mensual en los dos motores antes de liquidar ventas: con demanda efectivamente atendida y beneficios suficientes sube $5 hasta $180; con hasta dos ventas y pérdidas cae $5 hasta $30. No mueve dinero al renegociar; la renta efectiva sigue pagándose mediante el costo operativo existente y las entradas en `supply.propertyRentalCash`. Persisten `monthlyRent`, `lastLeaseReviewDay` y `lastLeaseCause`, sin migración obligatoria. La ubicación conserva el precio inicial. Se agregó prueba Online y se mantiene pendiente comprobar CI para integración Offline. Sin modificación de interfaz ni porcentajes. Próximo: contratos industriales adicionales y escenarios de 30 años.


## Continuación · reserva regional finita de acero

La reposición mensual de acero de los tres proveedores regionales consume ahora `supply.regionalSteelReserve` (reserva inicial de 30.000 unidades en partidas que aún no tienen ese campo), tanto en Online como Offline. Cuando se agota el mineral, la región deja de reponer acero sin materia prima; el stock ya producido sigue existiendo y puede circular por las órdenes tradicionales. La distribución por proveedor respeta el orden previo y el límite de reservas. La cadena metalúrgica queda afectada por escasez estructural durante partidas de décadas, además de la variación de precio que ya dependía del stock. Se agregó regresión Python para reserva cero; integración CI pendiente. Interfaz sin cambios, porcentajes por fase sin modificar. Prioridad siguiente: recuperación de reservas mediante reciclado/importaciones bajo costo físico y simulaciones 30 años para comprobar balance.


## Continuación · recuperación de acero desde chatarra municipal

El sistema de residuos acumula `waste.scrapSteelTons` a razón de 0,2 toneladas de chatarra separable por tonelada reciclada efectivamente. Cada cierre mensual, ambos motores pueden transformar hasta dos unidades de acero por tonelada de chatarra a costo municipal de $12 por unidad, solo con caja disponible y espacio en el stock del Corralón del Puerto. Se descuentan la masa recuperada y el dinero, se agrega acero físico al proveedor y se registra `supply.steelRecyclingSpend`. Esta fuente de acero complementa la reserva regional finita y puede sostener industria durante partidas largas sin recursos mágicos; sin plantas de reciclaje y recolección no hay insumo nuevo. Prueba económica Online incorporada; CI pendiente. Interfaz sin modificaciones. Prioridad posterior: comprobación 30 años y contratos industriales adicionales.


## Continuación · abastecimiento marítimo de acero

El stock del Corralón del Puerto por debajo de 30 unidades permite una compra marítima extraordinaria de hasta 60 unidades por mes **solo si existe un puerto operativo con ruta hasta el depósito**. Cada unidad importada cuesta $280 municipales (divisas y flete); se descuentan fondos efectivos y se registran `supply.steelImportSpend` y `supply.steelImportedUnits`. El acero físico aparece en el proveedor regional, donde las metalúrgicas deben comprarlo y recibirlo mediante su logística ordinaria. No se utiliza la reserva mineral regional ni se duplica chatarra. Implementado Online/Offline; nueva regresión Python de importación. Validar CI. Interfaz intacta. Siguiente: escenarios largos de fase 33 y control de balances.


## Continuación · límite logístico a importaciones de acero

El acero marítimo requiere ahora capacidad física adicional del puerto: el lote mensual está limitado por `shipCapacity` y por el espacio libre `cargoCapacity - cargoStored`, además de stock, fondos y conectividad. Se agrega capacidad de puertos operativos conectados; sin espacio portuario no hay importación. Online y Offline implementados, prueba de límite de 4 unidades incorporada. Se corrigió el día de cierre mensual en dos regresiones Online y se amplió el diagnóstico del test responsive, que aún se investiga; no afirmar CI aprobado hasta verificarlo. Sin modificaciones de interfaz. Siguiente prioridad: ensayos largos de 30 años e integración con el transporte portuario.


## Continuación · prospección siderúrgica finita

El capital privado puede financiar prospección de mineral de hierro cuando la reserva regional operativa cae por debajo de 900 unidades: cada campaña cuesta $4500 y acredita 300 unidades desde `supply.unexploredSteelOre`, un yacimiento restante que inicialmente dispone de 12000 unidades, sin creación infinita de recursos. Se contabiliza `geologicalExplorationSpend`; el nuevo mineral se usa en reposiciones mensuales posteriores. Online y Offline implementados; prueba Online de caja y conservación agregada. El CI anterior confirmó el motor pero falló la comprobación responsive de la prórroga de contratos, pendiente de corregir. No hubo cambios de interfaz. Prioridad próxima: validación larga de 30 años y reparación del escenario UI.


## Continuación · stress mensual de 30 años por cuatro perfiles

Agregado `tests/stress_30_years.py`: ejecutable manualmente mediante `python tests/stress_30_years.py`, recorre 360 cierres mensuales para pueblo, metrópolis, puerto y ciudad turística, con capital/población/reservas distintos. Controla no negatividad de mineral, chatarra y stock siderúrgico, además de ausencia de NaN en caja privada. Se trata de una **prueba de cierres mensuales con salto de días**, no una simulación íntegra de 10.950 ticks diarios ni verificación de transporte LAN. Falta ejecutar y validar resultados, expandir métricas anuales y cubrir tráficos portuarios. También se agregó espera del panel contractual al test responsive anterior; no darlo por resuelto sin CI. Interfaz sin cambios.


## Continuación · estrés 30 años integrado a CI

`validation.yml` ejecuta `python tests/stress_30_years.py` en cada push a main, tras las regresiones de motores: cuatro perfiles y 360 cierres mensuales por perfil con controles de inventario siderúrgico, reservas, chatarra, caja municipal, capital privado y gasto de importación/prospección/reciclaje. Este test automatizado no reemplaza 10.950 ticks diarios completos ni valida LAN real. No se modificó la interfaz. Confirmar resultado del último workflow, resolver el fallo responsive de botón de prórroga y continuar con mecanismos jugables pendientes.


## Continuación · viajes marítimos reales de acero

Las compras extraordinarias de acero ya no acreditan metal instantáneamente. Online/Offline descuentan el costo de importación al contratar, crean `supply.steelShipments` con puerto, cantidad, fecha y estado `en viaje`, y completan descarga no antes de 12 días. El puerto debe permanecer operativo y conectado al Corralón del Puerto; si se corta la conexión, el lote queda esperando sin duplicar stock ni repetir gastos. La reserva de capacidad y límite comercial descuentan cargamentos en tránsito. `steelImportedUnits` solo aumenta tras recepción. Se amplió regresión Online para verificar demora, llegada y ausencia de doble recepción. Interfaz no modificada. Siguiente: validar CI y corregir fallo responsive previo.


## Continuación · descarga portuaria parcial

Los embarques de acero importado ahora descargan hasta `unloadingCapacity` unidades por día (20 por defecto), con `deliveredUnits`, `lastUnloadedDay` y estado `descarga parcial` mientras quede carga. El Corralón recibe únicamente las unidades efectivamente descargadas. Cortes viales y puerto inhabilitado detienen la descarga; queda prohibida una segunda descarga el mismo día. Las unidades pendientes siguen contando como importación en tránsito para evitar pedidos superpuestos. Implementado Online/Offline y nueva prueba de tres días para un lote de 20 unidades con descarga diaria de 7. Pendiente CI. Sin cambios de interfaz.

## Alfa 0.99 · descarga siderúrgica compartida

En ambos motores, el cupo diario `unloadingCapacity` de un puerto se comparte entre **todos** los embarques de acero que llegaron al mismo muelle: si dos barcos traen 5 y 8 unidades y el puerto solo admite 7 al día, se entregan 5+2 el primer día y las 6 restantes al siguiente. La regla conserva el tiempo de navegación, la necesidad de puerto operativo, el acceso vial y los costos ya pagados. `lastUnloadedUnits` guarda el volumen diario por remesa y evita superar el límite en reintentos o al reabrir un guardado. Para remesas heredadas sin volumen diario registrado, el motor utiliza una estimación conservadora, sin migración obligatoria del esquema.

Se añadieron regresiones Online y Offline con dos cargamentos en el mismo puerto y comprobaciones de idempotencia; el workflow `validation.yml` incorpora el nuevo test Offline. Se corrigió el escenario responsive de prórrogas: la orden tenía un proveedor ausente y se cancelaba por insolvencia ficticia; ahora tiene comprador y vendedor existentes, materia identificable y corte de calles real. El CI debe confirmar el resultado después de publicar. Se conserva fase 33 en 40% y fase 17 en 80%; el progreso global sigue sin estimación verificable. Las verificaciones LAN física y Vercel no se realizaron.

**Próximo trabajo:** verificar el resultado CI de Alfa 0.99; completar contratos industriales a plazo en otras cadenas y ampliar observabilidad anual del estrés de 30 años para detectar pérdidas de capital, migración extrema y cuellos de botella portuarios.

## Alfa 0.100 · eventos turísticos con circuito económico completo

Se priorizó una **mecánica nueva de fase 25** frente al pulido de sistemas ya existentes. El municipio puede contratar para el próximo cierre mensual una feria ($1.200, hasta 110 visitantes), festival ($3.500, hasta 320) o congreso ($5.200, hasta 190), siempre con fondos no comprometidos por obras. Solo cabe una actividad programada por mes; la organización se paga una vez y no se reembolsa si el recinto o los accesos fallan al celebrarla. Requisitos: centro cívico y 1–2 comercios abiertos con ruta; congreso además hotel abierto accesible.

Al realizarse, servicios efectivos de agua/energía/saneamiento, cantidad de comercios y presupuesto real de limpieza limitan asistentes. Cada visitante cuesta $3–$5 de limpieza según evento; se cargan costo público, agua y residuos previstos. Los visitantes son **externos y temporales**, sin alterar por esa causa el padrón. Pueden aportar ocupación real a hoteles con servicios y ruta aunque no haya aeropuerto, y comprar producto físico restante en tiendas: se debitan unidades de `business.inventory`, se acredita solo el dinero de esas ventas a `business.cash` y se registra ingreso y resultado. La liquidación de venta es idempotente por evento, sin crear inventario infinito ni duplicar gasto. No se presentan las presiones calculadas de agua/residuos como consumos reales de red: aún falta enlazarlas a las capacidades físicas.

Reglas equivalentes en `server.py` y `offline.js`; Ciudad > Turismo incorpora la programación y un registro de estado, gastos, aforo, alojamiento y consumo. Nuevas regresiones Online/Offline de contratación, prohibición de duplicación, ejecución y cancelación sin reembolso; `tests/test_ui_layout.mjs` verifica los tres controles del panel Turismo en 390×844 y 1440×900, sin sobrepasar el ancho. El workflow de GitHub Actions empaqueta Alfa 0.100. **No afirmar CI aprobado sin confirmación de la ejecución final**; LAN física y despliegue Vercel siguen sin prueba.

Fase 25 pasa de 30% a **40%**, sin estimación global por falta de pesos comunes. Pendiente: eventos estacionales, seguridad y presión territorial, infraestructura turística especializada, derrame al transporte y vivienda, programación a varios meses y estrategia turística. En próximos sistemas priorizar hospitales/ambulancias, educación avanzada, trenes/carga y otras fases de baja cobertura, en vez de gastar versiones en detalles de esta feria.

## Alfa 0.101 — sistema de hospitalización y ambulancias · fases 9 y 28

Nuevo sistema jugable integrado a la red de centros cívicos de salud. El jugador puede equipar una sala de 12 camas por $7.200, ampliar de ocho en ocho por $4.600 hasta 36 camas y comprar hasta tres ambulancias a $2.800. La operación requiere acceso vial y financiación municipal **libre después de reservar obligaciones de obra**. Las inversiones se guardan en `building.hospitalWard` (compatible con partidas anteriores sin este campo), sin duplicar pagos. Cada centro tiene médicos de `workplaces`; una sala separa hasta cuatro trabajadores para atención básica y asigna los restantes a internación, descontando dos por dotación activa de ambulancia. Esa reasignación reduce las consultas primarias posibles: no hay personal ficticio.

El informe `healthReport.hospital` agrega demanda agregada de internación por barrio, camas con ocupación/rotación modelada en tres días, admisiones, espera, hasta dos traslados diarios por ambulancia dotada, y recorridos de hasta 45 minutos por calles transitable. Los barrios cercanos pueden acceder directamente en hasta 25 min; los lejanos necesitan ambulancia operativa. Agua, cloacas, electricidad, factor de financiación y personal reducen capacidad, y calor y agua no segura elevan demanda. La espera persistente se registra una sola vez por día en `state.health.hospitalBacklog`. El gasto fijo mensual por camas y ambulancias y suministros variables se suma efectivamente al programa municipal de servicios; hospital vacío sin personal sigue costando dinero. No se simulan diagnósticos clínicos individuales.

El panel **Ciudad > Salud** presenta indicadores hospitalarios, lista de espera, barrios desatendidos y botones de inversión. CSS con controles flexibles y etiquetas de varias líneas; `tests/test_ui_layout.mjs` prueba controles visibles, sin superposición y sin overflow en 390×844 y 1440×900, con nombre hospitalario largo. Tests Online y Offline cubren inversiones, personal ausente, reasignación desde clínica, falta de rutas, fondos reservados, ambulancia y repetición de informe sin doble cola. `.github/workflows/validation.yml` incluye tests Offline. Conservar como **una entrega de mecánica grande** (no generar nuevas versiones por pulido). La fase 9 se documenta en 50% y fase 28 en 60%, ambas parciales; global sin ponderación confiable.

**Siguiente sistema recomendado por cobertura y dependencia:** policía y protección social (fases 9, 13, 28), o formación secundaria y técnica (fase 28) y progresión por objetivos (fase 14). Falta hospital independiente en obra, ambulancias ocupadas durante misiones multidiarias y ciclos de alta hospitalaria; no afirmar que estas partes ya existen. CI, LAN física y Vercel deben comprobarse por separado.

## Convención invariable de versiones (decisión del usuario)

El juego mantiene la serie **Alfa 0.N**, con N entero decimal que puede tener tantos dígitos como sea necesario. **NO** saltar a `1.0`, `1.00` ni `1.01`. Secuencia oficial: `0.98 → 0.99 → 0.100 → 0.101 → 0.102 → ... → 0.999 → 0.1000 → ...`. Las versiones son **identificadores de texto**, no números decimales. Al incrementar, extraer la parte posterior a `0.` como un entero e incrementarla en uno (sin acotación de longitud). No usar comparadores de punto flotante ni semver para estos identificadores. Corregir `release_notes.json`, cabecera del juego, rango de historial, nombre del artefacto CI y menciones documentales en cada entrega grande. Alfa 0.100 corresponde a eventos turísticos; Alfa 0.101 a hospitalización y ambulancias. Evitar crear nuevas versiones por detalles aislados: la prioridad son sistemas jugables del roadmap.

## Alfa 0.102 · seguridad urbana y patrullaje (fases 9, 13 y 28)

Se agregó un **sistema jugable nuevo** en Online y Offline. Cada centro cívico municipal habilitado y con acceso vial puede equipar una base de seguridad por $4.000, que incluye un vehículo; cada móvil adicional cuesta $2.500, máximo tres. Las inversiones se pagan de caja **no comprometida por obras**. Se guarda en `building.policeUnit`, compatible con partidas antiguas sin esa propiedad. Las patrullas solo funcionan con electricidad/agua y financiación suficiente. Cada vehículo activo ocupa **tres trabajadores municipales** y el centro conserva hasta cuatro para atención primaria; la disponibilidad de personal para clínica e internación se reduce efectivamente y los móviles comprados sin dotación no prestan servicio. La prioridad puede cambiar entre mixta, residencial y comercial sin costo instantáneo.

Al cierre mensual se simulan incidentes deterministas de convivencia y comercio según localización, comercio, calles deterioradas y cortes de electricidad; no se usan atributos personales protegidos ni se atribuye delito a colectivos. El móvil solo interviene si existe camino con hasta 40 minutos de viaje y dispone de cupo (máximo dos intervenciones mensuales por patrulla). El enfoque reduce riesgo donde corresponde. Los incidentes sin respuesta pueden retirar hasta tres unidades reales del inventario comercial y, si se acumulan, erosionar aprobación/servicios. No se crea dinero ni inventario. El cierre se marca con `police.lastProcessedMonth` para evitar repetir pérdidas o intervenciones ante múltiples lecturas/reintentos. Costos fijos $390 por móvil y $70 por intervención atendida se imputan al programa municipal de **Servicios**; sin unidad no se cobran gastos ficticios. `policeReport` presenta cobertura por inmueble, atendidos/no atendidos, asignación de trabajadores, recursos y últimos incidentes. Es un primer nivel municipal de seguridad, no un cuerpo policial profesional independiente, que queda pendiente.

La sección **Ciudad > Seguridad** permite equipar, reforzar y configurar enfoques y muestra resultados económicos y sociales. Los botones se adaptan al ancho y admiten nombres largos; `tests/test_ui_layout.mjs` valida pantalla de 390 y 1440 px sin solapamiento, recorte u overflow. Se añadieron `tests/test_police_online.py` y `tests/test_police_offline.mjs`, incluidos en el CI. **No declarar pruebas concluidas antes de leer el último workflow**; la misma Alfa 0.102 agrupa todos los ajustes de esta mecánica. Fase 9: 55%, fase 13: 35%, fase 28: 65%; no asignar porcentaje global inventado. LAN real y Vercel aún no se verificaron.

**Siguiente gran mecánica recomendada:** protección social (hogares desplazados, vulnerabilidad y ayudas con cupos, presupuesto y consecuencias), seguida de educación secundaria/técnica y/o seguridad profesional con edificios, formación y turnos. Priorizar sistemas nuevos sobre microajustes, pero no sacrificar validación UI/CI.

## Requisito visual 3D obligatorio — intervención del usuario (Alfa 0.102, sin incrementar versión)

Toda mecánica de ciudad que tenga un actor físico debe representarse en el mundo Three.js, **no sólo en paneles**: vehículos, construcción, servicios, tráfico y labores visibles en tiempo real. La prioridad inmediata era hacer visibles **policía, bomberos y ambulancias**: las bases equipadas muestran coches policiales; los cuarteles exhiben autobombas; los hospitales, ambulancias. Con dotación activa, los patrulleros recorren calles conectadas; cuando hay incidente policial o incendio atendido, se reconstruye y anima la ruta de respuesta real, guardada por el motor. Los traslados de ambulancia se guardan en `health.ambulanceDispatches` (idempotentes por día, con origen, destino, pacientes y ruta) y se reproducen en el mundo cuando existen. Sin ruta transitable, el actor permanece estacionado, nunca atraviesa parcelas. Al seleccionar un actor móvil en Three.js, el panel describe su labor. No fabricar misiones visuales que no existen en la simulación.

El pipeline de render mantiene vehículos móviles en `trafficRoot`; `world3d.js` añade `makePoliceCar`, `makeAmbulance`, `spawnEmergencyActors`, búsqueda de ruta vial sin segmentos inhabilitados, patrullaje físico y reproducción temporal de incidentes. La función de diagnóstico `window.__ciudadViva3D()` expone la posición real de los actores Three.js para el test visual automatizado. `tests/test_ui_layout.mjs` cubre 390 y 1440 px, comprueba que las tres clases existen de verdad en el árbol de escena, tienen ruta y cambian de posición al transcurrir el tiempo. Esta validación corresponde a Alfa **0.102**, no crear 0.103 por una mejora de presentación de la misma mecánica.

**Norma futura:** diseñar cada sistema en tres capas simultáneas: estado/cálculo Online-Offline, interfaz informativa accesible y representación concreta en el mapa 3D. Una cifra en el panel no sustituye al actor físico. Las intervenciones históricas se muestran como reproducción visual de lo ocurrido, no como nuevas intervenciones reales; las unidades sin operación deben verse estacionadas. Faltan aún animaciones más profundas de entrada en edificios, evacuaciones, reparaciones y otras tareas urbanas; no declararlas hechas.

## Alfa 0.103 · edificios de servicios obligatorios, categorías y cobertura 3D

**Decisión vinculante del usuario:** ninguna atención médica, policía, autobomba ni basurero debe surgir gratuitamente del edificio de la Municipalidad. El jugador **debe construir** instalaciones específicas, varias si la ciudad crece. Cada base tiene una cobertura **máxima** medida por caminos viales conectados (no distancia euclidiana); las calles inhabilitadas no cuentan. Seleccionar edificio terminado/proyecto o previsualizar una tipología debe colorear **verde las calles efectivamente alcanzadas en la ciudad 3D**. Mantener actores 3D concretos (ambulancia, policía, autobomba, camiones) y reflejar su operación real. Las construcciones avanzadas cuestan más, tardan más, consumen más materiales y ofrecen mayor personal, equipamiento y alcance.

Se incorporaron **12 variantes de servicio**, elegibles desde Construir agrupadas por familias y licitadas por las constructoras existentes (Online/Offline): Salud = consultorio barrial ($8.000, 6 tramos, 12 puestos), policlínico ($14.200, 10, 24), hospital general ($25.500, 16, 40, 36 camas y 2 ambulancias); Seguridad = puesto de vigilancia ($9.200, 6, 12), comisaría distrital ($16.500, 11, 22, 2 móviles), central de seguridad ($28.700, 16, 36, 3); Bomberos = destacamento ($11.200, 7, 12, 1 autobomba), cuartel ($19.800, 12, 22, 2), comando ($33.000, 17, 36, 3); Residuos = base ($5.600, 6, 8, 1 camión), centro de transferencia ($12.000, 11, 14, 2), complejo de higiene urbana ($22.200, 17, 26, 3). Costos de referencia antes del multiplicador de la constructora; radio expresado en tramos de ruta. Las instalaciones de policía se construyen con tipo base `civic` pero `serviceModel` policial, segregadas de los centros sanitarios. Las instalaciones anteriores compatibles mantienen sus atributos y las que carecen de modelo se asocian al nivel básico cuando realmente son servicios, nunca a Municipalidad. Esta última puede seguir siendo sede municipal y centro de eventos, **no clínica, comisaría ni base de residuos**.

Servidores: `SERVICE_MODELS` y `service_model`/`offlineServiceModel`, `service_route_within`/`offlineServiceRoad`, radio aplicado a admisiones, internaciones, incidentes policiales, bomberos, rutas a contenedores y hogares cubiertos por camiones. Recolección ya no tiene camión ficticio desde el punto central ni capacidad de calle independiente de las bases. Los inmuebles mayores exigen incrementos proporcionales de las cinco clases de materiales y todo el costo contractual. En Three.js se diferencian policías, cuarteles y depósitos de niveles superiores; `coverageRoads` ilumina verde solo la red dentro del límite del edificio/obra seleccionada. Pruebas `test_service_models_online.py`/`test_service_models_offline.mjs` y UI en 390/1440 px verifican catálogo, proyectos, ausencia de cobertura gratuita y superposición; prueba de vehículo 3D exige redes energéticas y agua conectadas. **No confundir un vehículo estacionado por falta de servicios con fallo gráfico**.

La prioridad siguiente es extender la tipología escalonada a **escuelas (jardín, primaria, secundaria, universidad), industria, electricidad, agua, vivienda y comercios**, sin romper obras/contratos existentes; edificios especializados independientes pueden sustituir gradualmente el uso compartido de `civic`. No declarar terminadas todas las categorías construibles todavía. Continuar respetando la secuencia Alfa `0.103 → 0.104` y reservar números nuevos para mecánicas grandes. Confirmar CI final antes de afirmar aprobación completa; LAN/Vercel requieren prueba externa.

## Alfa 0.104 · jardín, primaria, secundaria y universidad con educación efectiva

Se agregaron cuatro obras municipales en Construir, con licitación y recursos materiales realmente proporcionales: jardín ($6.200, 52 días, 8 vacantes, radio 5 tramos, 5–6 años), primaria ($9.600, 68 días, 12 vacantes, radio 8, 7–12), secundaria ($17.800, 100 días, 18 vacantes, radio 12, 13–17), y universidad ($32.000, 145 días, 30 vacantes, radio 17, 18–24). Las bases tienen aulas y operación mensual $580/$820/$1.550/$3.200 más nómina e insumos por inscripto. La simulación de Online y Offline toma un residente identificable, una edad compatible y un máximo de ruta por calles abiertas; si una sede se llena, busca otra accesible. Los cupos dependen de profesores cualificados efectivamente empleados, aulas, electricidad, agua, saneamiento y presupuesto. Tras doce meses realmente asistidos por nivel, se registra la formación y aumentan las competencias laborales según ciclo, sin acreditar nada por informes repetidos o edificios vacíos. Las partidas antiguas con edificios u obras school sin serviceModel conservan su funcionamiento previo para edades 5–17.

La escena 3D distingue jardines y edificios mayores, y muestra en verde sobre calles transitables el radio del establecimiento seleccionado o previsualizado. Se incorporan regresiones Online/Offline y se actualiza el empaquetado CI. Los estudiantes todavía no se mueven individualmente por las calles de Three.js; tampoco existen carreras universitarias completas ni oferta técnica especializada. Fase 28 queda parcialmente en 75%, progreso global no cuantificable. CI se verificará después de publicar; LAN física y Vercel siguen sin comprobar.

**Siguiente gran mecánica sugerida:** protección social por hogar con elegibilidad objetiva, presupuesto y cupos mensuales realmente acotados y efectos comprobables. Seguir la serie Alfa 0.N: 0.105 → 0.106.


## Alfa 0.105 · interfaz rosa minimalista, avisos físicos y construcción comprensible (histórico)

La interfaz pasa a rosa empolvado/crema, superficies blancas, controles con jerarquía y navegación simplificada sin ocultar el simulador. En el muelle inferior hay **Avisos** y **Ayuda**. El módulo cityGuide.js obtiene alertas de datos calculados por las simulaciones Online/Offline: policía, incendios, ambulancias, basura visible, contenedores casi llenos, tramos dañados y obras pausadas. Cada aviso tiene identificador, posición real y texto accionable; la proyección de la cámara coloca botones 2D sobre el edificio o la calle (giro y zoom incluidos). Pulsar una alerta abre descripción y permite inspeccionar parcela. No se fabrican incidentes sin causa simulada. Los eventos resueltos solo se ven por un período limitado; los incidentes sin respuesta no se confunden con los atendidos. Los avisos son lectura y localización de hechos existentes, no despacho municipal manual.

Los cubos junto a calles corresponden a **contenedores de residuos**, **bolsas de basura no recogida** o **barreras de calzada deteriorada**, no a bloques de construcción. Al tocar la parcela se identifican con cantidad/capacidad o condición y medidas de solución. Las zonas amarillas son **permisos industriales, no fábricas terminadas**. Al tocarlas se puede elegir especialidad, o hacerlo en Construir: procesadora de alimentos, cantera, hormigonera, aserradero y metalúrgica. Los dos motores validan y guardan la especialidad elegida, sin cambiar la asignación automática de inversiones zonificadas y partidas anteriores sin selección explícita.

**Cómo conseguir hormigón:** en Obras → Pedir materiales, elegir proveedor con hormigón físico en stock, ruta para camión, destino con espacio y caja del contratista. Para producir localmente: dos parcelas industriales conectadas; construir primero cantera (áridos), después hormigonera. La receta del juego consume *dos áridos físicos por unidad de hormigón*, además de necesitar personal, electricidad, agua, saneamiento, capital privado y cadena logística. No afirmar que se modela cemento por separado. Las obras no terminan al pintar suelo: la guía explica etapas, certificados, esperas, causas y materiales aún por consumir, diferenciados de stock entregado o en tránsito.

Three.js añade detalles decorativos y diferenciación a todas las familias, patios, señalética, jardineras, fachadas, cubiertas, instalaciones industriales y luminarias, además de iluminación más cálida; se mantiene como base el modelado procedural previo, sin importar modelos CAD externos. En móvil se omiten adornos adicionales costosos. **Pendientes**: efectos activos de humo/llamas, tutorial con pasos validados, remodelación total de cada activo con malla de alta calidad, despacho manual de emergencias y mejoras adicionales de rendimiento. No declarar esos sistemas completos. Las regresiones cubren clasificación de avisos, fuentes, guía de materiales, especialidad industrial Offline y UI responsive. Verificar CI después de publicar; red LAN física y Vercel requieren comprobación separada.

**Próxima etapa:** emergencias con decisiones y respuesta municipal sobre el mundo; después optimización visual y tutorial por objetivos persistente.

### Ajuste Alfa 0.105 · primeros pasos guiados

El panel Ayuda ahora ofrece seis pasos con estado derivado del juego (calles existentes, suelo industrial, fábrica contratada, pedido de materiales y equipamientos). No confundir un permiso amarillo con la obra ni marcar avances sin evidencia: el primer paso es orientación, los restantes dependen de entidades existentes. Tests en cityGuide verifican este comportamiento. Los paneles Avisos y Ayuda son accesibles desde el dock.

### Mejora visual final de Alfa 0.105

Se sustituyen los cubos genéricos de basura por bolsas con silueta y nudo, y las barreras de calles deterioradas usan postes y señalización. Los incendios reales activos reciben una animación sutil de llama y humo en Three.js; sin un incendio emitido por el motor, no aparecen efectos. Mantener consumo de recursos bajo y validar captura responsive.

La fase 13 avanza del 35% al 40%. En el panel Ciudad → Servicios, una avería permite contratar reparación normal al costo base y tres días, o despachar una cuadrilla prioritaria por el doble y un día. La respuesta urgente verifica conectividad vial y caja municipal libre después de compromisos de obra; las acciones repetidas se rechazan. El corte aparece en Avisos con causa, ubicación, afectados y opciones. La ruta y el estado de la cuadrilla persisten y Three.js presenta un vehículo seleccionable durante el trabajo y hasta un día después de restablecer la red. Online y Offline usan el mismo costo, plazo y requisitos. Tests: `test_utility_response_online.py`, `test_utility_response_offline.mjs`, `test_city_guide.mjs` y revisión UI responsive.

**Pendiente:** responder con opciones específicas a enfermedades, accidentes y otras crisis; completar el catálogo causal de fase 13. La UI integral queda como etapa posterior a esta tanda mecánica, según la instrucción del usuario. El progreso global sigue sin estimarse: el registro de roadmap no define pesos verificables comunes para ponderar las 34 fases. Fase 13: 40%.

**Siguiente entrega:** ampliar fase 13 con respuesta sanitaria y movilidad ante accidentes, e integrar sus efectos persistentes. A continuación iniciar el rediseño visual integral solicitado. Mantener controles sin límites para invitados.

## Alfa 0.107 · rediseño integral Atlas municipal

La interfaz adopta una dirección cartográfica propia: azul petróleo, papel cálido, acento terracota y verde de acción. `design.css` concentra el nuevo sistema para pantalla de inicio, barras superiores, indicadores, mapa, dock, ventanas, catálogo, formularios, avisos y paneles de ciudad. El archivo se sirve también por el anfitrión LAN. Se corrigió la cuadrícula heredada: como los paneles laterales están en ventanas, el mapa ocupa todo el ancho de escritorio; en móvil ocupa toda la altura entre indicadores y pie. Los controles y textos largos permiten envolver y desplazar contenido. La navegación y mecánicas siguen disponibles. Comprobar visualmente 390×844 y 1440×900, además de las pruebas de interfaz existentes.

Fase 15 sube de 60% a 65% por coherencia visual y legibilidad comprobables. Progreso global aún no estimable: faltan pesos comunes verificables para las 34 fases. Pendientes: sesiones de usabilidad con personas y revisión de accesibilidad. Próxima entrega: respuestas sanitarias y viales de fase 13.

## Alfa 0.108 · movilidad y lectura de la ciudad (2026-11-01)

- El mapa dibuja estrés vial con viajes ya simulados, señales visuales en intersecciones, vehículos en carril derecho y giros de orientación suavizados. Los semáforos detienen visualmente los actores; la espera semafórica aún no entra en el cálculo autoritativo de tiempos.
- Se ampliaron geometrías y detalles de árboles, coches, buses, casas y fábricas. Se aumenta el zoom a 4×. En móvil se reduce la cantidad de árboles decorativos para sostener el rendimiento.
- Avisos reutilizados entre actualizaciones, pulso suave y ubicación baja para basura/calles. El panel de aviso conserva causas y acciones.
- Construir tiene grupos visibles; Economía separa producción, Hacienda y mercado; Ciudad muestra un menú vertical. Tema claro/oscuro guardado localmente. Sonido ambiental procedimental tras interacción.
- Al cambiar ventanas, los nodos de controles regresan a sus contenedores originales. La lista LAN consulta `/api/rooms` si existe un iniciador y muestra sesiones anunciadas. En Vercel no es posible descubrir máquinas LAN desde un sitio estático bajo HTTPS; se ofrece estado vacío y unión manual, sin simular salas.
- Verificación: sintaxis JS, pruebas Python 52/52, inspección visual móvil y escritorio de Construir, Ciudad, Economía y Tráfico. La prueba completa de Playwright terminó correctamente en 390 y 1440 px tras evitar el render 3D detrás de ventanas; también pasó la prueba visual de respuesta de servicios. Se verificaron por navegador la lista vacía LAN, el panel flotante de tráfico y el tema oscuro. Pasó también el stress económico de 30 años con cuatro perfiles y 360 cierres mensuales por perfil. La prueba entre dos computadoras físicas sigue pendiente.
- Progreso global: no cuantificable todavía. El método por fase usa incrementos de 5 puntos con evidencia, pero no hay pesos estables y verificables para agregar las 34 fases. Fases 7 y 15: 70% cada una, ambas parciales. Hito actual F; próximo: completar simulación vial con tiempos autoritativos, accidentes y otros sistemas pendientes de F.


## Continuidad desde Alfa 0.134

Último avance: centro municipal de cuidados diurnos para personas de 75+, integrado en ambos motores. Lee `ESTADO_DESARROLLO.md` y `SIGUIENTE_ENTREGA.md`; siguiente prioridad de mecánica: movilidad accesible y resultados longitudinales de protección social, después formación técnica. Capacidad actual = min(cupos físicos, 4 por trabajador) × proporción de redes/financiación, siempre con ruta vial al hogar. El reporte vive en `socialCareReport` online y `socialServices.elderCareReport` offline. No declarar esta área completa: no hay dependencia, visitas por frecuencia, ayuda de movilidad ni efectos longitudinales de bienestar.


## Continuidad desde Alfa 0.135

Nuevo bloque de fase 29: refinanciación municipal en ambos motores. Revisa `refinance_municipal_loan` en `server.py`, acción `refinanceMunicipalLoan` en `offline.js` y tarjeta `loan-refinance` en `game.js`. Tasa nueva 18% anual, 72 cuotas, saldo + mora como nuevo principal, no acredita efectivo y solo una reestructura si baja la mensualidad. Pruebas: `test_municipal_refinancing_online.py`, `test_municipal_refinancing_offline.mjs`, comprobación responsive `test_municipal_forecast_ui.mjs`. Fase 29 se estima con cinco bloques iguales de 20 puntos (100% completo, 50% parcial, 0% faltante), avance 40% actual (100/50/50/0/0). Siguiente: libro de caja de doble entrada conciliable y escenarios fiscales explícitos, más costo de vida de infraestructuras.


## Continuidad desde Alfa 0.136

Nuevo trabajo de fase 29: libro de caja neto en `server.py` (`record_municipal_cash_movement`, `municipal_cash_ledger_report`) y `offline.js` (`recordOfflineMunicipalCashMovement`, `offlineCashLedgerReport`), visible en `game.js` como panel `.cash-ledger`. Persiste apertura, cobros/pagos netos, acumulados, delta conciliado y hasta 120 movimientos; UI muestra los 12 últimos. Operación sin cambio no duplica; guardado legado toma la caja actual y no inventa historia. Es una captura entre límites API/cierre con referencia al evento reciente, no una partida doble ni clasificación de cada cuenta. Tests: `test_municipal_cash_ledger_online.py`, `test_municipal_cash_ledger_offline.mjs`, ampliación responsive de `test_municipal_forecast_ui.mjs`.

La fase 29 permanece en 40%, sin alterar criterio: cinco bloques de 20 puntos, resultados actuales 100/50/50/0/0. Para avanzar su auditoría, reemplazar/acompañar snapshots netos con fuentes tipadas en cada operación, distinguir gasto, ingreso, transferencia y reserva, mantener atomicidad Online/Offline y probar conciliación después de cargas/acciones repetidas. Después desarrollar escenarios fiscales con fórmulas transparentes y costo de vida de redes/infraestructura. Progreso total continúa sin estimarse hasta contar con pesos comunes verificables de las 34 fases.


## Continuidad desde Alfa 0.137

Nuevo sistema parcial de fase 29: `scenarios12` Online en `municipal_finance_scenarios` (`server.py`) y Offline en `offlineMunicipalScenarios` (`offline.js`); UI `municipalScenarioPanel`/`.municipal-scenarios` en Economía. Casos base 0/0, favorable +10% ingreso/−5% gastos y adverso −15% ingreso/+10% gastos, horizonte de 12 meses. Usa forecast real de proyectos, hitos, prioridades, reservas, deuda y mora, en copias sin alterar estado guardado. Incluye una clave de caché ligada a entradas financieras para que los sondeos no recalculen continuamente.

Tests: `test_municipal_forecast_online.py`, `test_municipal_forecast_offline.mjs` y `test_municipal_forecast_ui.mjs`. Fase 29: 50% con pesos fijos 20 puntos/bloque y valores 100/50/50/0/50. Próximo: extender a 1/4/10/20 años con población, salarios, inflación ficticia, impuestos y demanda; después calcular ciclo de vida de infraestructura con componentes conectados al mantenimiento/operación existentes. No llamar completo al comparador hasta cubrir horizonte y supuestos trazables.

# Continuidad inmediata · Alfa 0.145

La última entrega agrega expansión territorial pagada en fase 1. Lee los bloques Alfa 0.145 en `ESTADO_DESARROLLO.md`, `DECISIONES_TECNICAS.md` y `SIGUIENTE_ENTREGA.md` antes de continuar. Lógica de servidor Online: `server.py`, `new_settlement_state`, `ensure_land_claims`, `land_chunk_info`, `land_frontier`, `unlock_land_chunk`, además de validaciones en acciones `place` y `zone`. Offline equivalente en `offline.js` (`ensureOfflineLandClaims`, `offlineLandInfo`, `offlineLandFrontier`, `unlockLand`). Cliente/interfaz 3D: `game.js` y `world3d.js`; estilo de ficha en `design.css`.

Cada sector mide 8×8; la nueva partida abre `0,0`, `1,0`, `0,1`, `1,1`, con salida regional `(4,10)`. La interfaz dibuja candados sobre el frente ortogonal calculado. Seleccionar una parcela bloqueada muestra su costo y un botón; la compra requiere vecino desbloqueado y caja libre tras compromisos. Precio por anillo: 3.500 + 2.200 por cada anillo adicional, con anillo mínimo 1. Las coordenadas negativas y las partidas anteriores están contempladas; migrar guardados abre los sectores ocupados existentes. Para mantener paridad, aplicar cualquier cambio de reglas en ambos motores.

Pruebas de esta build: `tests/test_new_settlement.py`, `tests/test_new_settlement_offline.mjs`, `tests/test_land_expansion_ui.mjs`. Esta última revisa candado, precio, compra y encuadre en 390×844 / 1440×900. Fase 1 pasa a 75% (antes 70%); faltan catastro/derechos de propiedad y estrés con ciudades extensas. No declarar el juego completo ni inventar progreso global: `overallProgress` sigue `null` por falta de ponderación común verificable para 34 fases.

Siguiente tarea inmediata: desarrollar catastro/propiedad ligado a parcelas y expandir pruebas de guardado y cámara más allá del viejo borde 28×20. Después cambiar a otra mecánica incompleta del roadmap. No prolongar el trabajo en pulido menor.

Publicación obligatoria: commit directo en `main`, autor Git `Tobias Morel <66056611+TobyMorel@users.noreply.github.com>`, revisar SHA/CI y crear ZIP completo sin `.git`, cachés ni ZIP de versiones anteriores.

## Continuidad más reciente · Alfa 0.155

Bug de inicio offline corregido: guardados viejos pueden no incluir nuevas colecciones; `offline.js` completa con arrays vacíos las colecciones que el seed define como arrays y `world3d.js` protege buildings/projects al construir la escena. Regresión permanente: `tests/test_offline_boot_recovery.mjs` cubre localStorage limpio y un guardado sin esas dos propiedades; el job responsive ejecuta el caso primero en cada push. Reproducir/validar con `node tests/test_offline_boot_recovery.mjs`. La prueba de LAN entre dos computadoras aún requiere hardware; no se afirma validada.

Mantener identidad Git noreply: `Tobias Morel <66056611+TobyMorel@users.noreply.github.com>`. Publicar en main y adjuntar ZIP íntegro por entrega. Global no estimable; fases 7=95%, 4=60%, 9=75%.
